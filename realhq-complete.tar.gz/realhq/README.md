# RealHQ Studio — H-teach hub (Phases 1–3: backend + bilingual UI)

```bash
pip install reportlab arabic-reshaper python-bidi      # PDF export only; everything else is stdlib
python -m server.server                                  # first run prints a ONE-TIME password for user "hammam"
python -m tests.test_smoke                               # 88 end-to-end checks (boots its own server + temp data dir)
python -m server.admin reset-password hammam             # offline recovery
python -m server.restore data/backups/<file>.db           # verify a snapshot (add --apply to restore)
```
Open http://127.0.0.1:8080/ — the Employee Login Portal (Arabic RTL by default; `L` toggles English LTR). On localhost over plain HTTP set `REALHQ_ENV=development`;
in production serve behind HTTPS. First start (empty data dir):
`REALHQ_ENV=development REALHQ_BOOTSTRAP_PASSWORD='<your temp password>' python -m server.server` — the password only applies when the database is first created, and must be changed at first login.
UI files live in `web/` (no build step; strict CSP, text is always inserted as text). Shortcuts: `1–4` tabs, `L` language, `Esc` close panel.

Key env vars: `REALHQ_DATA_DIR`, `REALHQ_PORT`, `REALHQ_ENV=development` (allows non-HTTPS cookies on localhost),
`REALHQ_BOOTSTRAP_PASSWORD`, `REALHQ_SEED_DEMO=0`, `REALHQ_PDF_FONT`, `REALHQ_TRUST_PROXY=1` (behind a reverse proxy). See `server/config.py`.

Run behind a TLS reverse proxy in production. Full design, RBAC matrix and API contract: `docs/PHASE1_ARCHITECTURE.md`.
