# RealHQ Studio — Phase 1: Architecture
**Enterprise:** H-teach hub · **Platform:** RealHQ Studio · **Final decision-maker:** Hammam Alhwamdeh / همام الحوامدة (Founder, CEO & CTO)

Status: Phase 1 (design) + Phase 2 (backend) delivered and verified by `tests/test_smoke.py` (88 end-to-end checks). Phase 3 (bilingual UI) is intentionally **not started**.

## 1. Directory structure
```
realhq/
├── server/
│   ├── server.py          HTTP wiring: routing, CSRF, RBAC gate, rate/size limits, security headers
│   ├── config.py          env-driven config (secrets never come from clients)
│   ├── schema.sql         bilingual, tenant-scoped relational schema (v1)
│   ├── db.py              per-thread connections, serialized write transactions (mutation + audit are atomic)
│   ├── seed.py            H-teach hub, RealHQ Studio, departments/rooms/skills (AR+EN), Hammam as CEO&CTO, demo team
│   ├── security.py        PBKDF2 hashing, password policy, rate limiter, sessions
│   ├── rbac.py            roles, permissions, data-classification clearance, task state machine
│   ├── audit.py           HMAC hash-chained, append-only audit log
│   ├── api.py             bilingual errors, route registry, whitelist validation, tenant-checked references
│   ├── handlers_auth.py   login/logout/rotate/change-password, employees, reference, live HQ state
│   ├── handlers_data.py   tasks, clients, leads, projects, knowledge, research, time, approvals, scoped chat
│   ├── handlers_ops.py    audit, backups, retention, exports, health
│   ├── backup.py          online backups, integrity checks, rotation, restore verification
│   ├── retention.py       dry-run -> confirm -> snapshot+archive -> delete (365-day lifecycle)
│   ├── exports.py         CSV (UTF-8 BOM, formula-safe) and PDF (Arabic shaping + RTL) generators
│   ├── workers.py         backup scheduler, retention dry-run, session GC, crash recovery
│   ├── admin.py           offline CLI: reset-password, unlock, backup-now, verify-audit
│   └── restore.py         offline restore with verification
├── tests/test_smoke.py    real-server end-to-end tests
└── docs/PHASE1_ARCHITECTURE.md
```
Runtime data (`./data`, mode 0700): `realhq.db`, `backups/`, `archives/<company>/`, `secrets/audit_hmac.key`.

## 2. Key architecture decisions
| Decision | Rationale / honest trade-off |
|---|---|
| Python stdlib HTTP server + SQLite (WAL) | Zero-dependency, runnable anywhere, fully testable. Single-node by design. For horizontal scale: put behind a reverse proxy (TLS) and migrate to PostgreSQL; every query is already `company_id`-scoped and the schema is portable. |
| Writes serialized via one lock + `BEGIN IMMEDIATE` | A change and its audit entry commit atomically; gives a gap-free audit sequence. Throughput limit is acceptable for an executive-ops tool; reads are concurrent. |
| Multi-tenancy via `company_id` on every table | Enforced in every query; foreign keys are validated to belong to the **same** company; out-of-scope rows return 404 (not 403) so existence doesn't leak. |
| Backups are whole-database | Therefore they are **platform-level**: only the platform-root company's CEO/CTO manages them (auditor read-only). |
| TLS is not terminated here | Run behind Caddy/nginx. `Secure` cookies are on by default (`REALHQ_ENV=development` disables for localhost). |

## 3. Data model (summary)
- **Identity:** `companies` (AR/EN, parent/unit, `is_platform_root`), `departments`, `rooms` (HQ grid), `skills`, `employees` (`display_name_*`, `role_*`, `bio_*`, `rbac_role`, `password_hash`, lockout fields, desk/room), `employee_skills`, `sessions` (stores only SHA-256 of token + CSRF token).
- **Work:** `clients`, `leads`, `projects`, `tasks`, `approvals`, `time_entries`, `knowledge_items`, `research_reports`, `chat_threads`/`chat_messages`. All carry `company_id`; sensitive ones carry `classification ∈ {internal, confidential, restricted}`.
- **Governance:** `audit_log` (append-only triggers, HMAC chain), `backup_policy`, `backup_runs`, `retention_rules`, `cleanup_runs`, `export_jobs`, `worker_status`.

## 4. RBAC and privacy
| Capability | ceo_cto | manager | member | auditor |
|---|:-:|:-:|:-:|:-:|
| Clearance (data classification readable) | all | internal+confidential | internal | all (read-only) |
| Employees: create / role / deactivate / reset password | ✅ | – | – | – |
| Tasks/clients/leads/projects: read / write | ✅ / ✅ | ✅ / ✅ | tasks+projects only; own tasks | read |
| Assign tasks to others | ✅ | ✅ | self only | – |
| Request approval | ✅ | ✅ | ✅ | – |
| **Decide approval (final authority)** | ✅ | – | – | – |
| Delete records | ✅ | – | – | – |
| Audit log + verify, export history | ✅ | – | – | ✅ |
| Exports | all | business entities + summary | – | all |
| Backups / retention manage | ✅ | – | – | read |

**Task state machine** (transitions into `awaiting_approval/approved/rejected` happen *only* through the approvals API):
`draft→todo|cancelled` · `todo→in_progress|cancelled` · `in_progress→todo|done|cancelled` · `awaiting_approval→cancelled` · `approved→in_progress|done` · `rejected→todo|cancelled` · `done→todo` (manager+) · `cancelled→todo` (CEO only).
Tasks flagged `external_action` **cannot reach `done` without an approved approval** — drafts never masquerade as completed external actions.

**Security controls implemented:** PBKDF2-HMAC-SHA256 (600k iterations, 16-byte per-user salt, auto-rehash on login) · password policy (≥12 chars, mixed classes, no username) · lockout after N failures + per-IP login limiter + global limiter · uniform `INVALID_CREDENTIALS` response (no account enumeration; dummy hash on unknown users) · `HttpOnly; SameSite=Strict; Secure` cookie, token stored hashed, idle + absolute expiry, rotation/logout/revoke-on-role-change/password-change · CSRF token + Origin check on all mutations · forced password change on first login · 1 MB body cap, JSON-only, no chunked bodies, socket timeouts, concurrency cap · whitelist validation (unknown fields rejected) · parameterized SQL only · plaintext passwords/hashes never returned or logged (audit redacts keys matching pass/token/secret/hash) · CSP `default-src 'none'`, `nosniff`, `X-Frame-Options: DENY`, `no-store`.

## 5. Audit design
Every audit row stores actor, action, entity, redacted summary/diff, IP, and `entry_hash = HMAC-SHA256(key, canonical(row) ‖ prev_hash)` per company. DB triggers block `UPDATE`/`DELETE`. `GET /api/audit/verify` (and restore verification) recomputes the chain; the key lives in `secrets/audit_hmac.key` (0600), so an attacker with only DB access cannot forge a valid chain. Logged: logins, failures, lockouts, account/role changes, approvals, exports, backups, restore-verifications, cleanups (exact counts), policy changes.

## 6. Backups, exports, retention
- **Backups:** `hourly|daily|weekly` worker (60 s tick, resumes after downtime), manual trigger, SQLite online-backup API → integrity check → SHA-256 sidecar → mode 0600 → rotation (`keep_count` scheduled; 30 manual; 30 pre-cleanup). **Restore verification** restores into a temp dir and checks hash, `integrity_check`, foreign keys, and audit chain — it never touches the live DB. Live restore is an **offline** CLI (`python -m server.restore`) requiring typed confirmation.
- **Exports:** CSV (UTF-8 **BOM**, CRLF, formula-injection neutralized, `en|ar|bi` headers) and PDF (A4 landscape, Arabic reshaping + bidi, RTL column order, header banner with classification, metadata block, page numbers). Filters: `status, since, until, classification, lang`. Clearance-filtered; each export logged in `export_jobs` + audit with SHA-256.
- **Retention (365-day floor, configurable upward):** candidates = closed/cancelled tasks, stale drafts, closed-lost leads, finished research reports older than the rule. **Protected:** tasks in active/planned/on-hold projects, leads linked to active clients, clients, pinned knowledge, approvals, audit log. Flow: nightly **dry-run only** → `pending_confirmation` plan (7-day TTL) → CEO/CTO types `DELETE n RECORDS` → mandatory pre-cleanup backup (abort on failure) → JSON archive (0600) → re-check eligibility → atomic delete (`secure_delete` on) → exact counts in audit.
- **Resilience:** workers catch/log/back-off and publish heartbeats (`/api/health/detail`); on startup, interrupted backup/cleanup runs are marked failed, never silently resumed.

## 7. REST API contract
JSON over `/api`. Mutations need cookie + `X-CSRF-Token`. Errors: `{"error":{"code","message_en","message_ar","details"}}`. Lists accept `limit` (≤200), `offset`, `q`, plus resource filters.
Login: `POST /api/auth/login {identifier, password, company?}` — `identifier` is a username (scoped by `company` slug, default `h-teach-hub`) or a company email.

| Method | Path | Permission | Notes |
|---|---|---|---|
| GET | `/api/approvals` | `approvals:read` |  |
| POST | `/api/approvals` | `approvals:request` |  |
| POST | `/api/approvals/{id}/cancel` | `approvals:request` |  |
| POST | `/api/approvals/{id}/decide` | `approvals:decide` |  |
| GET | `/api/audit` | `audit:read` |  |
| GET | `/api/audit/verify` | `audit:read` |  |
| POST | `/api/auth/change-password` | `any signed-in` |  |
| POST | `/api/auth/login` | `public` |  |
| POST | `/api/auth/logout` | `any signed-in` |  |
| GET | `/api/auth/me` | `any signed-in` |  |
| POST | `/api/auth/rotate` | `any signed-in` |  |
| POST | `/api/backups` | `backups:manage` | platform-root only |
| POST | `/api/backups/{id}/verify` | `backups:manage` | platform-root only |
| PUT | `/api/backups/policy` | `backups:manage` | platform-root only |
| GET | `/api/backups/status` | `backups:read` | platform-root only |
| GET | `/api/chat/threads` | `chat:use` |  |
| POST | `/api/chat/threads` | `chat:use` |  |
| GET | `/api/chat/threads/{id}/messages` | `chat:use` |  |
| POST | `/api/chat/threads/{id}/messages` | `chat:use` |  |
| GET | `/api/clients` | `clients:read` |  |
| POST | `/api/clients` | `clients:write` |  |
| DELETE | `/api/clients/{id}` | `clients:delete` |  |
| GET | `/api/clients/{id}` | `clients:read` |  |
| PATCH | `/api/clients/{id}` | `clients:write` |  |
| GET | `/api/employees` | `employees:read` |  |
| POST | `/api/employees` | `employees:manage` |  |
| GET | `/api/employees/{id}` | `employees:read` |  |
| PATCH | `/api/employees/{id}` | `employees:manage` |  |
| POST | `/api/employees/{id}/activate` | `employees:manage` |  |
| POST | `/api/employees/{id}/deactivate` | `employees:manage` |  |
| POST | `/api/employees/{id}/reset-password` | `employees:manage` |  |
| GET | `/api/export/{entity}.{csv|pdf}` | `any signed-in` |  |
| GET | `/api/export/executive-summary.{csv|pdf}` | `summary:read` |  |
| GET | `/api/exports` | `audit:read` |  |
| GET | `/api/health` | `public` |  |
| GET | `/api/health/detail` | `audit:read` |  |
| GET | `/api/hq/employees/{id}` | `hq:read` |  |
| GET | `/api/hq/state` | `hq:read` |  |
| GET | `/api/hq/summary` | `summary:read` |  |
| GET | `/api/knowledge-items` | `knowledge_items:read` |  |
| POST | `/api/knowledge-items` | `knowledge_items:write` |  |
| DELETE | `/api/knowledge-items/{id}` | `knowledge_items:delete` |  |
| GET | `/api/knowledge-items/{id}` | `knowledge_items:read` |  |
| PATCH | `/api/knowledge-items/{id}` | `knowledge_items:write` |  |
| GET | `/api/leads` | `leads:read` |  |
| POST | `/api/leads` | `leads:write` |  |
| DELETE | `/api/leads/{id}` | `leads:delete` |  |
| GET | `/api/leads/{id}` | `leads:read` |  |
| PATCH | `/api/leads/{id}` | `leads:write` |  |
| GET | `/api/projects` | `projects:read` |  |
| POST | `/api/projects` | `projects:write` |  |
| DELETE | `/api/projects/{id}` | `projects:delete` |  |
| GET | `/api/projects/{id}` | `projects:read` |  |
| PATCH | `/api/projects/{id}` | `projects:write` |  |
| GET | `/api/reference` | `reference:read` |  |
| GET | `/api/research-reports` | `research_reports:read` |  |
| POST | `/api/research-reports` | `research_reports:write` |  |
| DELETE | `/api/research-reports/{id}` | `research_reports:delete` |  |
| GET | `/api/research-reports/{id}` | `research_reports:read` |  |
| PATCH | `/api/research-reports/{id}` | `research_reports:write` |  |
| POST | `/api/retention/dry-run` | `retention:manage` |  |
| GET | `/api/retention/rules` | `retention:read` |  |
| PUT | `/api/retention/rules` | `retention:manage` |  |
| GET | `/api/retention/runs` | `retention:read` |  |
| POST | `/api/retention/runs/{id}/cancel` | `retention:manage` |  |
| POST | `/api/retention/runs/{id}/execute` | `retention:manage` |  |
| GET | `/api/tasks` | `tasks:read` |  |
| POST | `/api/tasks` | `tasks:write` |  |
| DELETE | `/api/tasks/{id}` | `tasks:delete` |  |
| GET | `/api/tasks/{id}` | `tasks:read` |  |
| PATCH | `/api/tasks/{id}` | `tasks:write` |  |
| POST | `/api/tasks/{id}/assign` | `tasks:write` |  |
| POST | `/api/tasks/{id}/transition` | `tasks:write` |  |
| GET | `/api/time-entries` | `time_entries:read` |  |
| POST | `/api/time-entries` | `time_entries:write` |  |
| DELETE | `/api/time-entries/{id}` | `time_entries:write` |  |

_76 endpoints._


## 8. Known limitations (stated plainly)
1. Single-process SQLite — right for one executive workspace; plan Postgres + shared session/rate-limit store before multi-node.
2. No TLS, SSO/MFA or email delivery yet. **MFA for the CEO/CTO account is the next security item I recommend.**
3. Pre-cleanup backups and archives contain pre-deletion data by design; they are 0600/0700 and rotated, but retention "erases" data only from the live DB until those rotate out.
4. PDFs use DejaVu Sans if no Arabic font is configured; set `REALHQ_PDF_FONT` to Cairo/Noto Naskh for brand-quality typography. Very long wrapped Arabic cells are truncated at 160 chars.
5. Research/web-search workers, AI calls and the SSRF-safe fetcher are not built in this phase (no external calls exist yet, so there is no injection/SSRF surface); data model and inert-text storage are ready.
6. Tenant isolation is verified for the main read/write paths by tests; a second company has no provisioning API yet (by design: CEO-only, to be added with unit management).
