"""Offline admin CLI (run on the server host).  python -m server.admin <command>"""
import argparse, getpass, sys
from .server import App
from . import security as sec, audit, backup
from .db import utcnow, one


def main():
    ap = argparse.ArgumentParser(prog="server.admin"); sub = ap.add_subparsers(dest="cmd", required=True)
    for n in ("reset-password", "unlock"): sub.add_parser(n).add_argument("username")
    sub.add_parser("backup-now"); sub.add_parser("verify-audit")
    a = ap.parse_args(); app = App()
    c = app.db.conn()
    if a.cmd in ("reset-password", "unlock"):
        e = one(c, "SELECT * FROM employees WHERE username=? AND company_id=1", (a.username,))
        if not e: sys.exit("no such user")
        with app.db.tx() as w:
            if a.cmd == "reset-password":
                pw = getpass.getpass("New temporary password: ")
                if pw != getpass.getpass("Repeat: "): sys.exit("mismatch")
                p = sec.password_problems(pw, e["username"], e["email"])
                if p: sys.exit("weak password: " + ", ".join(p))
                w.execute("UPDATE employees SET password_hash=?, must_change_password=1, failed_attempts=0, locked_until=NULL, is_active=1 WHERE id=?", (sec.hash_password(pw, app.cfg.pbkdf2_iters), e["id"]))
                sec.revoke_all(w, e["id"])
            else: w.execute("UPDATE employees SET failed_attempts=0, locked_until=NULL WHERE id=?", (e["id"],))
            audit.log(w, app.audit_key, 1, None, "cli-admin", f"employee.{a.cmd.replace('-', '_')}", "employee", e["id"], {"via": "offline CLI"})
        print("done")
    elif a.cmd == "backup-now": print(backup.run_backup(app, "manual", "cli-admin"))
    else:
        for r in c.execute("SELECT id FROM companies"): print(r[0], audit.verify_chain(c, app.audit_key, r[0]))


if __name__ == "__main__": main()
