"""HTTP-agnostic plumbing: errors (bilingual), routing registry, request object, input validation."""
import json, re, datetime

MESSAGES = {  # code: (http, English, Arabic)
    "BAD_REQUEST": (400, "Invalid request.", "طلب غير صالح."),
    "VALIDATION": (422, "Validation failed.", "فشل التحقق من البيانات."),
    "WEAK_PASSWORD": (422, "Password does not meet the security policy.", "كلمة المرور لا تستوفي سياسة الأمان."),
    "UNAUTHENTICATED": (401, "Authentication required.", "يلزم تسجيل الدخول."),
    "INVALID_CREDENTIALS": (401, "Invalid credentials.", "بيانات الدخول غير صحيحة."),
    "FORBIDDEN": (403, "You do not have permission for this action.", "ليست لديك صلاحية لهذا الإجراء."),
    "CSRF": (403, "Request origin could not be verified.", "تعذر التحقق من مصدر الطلب."),
    "PASSWORD_CHANGE_REQUIRED": (403, "You must change your password first.", "يجب تغيير كلمة المرور أولاً."),
    "NOT_FOUND": (404, "Not found.", "غير موجود."),
    "METHOD_NOT_ALLOWED": (405, "Method not allowed.", "الطريقة غير مسموحة."),
    "CONFLICT": (409, "Conflict with current state.", "تعارض مع الحالة الحالية."),
    "INVALID_TRANSITION": (409, "This state transition is not allowed.", "الانتقال بين الحالات غير مسموح."),
    "EXTERNAL_ACTION_NOT_APPROVED": (409, "External actions require an approved CEO/CTO approval before completion.", "الإجراءات الخارجية تتطلب موافقة معتمدة من الرئيس التنفيذي قبل الإنجاز."),
    "LAST_CEO": (409, "The last active CEO/CTO account cannot be removed or demoted.", "لا يمكن تعطيل أو خفض آخر حساب فعّال للرئيس التنفيذي."),
    "CONFIRMATION_REQUIRED": (409, "Explicit confirmation phrase is required.", "يلزم إدخال عبارة التأكيد الصريحة."),
    "PAYLOAD_TOO_LARGE": (413, "Request body too large.", "حجم الطلب كبير جدًا."),
    "UNSUPPORTED_MEDIA": (415, "Content-Type must be application/json.", "يجب أن يكون نوع المحتوى application/json."),
    "RATE_LIMITED": (429, "Too many requests. Try again later.", "طلبات كثيرة جدًا. حاول لاحقًا."),
    "PDF_UNAVAILABLE": (501, "PDF generation is not available on this server.", "إنشاء ملفات PDF غير متاح على هذا الخادم."),
    "BACKUP_FAILED": (500, "Backup failed.", "فشل النسخ الاحتياطي."),
    "INTERNAL": (500, "Internal server error.", "خطأ داخلي في الخادم."),
}


class ApiError(Exception):
    def __init__(self, code, details=None):
        self.code, self.details = code, details
        self.status, self.en, self.ar = MESSAGES.get(code, MESSAGES["INTERNAL"])


class JSON:
    def __init__(self, data, status=200, headers=None): self.data, self.status, self.headers = data, status, headers or {}
class Raw:
    def __init__(self, body, ctype, filename=None, status=200, headers=None): self.body, self.ctype, self.filename, self.status, self.headers = body, ctype, filename, status, headers or {}


ROUTES = []


def route(method, pattern, perm=None, auth=True, root_only=False):
    def conv(m):
        n = m.group(1)
        if n == "fmt": return "(?P<fmt>csv|pdf)"
        if n == "id" or n.endswith("_id"): return f"(?P<{n}>\\d+)"
        return f"(?P<{n}>[a-z0-9_\\-]+)"
    rx = re.compile(re.sub(r"\{(\w+)\}", conv, pattern.replace(".", "\\.")))
    def deco(fn):
        ROUTES.append((method, rx, fn, dict(perm=perm, auth=auth, root_only=root_only)))
        return fn
    return deco


class Request:
    def __init__(self, app, method, path, query, body, ip, headers, ctx, params):
        self.app, self.method, self.path, self.query, self.body, self.ip = app, method, path, query, body, ip
        self.headers, self.ctx, self.params = headers, ctx, params
        self.cfg = app.cfg
    @property
    def c(self): return self.app.db.conn()
    def tx(self): return self.app.db.tx()
    @property
    def cid(self): return self.ctx["company_id"]
    @property
    def role(self): return self.ctx["rbac_role"]
    @property
    def uid(self): return self.ctx["employee_id"]
    def audit(self, c, action, etype=None, eid=None, summary=None, company_id=None):
        from . import audit
        audit.log(c, self.app.audit_key, company_id or self.cid, self.ctx["employee_id"], self.ctx["username"], action, etype, eid, summary, self.ip)
    def id(self, name="id"): return int(self.params[name])


# ---------------- validation ----------------
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _conv(kind, v, o):
    if kind in ("str", "text"):
        if not isinstance(v, str): raise ValueError("string expected")
        v = v.strip()
        if _CTRL.search(v): raise ValueError("control characters not allowed")
        if len(v) < o.get("min", 1 if o.get("req") else 0): raise ValueError("too short")
        if len(v) > o.get("max", 200): raise ValueError(f"max {o.get('max', 200)} chars")
        if o.get("pattern") and not re.fullmatch(o["pattern"], v): raise ValueError("invalid format")
        return v
    if kind == "enum":
        if v not in o["values"]: raise ValueError("one of: " + ", ".join(o["values"]))
        return v
    if kind in ("int", "ref"):
        if isinstance(v, bool) or not isinstance(v, int): raise ValueError("integer expected")
        if v < o.get("min", 0) or v > o.get("max", 2**31): raise ValueError("out of range")
        return v
    if kind == "float":
        if isinstance(v, bool) or not isinstance(v, (int, float)): raise ValueError("number expected")
        if v < o.get("min", 0) or v > o.get("max", 1e12): raise ValueError("out of range")
        return float(v)
    if kind == "bool":
        if not isinstance(v, bool): raise ValueError("boolean expected")
        return 1 if v else 0
    if kind == "date":
        try: datetime.date.fromisoformat(v)
        except Exception: raise ValueError("YYYY-MM-DD expected")
        return v
    if kind == "idlist":
        if not isinstance(v, list) or len(v) > 50 or any(isinstance(x, bool) or not isinstance(x, int) for x in v): raise ValueError("list of ids (max 50)")
        return v
    raise ValueError("bad spec")


def clean(data, spec, partial=False):
    """Whitelist validation: unknown fields are rejected (mass-assignment protection)."""
    if not isinstance(data, dict): raise ApiError("VALIDATION", {"_": "JSON object expected"})
    errs = {k: "unknown field" for k in data if k not in spec}
    out = {}
    for k, (kind, o) in spec.items():
        if k not in data:
            if not partial and o.get("req"): errs[k] = "required"
            elif not partial and "default" in o: out[k] = o["default"]
            continue
        v = data[k]
        if v is None and not o.get("req"): out[k] = None; continue
        try: out[k] = _conv(kind, v, o)
        except ValueError as e: errs[k] = str(e)
    if errs: raise ApiError("VALIDATION", errs)
    return out


def check_refs(c, company_id, out, spec):
    """Every foreign key must point to a row in the SAME company (tenant isolation)."""
    errs = {}
    for k, (kind, o) in spec.items():
        if kind == "ref" and out.get(k) is not None:
            extra = " AND is_active=1" if o["table"] == "employees" else ""
            if not c.execute(f"SELECT 1 FROM {o['table']} WHERE id=? AND company_id=?{extra}", (out[k], company_id)).fetchone():
                errs[k] = "does not exist in your company"
    if errs: raise ApiError("VALIDATION", errs)


def page(req, default=50):
    try: limit = max(1, min(200, int(req.query.get("limit", default)))); offset = max(0, int(req.query.get("offset", 0)))
    except ValueError: raise ApiError("BAD_REQUEST")
    return limit, offset


def like(q): return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
