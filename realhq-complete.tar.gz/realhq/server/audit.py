"""Tamper-evident audit log: per-company HMAC-SHA256 hash chain, append-only via DB triggers."""
import hashlib, hmac, json, os, re, secrets
from .db import utcnow

_SENSITIVE = re.compile(r"pass|token|secret|hash|csrf|cookie", re.I)


def load_key(cfg):
    p = cfg.secrets_dir / "audit_hmac.key"
    if not p.exists():
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f: f.write(secrets.token_hex(32))
    return p.read_text().strip().encode()


def redact(v, depth=0):
    if depth > 4: return "…"
    if isinstance(v, dict): return {k: ("[redacted]" if _SENSITIVE.search(str(k)) else redact(x, depth + 1)) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [redact(x, depth + 1) for x in v[:50]]
    if isinstance(v, str): return v if len(v) <= 300 else v[:300] + "…"
    return v


def _canon(company_id, seq, ts, actor_id, actor_username, action, etype, eid, summary, ip, prev):
    return json.dumps([company_id, seq, ts, actor_id, actor_username, action, etype, eid, summary, ip, prev],
                      separators=(",", ":"), ensure_ascii=True)


def log(c, key, company_id, actor_id, actor_username, action, entity_type=None, entity_id=None, summary=None, ip=None):
    """Must be called inside the caller's write transaction so the entry is atomic with the change."""
    last = c.execute("SELECT seq, entry_hash FROM audit_log WHERE company_id=? ORDER BY seq DESC LIMIT 1", (company_id,)).fetchone()
    seq, prev = (last["seq"] + 1, last["entry_hash"]) if last else (1, "GENESIS")
    ts = utcnow()
    s = json.dumps(redact(summary or {}), ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    eid = None if entity_id is None else str(entity_id)
    h = hmac.new(key, _canon(company_id, seq, ts, actor_id, actor_username, action, entity_type, eid, s, ip, prev).encode(), hashlib.sha256).hexdigest()
    c.execute("INSERT INTO audit_log(company_id,seq,ts,actor_id,actor_username,action,entity_type,entity_id,summary_json,ip,prev_hash,entry_hash)"
              " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (company_id, seq, ts, actor_id, actor_username, action, entity_type, eid, s, ip, prev, h))


def verify_chain(c, key, company_id):
    prev, n = "GENESIS", 0
    for r in c.execute("SELECT * FROM audit_log WHERE company_id=? ORDER BY seq", (company_id,)):
        n += 1
        exp = hmac.new(key, _canon(r["company_id"], r["seq"], r["ts"], r["actor_id"], r["actor_username"], r["action"], r["entity_type"],
                                   r["entity_id"], r["summary_json"], r["ip"], prev).encode(), hashlib.sha256).hexdigest()
        if r["seq"] != n or r["prev_hash"] != prev or not hmac.compare_digest(exp, r["entry_hash"]):
            return {"ok": False, "entries": n, "first_bad_seq": r["seq"]}
        prev = r["entry_hash"]
    return {"ok": True, "entries": n, "first_bad_seq": None}
