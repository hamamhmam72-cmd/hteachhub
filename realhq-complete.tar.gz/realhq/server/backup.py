"""Online SQLite backups (sqlite3 backup API), integrity verification, rotation, restore verification."""
import hashlib, json, os, shutil, sqlite3, tempfile, time
from pathlib import Path
from .db import connect, rows, one, utcnow
from . import audit

INTERVALS = {"hourly": 3600, "daily": 86400, "weekly": 604800}


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()


def _audit_system(app, actor, action, rid, summary):
    with app.db.tx() as w:
        audit.log(w, app.audit_key, 1, None, actor or "system", action, "backup", rid, summary)


def run_backup(app, kind="manual", actor=None):
    cfg, db = app.cfg, app.db
    with db.tx() as w:
        rid = w.execute("INSERT INTO backup_runs(kind,status,started_at,triggered_by) VALUES(?,?,?,?)", (kind, "running", utcnow(), actor or "system")).lastrowid
    final = cfg.backup_dir / f"realhq-{kind}-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}-{rid}.db"; tmp = final.with_suffix(".tmp")
    try:
        dst = sqlite3.connect(tmp); db.conn().backup(dst); dst.close()           # consistent snapshot even under concurrent writes
        chk = connect(tmp, readonly=True)
        ok = chk.execute("PRAGMA integrity_check").fetchone()[0]; chk.close()
        if ok != "ok": raise RuntimeError(f"integrity_check failed: {ok}")
        os.chmod(tmp, 0o600); os.replace(tmp, final)
        sha, size = _sha(final), final.stat().st_size
        (final.with_suffix(".db.sha256")).write_text(f"{sha}  {final.name}\n")
        with db.tx() as w:
            w.execute("UPDATE backup_runs SET status='completed', path=?, size_bytes=?, sha256=?, finished_at=? WHERE id=?", (str(final), size, sha, utcnow(), rid))
        _audit_system(app, actor, "backup.create", rid, {"kind": kind, "size_bytes": size, "sha256": sha})
        rotate(app)
        return one(db.conn(), "SELECT * FROM backup_runs WHERE id=?", (rid,))
    except Exception as e:
        tmp.unlink(missing_ok=True)
        with db.tx() as w: w.execute("UPDATE backup_runs SET status='failed', error=?, finished_at=? WHERE id=?", (str(e)[:500], utcnow(), rid))
        _audit_system(app, actor, "backup.failed", rid, {"kind": kind, "error": str(e)[:200]})
        raise


def rotate(app):
    keep = {"scheduled": policy(app)["keep_count"], "manual": app.cfg.keep_manual_backups, "pre_cleanup": app.cfg.keep_precleanup_backups}
    c = app.db.conn()
    for kind, n in keep.items():
        old = rows(c, "SELECT id,path FROM backup_runs WHERE kind=? AND status='completed' ORDER BY id DESC LIMIT -1 OFFSET ?", (kind, n))
        for r in old:
            p = Path(r["path"] or "")
            if p.parent == app.cfg.backup_dir:  # never delete outside the backup dir
                p.unlink(missing_ok=True); p.with_suffix(".db.sha256").unlink(missing_ok=True)
            with app.db.tx() as w: w.execute("UPDATE backup_runs SET status='rotated' WHERE id=?", (r["id"],))


def policy(app): return one(app.db.conn(), "SELECT * FROM backup_policy WHERE id=1")


def verify_backup(app, rid, actor):
    """Controlled restore verification: restores the snapshot into a temp dir (NOT over the live DB) and checks it."""
    r = one(app.db.conn(), "SELECT * FROM backup_runs WHERE id=?", (rid,))
    if not r or r["status"] != "completed": return {"ok": False, "error": "backup not available"}
    p = Path(r["path"])
    res = {"ok": False, "checks": {}}
    try:
        if not p.exists(): raise RuntimeError("file missing")
        res["checks"]["sha256_matches"] = _sha(p) == r["sha256"]
        with tempfile.TemporaryDirectory(dir=app.cfg.data_dir) as td:
            t = Path(td) / "restore.db"; shutil.copy2(p, t); os.chmod(t, 0o600)
            c = connect(t, readonly=True)
            res["checks"]["integrity_check"] = c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            res["checks"]["foreign_keys"] = c.execute("PRAGMA foreign_key_check").fetchone() is None
            res["checks"]["audit_chain"] = all(audit.verify_chain(c, app.audit_key, x[0])["ok"] for x in c.execute("SELECT id FROM companies"))
            res["rows"] = {tb: c.execute(f"SELECT count(*) FROM {tb}").fetchone()[0] for tb in ("companies", "employees", "tasks", "clients", "audit_log")}
            c.close()
        res["ok"] = all(res["checks"].values())
    except Exception as e:
        res["error"] = str(e)[:200]
    with app.db.tx() as w:
        w.execute("UPDATE backup_runs SET verified_at=?, verify_result=? WHERE id=?", (utcnow(), json.dumps(res), rid))
    _audit_system(app, actor, "backup.restore_verify", rid, {"ok": res["ok"], "checks": res["checks"]})
    return res
