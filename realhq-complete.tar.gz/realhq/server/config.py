"""Central configuration. Everything sensitive comes from environment variables, never from client input."""
import os
from pathlib import Path


def _int(name, default, lo=None, hi=None):
    try:
        v = int(os.environ.get(name, default))
    except ValueError:
        v = default
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _bool(name, default):
    v = os.environ.get(name)
    return default if v is None else v.strip().lower() in ("1", "true", "yes", "on")


class Config:
    def __init__(self):
        e = os.environ
        self.env = e.get("REALHQ_ENV", "production")
        self.host = e.get("REALHQ_HOST", "127.0.0.1")
        self.port = _int("REALHQ_PORT", 8080, 0, 65535)
        self.data_dir = Path(e.get("REALHQ_DATA_DIR", "./data")).resolve()
        self.db_path = self.data_dir / "realhq.db"
        self.backup_dir = Path(e.get("REALHQ_BACKUP_DIR", str(self.data_dir / "backups"))).resolve()
        self.archive_dir = self.data_dir / "archives"
        self.secrets_dir = self.data_dir / "secrets"
        self.default_company_slug = e.get("REALHQ_DEFAULT_COMPANY", "h-teach-hub")
        self.seed_demo = _bool("REALHQ_SEED_DEMO", True)
        self.bootstrap_password = e.get("REALHQ_BOOTSTRAP_PASSWORD")
        # --- auth / sessions
        self.pbkdf2_iters = _int("REALHQ_PBKDF2_ITERS", 600_000, 100_000)  # OWASP 2023 guidance for PBKDF2-SHA256
        self.cookie_name = "rhq_session"
        self.cookie_secure = _bool("REALHQ_COOKIE_SECURE", self.env != "development")
        self.session_abs_seconds = _int("REALHQ_SESSION_ABS", 12 * 3600, 600)
        self.session_idle_seconds = _int("REALHQ_SESSION_IDLE", 2 * 3600, 300)
        self.lockout_threshold = _int("REALHQ_LOCKOUT_THRESHOLD", 5, 3)
        self.lockout_seconds = _int("REALHQ_LOCKOUT_SECONDS", 900, 60)
        self.trust_proxy = _bool("REALHQ_TRUST_PROXY", False)
        # --- request limits
        self.max_body = _int("REALHQ_MAX_BODY", 1_000_000, 1024, 10_000_000)
        self.socket_timeout = _int("REALHQ_SOCKET_TIMEOUT", 30, 5)
        self.login_ip_limit = _int("REALHQ_LOGIN_IP_LIMIT", 20, 3)       # attempts / 10 min / IP
        self.global_ip_limit = _int("REALHQ_GLOBAL_IP_LIMIT", 600, 30)   # requests / min / IP
        self.max_concurrent = _int("REALHQ_MAX_CONCURRENT", 64, 4)
        # --- lifecycle
        self.min_retention_days = _int("REALHQ_MIN_RETENTION_DAYS", 365, 30)
        self.cleanup_plan_ttl_days = 7
        self.keep_manual_backups = 30
        self.keep_precleanup_backups = 30
        self.export_row_cap_csv = 50_000
        self.export_row_cap_pdf = 5_000
        self.pdf_font = e.get("REALHQ_PDF_FONT")  # optional path to an Arabic-capable TTF

    def ensure_dirs(self):
        for d in (self.data_dir, self.backup_dir, self.archive_dir, self.secrets_dir):
            d.mkdir(parents=True, exist_ok=True)
            os.chmod(d, 0o700)
