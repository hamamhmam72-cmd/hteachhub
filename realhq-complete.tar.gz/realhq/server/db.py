import os, sqlite3, threading, datetime as _dt
from contextlib import contextmanager
from pathlib import Path

SCHEMA_VERSION = 1


def utcnow():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def iso_after(seconds=0, days=0):
    return (_dt.datetime.now(_dt.timezone.utc) + _dt.timedelta(seconds=seconds, days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")


def iso_before(days):
    return iso_after(days=-days)


def rows(c, sql, args=()):
    return [dict(r) for r in c.execute(sql, args).fetchall()]


def one(c, sql, args=()):
    r = c.execute(sql, args).fetchone()
    return dict(r) if r else None


def connect(path, readonly=False):
    uri = f"file:{path}?mode=ro" if readonly else f"file:{path}"
    c = sqlite3.connect(uri, uri=True, isolation_level=None, timeout=10, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=10000")
    if not readonly:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA secure_delete=ON")  # purged rows are overwritten, not merely unlinked
    return c


class Database:
    """One connection per thread. ALL writes are serialized through a process-wide lock + BEGIN IMMEDIATE,
    so a mutation and its audit-log entry commit (or roll back) atomically."""

    def __init__(self, cfg):
        self.cfg = cfg
        self._local = threading.local()
        self._wlock = threading.RLock()

    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = self._local.c = connect(self.cfg.db_path)
        return c

    @contextmanager
    def tx(self):
        with self._wlock:
            c = self.conn()
            c.execute("BEGIN IMMEDIATE")
            try:
                yield c
                c.execute("COMMIT")
            except BaseException:
                try:
                    c.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise

    def init_schema(self):
        c = self.conn()
        fresh = c.execute("PRAGMA user_version").fetchone()[0] == 0
        if fresh:
            c.executescript(Path(__file__).with_name("schema.sql").read_text(encoding="utf-8"))
            c.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        os.chmod(self.cfg.db_path, 0o600)
        return fresh
