"""CSV (UTF-8 BOM, formula-injection safe) and PDF (bilingual / RTL-safe) exports + executive summary."""
import csv, datetime, hashlib, io, json, re
from xml.sax.saxutils import escape
from .api import ApiError
from .db import rows, one, utcnow
from .rbac import CLEARANCE

C = lambda k, en, ar: (k, en, ar)
ENT = {
 "tasks": dict(perm="export:tasks", a="t", cls="t.classification", status="t.status", date="t.created_at",
   sql="SELECT t.id,t.title,t.status,t.priority,e.username AS assignee,p.name AS project,t.due_date,t.external_action,t.classification,t.created_at,t.closed_at FROM tasks t LEFT JOIN employees e ON e.id=t.assignee_id LEFT JOIN projects p ON p.id=t.project_id",
   cols=[C("id","ID","المعرف"),C("title","Title","العنوان"),C("status","Status","الحالة"),C("priority","Priority","الأولوية"),C("assignee","Assignee","المكلّف"),C("project","Project","المشروع"),C("due_date","Due","الاستحقاق"),C("external_action","External action","إجراء خارجي"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("closed_at","Closed","أُغلق")],
   pdf=["id","title","status","priority","assignee","due_date","classification"]),
 "clients": dict(perm="export:clients", a="x", cls="x.classification", status="x.status", date="x.created_at",
   sql="SELECT x.id,x.name,x.contact_email,x.status,x.pinned,x.classification,x.created_at,x.closed_at FROM clients x",
   cols=[C("id","ID","المعرف"),C("name","Name","الاسم"),C("contact_email","Email","البريد"),C("status","Status","الحالة"),C("pinned","Pinned","مثبّت"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("closed_at","Closed","أُغلق")],
   pdf=["id","name","contact_email","status","classification","created_at"]),
 "leads": dict(perm="export:leads", a="x", cls="x.classification", status="x.status", date="x.created_at",
   sql="SELECT x.id,x.name,x.source,x.status,x.est_value,x.classification,x.created_at,x.closed_at FROM leads x",
   cols=[C("id","ID","المعرف"),C("name","Name","الاسم"),C("source","Source","المصدر"),C("status","Status","الحالة"),C("est_value","Est. value","القيمة التقديرية"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("closed_at","Closed","أُغلق")],
   pdf=["id","name","source","status","est_value","classification"]),
 "projects": dict(perm="export:projects", a="x", cls="x.classification", status="x.status", date="x.created_at",
   sql="SELECT x.id,x.name,x.status,x.start_date,x.due_date,x.classification,x.created_at,x.closed_at FROM projects x",
   cols=[C("id","ID","المعرف"),C("name","Name","الاسم"),C("status","Status","الحالة"),C("start_date","Start","البداية"),C("due_date","Due","الاستحقاق"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("closed_at","Closed","أُغلق")],
   pdf=["id","name","status","due_date","classification"]),
 "approvals": dict(perm="export:approvals", a="x", cls="x.classification", status="x.status", date="x.created_at",
   sql="SELECT x.id,x.kind,x.title,x.status,r.username AS requested_by,d.username AS decided_by,x.decision_note,x.classification,x.created_at,x.decided_at FROM approvals x LEFT JOIN employees r ON r.id=x.requested_by LEFT JOIN employees d ON d.id=x.decided_by",
   cols=[C("id","ID","المعرف"),C("kind","Kind","النوع"),C("title","Title","العنوان"),C("status","Status","الحالة"),C("requested_by","Requested by","طالب الموافقة"),C("decided_by","Decided by","صاحب القرار"),C("decision_note","Note","ملاحظة"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("decided_at","Decided","تاريخ القرار")],
   pdf=["id","kind","title","status","requested_by","decided_by","created_at"]),
 "time_entries": dict(perm="export:time_entries", a="x", cls="t.classification", status=None, date="x.created_at",
   sql="SELECT x.id,x.task_id,t.title AS task,e.username AS employee,x.minutes,x.work_date,x.note,x.created_at FROM time_entries x JOIN tasks t ON t.id=x.task_id JOIN employees e ON e.id=x.employee_id",
   cols=[C("id","ID","المعرف"),C("task_id","Task ID","رقم المهمة"),C("task","Task","المهمة"),C("employee","Employee","الموظف"),C("minutes","Minutes","الدقائق"),C("work_date","Date","التاريخ"),C("note","Note","ملاحظة"),C("created_at","Created","أُنشئ")],
   pdf=["id","task","employee","minutes","work_date"]),
 "knowledge_items": dict(perm="export:knowledge_items", a="x", cls="x.classification", status=None, date="x.created_at",
   sql="SELECT x.id,x.title,x.tags,x.pinned,x.classification,x.created_at,x.updated_at FROM knowledge_items x",
   cols=[C("id","ID","المعرف"),C("title","Title","العنوان"),C("tags","Tags","الوسوم"),C("pinned","Pinned","مثبّت"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("updated_at","Updated","حُدّث")],
   pdf=["id","title","tags","pinned","classification"]),
 "research_reports": dict(perm="export:research_reports", a="x", cls="x.classification", status="x.status", date="x.created_at",
   sql="SELECT x.id,x.title,x.query,x.status,x.summary,x.classification,x.created_at,x.updated_at FROM research_reports x",
   cols=[C("id","ID","المعرف"),C("title","Title","العنوان"),C("query","Query","الاستعلام"),C("status","Status","الحالة"),C("summary","Summary","الملخص"),C("classification","Classification","التصنيف"),C("created_at","Created","أُنشئ"),C("updated_at","Updated","حُدّث")],
   pdf=["id","title","status","summary","classification"]),
 "employees": dict(perm="export:employees", a="x", cls=None, const_cls="confidential", status=None, date="x.created_at",
   sql="SELECT x.id,x.username,x.email,x.display_name_en,x.display_name_ar,x.role_en,x.role_ar,x.rbac_role,d.name_en AS department_en,d.name_ar AS department_ar,x.is_active,x.last_login_at,x.created_at FROM employees x LEFT JOIN departments d ON d.id=x.department_id",
   cols=[C("id","ID","المعرف"),C("username","Username","اسم المستخدم"),C("email","Email","البريد"),C("display_name_en","Name (EN)","الاسم (إنجليزي)"),C("display_name_ar","Name (AR)","الاسم (عربي)"),C("role_en","Title (EN)","المسمى (إنجليزي)"),C("role_ar","Title (AR)","المسمى (عربي)"),C("rbac_role","Access role","دور الوصول"),C("department_en","Department (EN)","القسم (إنجليزي)"),C("department_ar","Department (AR)","القسم (عربي)"),C("is_active","Active","فعّال"),C("last_login_at","Last login","آخر دخول"),C("created_at","Created","أُنشئ")],
   pdf=["username","display_name_en","display_name_ar","role_en","rbac_role","is_active"]),
 "audit_log": dict(perm="export:audit_log", a="x", cls=None, const_cls="restricted", status=None, date="x.ts",
   sql="SELECT x.seq,x.ts,x.actor_username,x.action,x.entity_type,x.entity_id,x.summary_json,x.ip,substr(x.entry_hash,1,16) AS hash_prefix FROM audit_log x",
   cols=[C("seq","Seq","التسلسل"),C("ts","Time (UTC)","الوقت (UTC)"),C("actor_username","Actor","المنفّذ"),C("action","Action","الإجراء"),C("entity_type","Entity","الكيان"),C("entity_id","Entity ID","معرّف الكيان"),C("summary_json","Summary","الملخص"),C("ip","IP","العنوان"),C("hash_prefix","Hash","البصمة")],
   pdf=["seq","ts","actor_username","action","entity_type","entity_id"]),
}
ORDER_RANK = {"internal": 0, "confidential": 1, "restricted": 2}


def _filters(q):
    f = {}
    if q.get("status"):
        if not re.fullmatch(r"[a-z_]{1,30}", q["status"]): raise ApiError("BAD_REQUEST")
        f["status"] = q["status"]
    for k in ("since", "until"):
        if q.get(k):
            try: datetime.date.fromisoformat(q[k])
            except ValueError: raise ApiError("BAD_REQUEST", {k: "YYYY-MM-DD"})
            f[k] = q[k]
    if q.get("classification"):
        if q["classification"] not in ORDER_RANK: raise ApiError("BAD_REQUEST")
        f["classification"] = q["classification"]
    return f


def neutralize(v):
    """Defuse spreadsheet formula injection (=,+,-,@, tab, CR) in every text cell."""
    if isinstance(v, str) and v.lstrip()[:1] in ("=", "+", "-", "@", "\t", "\r"): return "'" + v
    return v


def _query(app, ctx, name, f, cap):
    e = ENT[name]; where, a = [], []
    if name == "audit_log": where.append("x.company_id=?"); a.append(ctx["company_id"])
    else: where.append(f"{e['a']}.company_id=?"); a.append(ctx["company_id"])
    if e["cls"]:
        cl = CLEARANCE[ctx["rbac_role"]]; where.append(f"{e['cls']} IN ({','.join('?' * len(cl))})"); a += list(cl)
        if f.get("classification"): where.append(f"{e['cls']}=?"); a.append(f["classification"])
    if f.get("status") and e["status"]: where.append(f"{e['status']}=?"); a.append(f["status"])
    if f.get("since"): where.append(f"{e['date']}>=?"); a.append(f["since"])
    if f.get("until"): where.append(f"{e['date']}<?"); a.append(f["until"] + "T99")
    order = "x.seq" if name == "audit_log" else f"{e['a']}.id"
    data = rows(app.db.conn(), f"{e['sql']} WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ?", a + [cap + 1])
    return data[:cap], len(data) > cap


def _labels(cols, lang):
    return [(f"{en} / {ar}" if lang == "bi" else ar if lang == "ar" else en) for _, en, ar in cols]


def _classification(name, data):
    e = ENT[name]
    if not e["cls"]: return e["const_cls"]
    return max((r["classification"] for r in data), key=ORDER_RANK.get, default="internal")


def make_csv(cols, data, lang):
    buf = io.StringIO(); w = csv.writer(buf, lineterminator="\r\n"); w.writerow(_labels(cols, lang))
    for r in data: w.writerow([neutralize(r[k]) for k, _, _ in cols])
    return buf.getvalue().encode("utf-8-sig")


# ---------------- PDF ----------------
_font = {}


def _fonts():
    if _font: return _font
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    import os
    cands = [os.environ.get("REALHQ_PDF_FONT"), "/usr/share/fonts/truetype/noto/NotoNaskhArabic-Regular.ttf", "/usr/share/fonts/truetype/amiri/Amiri-Regular.ttf",
             "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans.ttf", "/Library/Fonts/Arial Unicode.ttf", "C:/Windows/Fonts/arial.ttf"]
    for p in cands:
        if p and os.path.exists(p):
            pdfmetrics.registerFont(TTFont("RHQ", p)); _font.update(name="RHQ", unicode=True); return _font
    _font.update(name="Helvetica", unicode=False); return _font


_AR = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]")


def _shape(s):
    s = "" if s is None else str(s)
    if _fonts()["unicode"] and _AR.search(s):
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(s))
    return s if _fonts()["unicode"] else s.encode("latin-1", "replace").decode("latin-1")


def _cell(v, style, trunc=160):
    s = "" if v is None else str(v)
    return __import__("reportlab.platypus", fromlist=["Paragraph"]).Paragraph(escape(_shape(s[:trunc] + ("…" if len(s) > trunc else ""))), style)


def _doc(app, ctx, title_en, title_ar, lang, meta, header, body_rows, widths, banner):
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib import colors
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    except ImportError: raise ApiError("PDF_UNAVAILABLE")
    f = _fonts()["name"]; rtl = lang == "ar"; al = 2 if rtl else 0
    st = ParagraphStyle("b", fontName=f, fontSize=8, leading=10, alignment=al); hs = ParagraphStyle("h", parent=st, textColor=colors.white, fontSize=8)
    ts = ParagraphStyle("t", fontName=f, fontSize=16, leading=20, alignment=al, textColor=colors.HexColor("#0B0D10"))
    out = io.BytesIO(); page = landscape(A4); co = one(app.db.conn(), "SELECT name_ar,name_en FROM companies WHERE id=?", (ctx["company_id"],))
    def deco(cv, d):
        cv.saveState(); cv.setFont(f, 7); cv.setFillColor(colors.HexColor("#8a6d00"))
        cv.drawString(28, page[1] - 18, _shape(f"{banner.upper()}  ·  {co['name_en']}"))
        cv.setFillColor(colors.grey); cv.drawString(28, 16, f"RealHQ Studio · H-teach hub · {meta['generated']}"); cv.drawRightString(page[0] - 28, 16, f"{d.page}"); cv.restoreState()
    doc = SimpleDocTemplate(out, pagesize=page, leftMargin=28, rightMargin=28, topMargin=34, bottomMargin=30, title=title_en, author="RealHQ Studio")
    names = {"en": co["name_en"], "ar": co["name_ar"], "bi": f"{co['name_en']} / {co['name_ar']}"}[lang]
    title = {"en": title_en, "ar": title_ar, "bi": f"{title_en} / {title_ar}"}[lang]
    story = [Paragraph(escape(_shape(title)), ts), Spacer(1, 4)]
    mt = Table([([_cell(_ml(k, lang), st), _cell(v, st)][::-1] if rtl else [_cell(_ml(k, lang), st), _cell(v, st)]) for k, v in [(("Company", names))] + meta["rows"]], colWidths=([330, 130] if rtl else [130, 330]), hAlign="RIGHT" if rtl else "LEFT")
    mt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 1), ("TOPPADDING", (0, 0), (-1, -1), 1)]))
    story += [mt, Spacer(1, 8)]
    data = [[_cell(h, hs, 60) for h in header]] + [[_cell(v, st) for v in r] for r in body_rows]
    if rtl: data = [r[::-1] for r in data]; widths = widths[::-1]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="RIGHT" if rtl else "LEFT")
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#14181F")), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#c9ced6")),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f4f6f8")]), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(t); doc.build(story, onFirstPage=deco, onLaterPages=deco)
    return out.getvalue()


ML = {"Scope": "النطاق", "Generated (UTC)": "تاريخ الإنشاء (UTC)", "Generated by": "أنشأه", "Filters": "المرشحات", "Classification": "التصنيف", "Rows": "عدد الصفوف", "Company": "الشركة"}
TITLE_AR = {"tasks": "المهام", "clients": "العملاء", "leads": "العملاء المحتملون", "projects": "المشاريع", "approvals": "الموافقات", "time_entries": "سجلات الوقت",
            "knowledge_items": "قاعدة المعرفة", "research_reports": "تقارير البحث", "employees": "الموظفون", "audit_log": "سجل التدقيق"}


def _ml(label, lang):
    ar = ML.get(label, label)
    return {"en": label, "ar": ar, "bi": f"{label} / {ar}"}[lang]


def make_pdf(app, ctx, name, data, lang, f, truncated, cls):
    e = ENT[name]; cols = [c for c in e["cols"] if c[0] in e["pdf"]]; avail = 785; w = [avail / len(cols)] * len(cols)
    meta = {"generated": utcnow(), "rows": [("Scope", f"{name} · company #{ctx['company_id']}"), ("Generated (UTC)", utcnow()),
            ("Generated by", ctx["username"]), ("Filters", json.dumps(f) if f else "—"), ("Classification", cls), ("Rows", f"{len(data)}" + (" (truncated)" if truncated else ""))]}
    return _doc(app, ctx, name.replace("_", " ").title() + " Report", "تقرير " + TITLE_AR[name], lang, meta, _labels(cols, lang), [[r[k] for k, _, _ in cols] for r in data], w, cls)


def summary_data(app, ctx):
    c = app.db.conn(); cid = ctx["company_id"]; cl = CLEARANCE[ctx["rbac_role"]]; q = ",".join("?" * len(cl))
    def grp(sql, *a): return ", ".join(f"{k}: {v}" for k, v in c.execute(sql, a)) or "—"
    s = [("Active employees", "الموظفون الفعّالون", c.execute("SELECT count(*) FROM employees WHERE company_id=? AND is_active=1", (cid,)).fetchone()[0]),
         ("Tasks by status", "المهام حسب الحالة", grp(f"SELECT status,count(*) FROM tasks WHERE company_id=? AND classification IN ({q}) GROUP BY status", cid, *cl)),
         ("Pending approvals (CEO/CTO)", "موافقات معلّقة (الرئيس التنفيذي)", c.execute(f"SELECT count(*) FROM approvals WHERE company_id=? AND status='pending' AND classification IN ({q})", (cid, *cl)).fetchone()[0]),
         ("Projects by status", "المشاريع حسب الحالة", grp(f"SELECT status,count(*) FROM projects WHERE company_id=? AND classification IN ({q}) GROUP BY status", cid, *cl)),
         ("Leads by status", "العملاء المحتملون حسب الحالة", grp(f"SELECT status,count(*) FROM leads WHERE company_id=? AND classification IN ({q}) GROUP BY status", cid, *cl)),
         ("Open pipeline value", "قيمة خط المبيعات المفتوح", c.execute(f"SELECT COALESCE(SUM(est_value),0) FROM leads WHERE company_id=? AND status NOT IN ('closed_won','closed_lost') AND classification IN ({q})", (cid, *cl)).fetchone()[0]),
         ("Pending cleanup plans", "خطط تنظيف بانتظار التأكيد", c.execute("SELECT count(*) FROM cleanup_runs WHERE company_id=? AND status='pending_confirmation'", (cid,)).fetchone()[0])]
    if ctx["is_platform_root"]:
        b = one(c, "SELECT finished_at FROM backup_runs WHERE status='completed' ORDER BY id DESC LIMIT 1")
        s.append(("Last successful backup (UTC)", "آخر نسخة احتياطية ناجحة (UTC)", b["finished_at"] if b else "never"))
    return s


def run_export(app, ctx, name, fmt, q, lang):
    lang = lang if lang in ("en", "ar", "bi") else "bi"
    if name == "executive-summary":
        s = summary_data(app, ctx); f, data, cls = {}, s, "confidential"
        if fmt == "csv":
            buf = io.StringIO(); w = csv.writer(buf, lineterminator="\r\n"); w.writerow(_labels([("k", "Metric", "المؤشر"), ("v", "Value", "القيمة")], lang))
            for en, ar, v in s: w.writerow([neutralize(en if lang != "ar" else ar), neutralize(v if not isinstance(v, str) else v)])
            body = buf.getvalue().encode("utf-8-sig")
        else:
            lab = lambda en, ar: {"en": en, "ar": ar, "bi": f"{en} / {ar}"}[lang]
            meta = {"generated": utcnow(), "rows": [("Generated (UTC)", utcnow()), ("Generated by", ctx["username"]), ("Classification", cls)]}
            body = _doc(app, ctx, "Executive Summary", "الملخص التنفيذي", lang, meta, _labels([("k", "Metric", "المؤشر"), ("v", "Value", "القيمة")], lang), [[lab(en, ar), v] for en, ar, v in s], [300, 485], cls)
        rows_n = len(s)
    else:
        if name not in ENT: raise ApiError("NOT_FOUND")
        f = _filters(q); cap = app.cfg.export_row_cap_csv if fmt == "csv" else app.cfg.export_row_cap_pdf
        data, trunc = _query(app, ctx, name, f, cap); cls = _classification(name, data); rows_n = len(data)
        body = make_csv(ENT[name]["cols"], data, lang) if fmt == "csv" else make_pdf(app, ctx, name, data, lang, f, trunc, cls)
    sha = hashlib.sha256(body).hexdigest()
    with app.db.tx() as w:
        w.execute("INSERT INTO export_jobs(company_id,entity,format,lang,filters_json,row_count,classification,sha256,bytes,requested_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (ctx["company_id"], name, fmt, lang, json.dumps(f), rows_n, cls, sha, len(body), ctx["employee_id"], utcnow()))
        from . import audit
        audit.log(w, app.audit_key, ctx["company_id"], ctx["employee_id"], ctx["username"], "export.download", name, None, {"format": fmt, "rows": rows_n, "filters": f, "classification": cls, "sha256": sha}, ctx.get("ip"))
    ts = datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    return body, f"realhq-{name}-{ts}.{fmt}", ("text/csv; charset=utf-8" if fmt == "csv" else "application/pdf")
