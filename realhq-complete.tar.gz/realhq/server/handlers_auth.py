"""Authentication, employees (provisioning), reference data, live HQ state."""
import json
from .api import route, ApiError, JSON, clean, check_refs, page, like, Request
from .db import rows, one, utcnow, iso_after
from . import security as sec
from .rbac import permission_list, CLEARANCE, ROLES

PUBLIC_EMP = ("id", "username", "display_name_ar", "display_name_en", "role_ar", "role_en", "department_id", "room_id", "desk_slot",
              "bio_ar", "bio_en", "rbac_role", "is_active", "is_demo")
PRIV_EMP = PUBLIC_EMP + ("email", "must_change_password", "last_login_at", "locked_until", "created_at", "updated_at")


def emp_view(e, role, with_skills=None):
    keep = PRIV_EMP if role in ("ceo_cto", "manager", "auditor") else PUBLIC_EMP
    out = {k: e[k] for k in keep if k in e}
    if role == "ceo_cto": out["has_password"] = e["password_hash"] != "!"
    if with_skills is not None: out["skills"] = with_skills
    return out


def me_view(req, s):
    return {"id": s["employee_id"], "username": s["username"], "company_id": s["company_id"], "rbac_role": s["rbac_role"],
            "display_name_en": s["display_name_en"], "display_name_ar": s["display_name_ar"], "must_change_password": bool(s["must_change_password"]),
            "is_platform_root": bool(s["is_platform_root"]), "clearance": list(CLEARANCE[s["rbac_role"]]),
            "permissions": permission_list(s["rbac_role"]) if s["is_platform_root"] or s["rbac_role"] != "ceo_cto" or True else []}


def _fail_audit(req, company_id, ident, why):
    import hashlib
    with req.tx() as w:
        from . import audit
        audit.log(w, req.app.audit_key, company_id, None, "anonymous", "auth.login_failed", "employee", None,
                  {"reason": why, "identifier_sha256": hashlib.sha256(ident.encode()).hexdigest()[:16]}, req.ip)


@route("POST", "/api/auth/login", auth=False)
def login(req):
    d = req.body if isinstance(req.body, dict) else {}
    ident, pw, slug = d.get("identifier"), d.get("password"), d.get("company") or req.cfg.default_company_slug
    if not isinstance(ident, str) or not isinstance(pw, str) or not ident or len(ident) > 120 or len(pw) > 256 or not isinstance(slug, str):
        raise ApiError("INVALID_CREDENTIALS")
    if not req.app.login_limiter.allow(req.ip): raise ApiError("RATE_LIMITED")
    c = req.c; ident_l = ident.strip().lower()
    if "@" in ident_l: emp = one(c, "SELECT * FROM employees WHERE lower(email)=?", (ident_l,))
    else:
        emp = one(c, "SELECT e.* FROM employees e JOIN companies co ON co.id=e.company_id WHERE co.slug=? AND lower(e.username)=?", (slug, ident_l))
    now = utcnow()
    if not emp:
        sec.verify_password(pw, None, req.cfg.pbkdf2_iters)
        _fail_audit(req, 1, ident_l, "unknown_account"); raise ApiError("INVALID_CREDENTIALS")
    co = one(c, "SELECT is_active FROM companies WHERE id=?", (emp["company_id"],))
    locked = bool(emp["locked_until"] and emp["locked_until"] > now)
    ok = sec.verify_password(pw, emp["password_hash"], req.cfg.pbkdf2_iters)
    if locked or not ok or not emp["is_active"] or not co["is_active"]:
        with req.tx() as w:
            why = "locked" if locked else "inactive" if not emp["is_active"] else "bad_password"
            if not ok and not locked:
                n = emp["failed_attempts"] + 1
                if n >= req.cfg.lockout_threshold:
                    w.execute("UPDATE employees SET failed_attempts=0, locked_until=? WHERE id=?", (iso_after(req.cfg.lockout_seconds), emp["id"]))
                    from . import audit as _a
                    _a.log(w, req.app.audit_key, emp["company_id"], emp["id"], emp["username"], "auth.account_locked", "employee", emp["id"], {"minutes": req.cfg.lockout_seconds // 60}, req.ip)
                else: w.execute("UPDATE employees SET failed_attempts=? WHERE id=?", (n, emp["id"]))
            from . import audit
            audit.log(w, req.app.audit_key, emp["company_id"], emp["id"], emp["username"], "auth.login_failed", "employee", emp["id"], {"reason": why}, req.ip)
        raise ApiError("INVALID_CREDENTIALS")  # same response for every failure => no account enumeration
    with req.tx() as w:
        h = sec.hash_password(pw, req.cfg.pbkdf2_iters) if sec.needs_rehash(emp["password_hash"], req.cfg.pbkdf2_iters) else emp["password_hash"]
        w.execute("UPDATE employees SET failed_attempts=0, locked_until=NULL, last_login_at=?, password_hash=? WHERE id=?", (now, h, emp["id"]))
        token, csrf = sec.create_session(w, emp, req.ip, req.headers.get("User-Agent"), req.cfg)
        from . import audit
        audit.log(w, req.app.audit_key, emp["company_id"], emp["id"], emp["username"], "auth.login", "employee", emp["id"], {}, req.ip)
    s = sec.lookup_session(req.app.db, token, req.cfg)
    return JSON({"user": me_view(req, s), "csrf_token": csrf}, headers={"Set-Cookie": sec.cookie_header(req.cfg, token, req.cfg.session_abs_seconds)})


@route("POST", "/api/auth/logout")
def logout(req):
    with req.tx() as w:
        sec.revoke_session(w, req.ctx["id"]); req.audit(w, "auth.logout", "employee", req.uid)
    return JSON({"ok": True}, headers={"Set-Cookie": sec.cookie_header(req.cfg, "", 0)})


@route("GET", "/api/auth/me")
def me(req):
    return JSON({"user": me_view(req, req.ctx), "csrf_token": req.ctx["csrf_token"]})


@route("POST", "/api/auth/rotate")
def rotate(req):
    with req.tx() as w:
        e = one(w, "SELECT * FROM employees WHERE id=?", (req.uid,))
        token, csrf = sec.create_session(w, e, req.ip, req.headers.get("User-Agent"), req.cfg)
        sec.revoke_session(w, req.ctx["id"]); req.audit(w, "auth.session_rotated", "employee", req.uid)
    return JSON({"csrf_token": csrf}, headers={"Set-Cookie": sec.cookie_header(req.cfg, token, req.cfg.session_abs_seconds)})


@route("POST", "/api/auth/change-password")
def change_password(req):
    d = req.body if isinstance(req.body, dict) else {}
    cur, new = d.get("current_password"), d.get("new_password")
    if not isinstance(cur, str) or not isinstance(new, str): raise ApiError("VALIDATION", {"_": "current_password/new_password required"})
    e = one(req.c, "SELECT * FROM employees WHERE id=?", (req.uid,))
    if not sec.verify_password(cur, e["password_hash"], req.cfg.pbkdf2_iters): raise ApiError("INVALID_CREDENTIALS")
    probs = sec.password_problems(new, e["username"], e["email"])
    if cur == new: probs.append("must_differ_from_current")
    if probs: raise ApiError("WEAK_PASSWORD", probs)
    with req.tx() as w:
        w.execute("UPDATE employees SET password_hash=?, must_change_password=0, updated_at=? WHERE id=?", (sec.hash_password(new, req.cfg.pbkdf2_iters), utcnow(), req.uid))
        sec.revoke_all(w, req.uid)
        token, csrf = sec.create_session(w, e, req.ip, req.headers.get("User-Agent"), req.cfg)
        req.audit(w, "auth.password_changed", "employee", req.uid)
    return JSON({"ok": True, "csrf_token": csrf}, headers={"Set-Cookie": sec.cookie_header(req.cfg, token, req.cfg.session_abs_seconds)})


# ---------------- employees ----------------
EMP_SPEC = {
    "username": ("str", {"req": True, "min": 3, "max": 32, "pattern": r"[a-z0-9][a-z0-9._-]{2,31}"}),
    "email": ("str", {"max": 120, "pattern": r"[^@\s]+@[^@\s]+\.[^@\s]+"}),
    "display_name_ar": ("str", {"req": True, "max": 100}), "display_name_en": ("str", {"req": True, "max": 100}),
    "role_ar": ("str", {"req": True, "max": 100}), "role_en": ("str", {"req": True, "max": 100}),
    "bio_ar": ("text", {"max": 1000, "default": ""}), "bio_en": ("text", {"max": 1000, "default": ""}),
    "rbac_role": ("enum", {"values": list(ROLES), "default": "member"}),
    "department_id": ("ref", {"table": "departments"}), "room_id": ("ref", {"table": "rooms"}),
    "desk_slot": ("int", {"min": 0, "max": 50, "default": 0}), "skill_ids": ("idlist", {}),
}


def _skills(c, eid): return rows(c, "SELECT s.id,s.code,s.name_ar,s.name_en FROM skills s JOIN employee_skills es ON es.skill_id=s.id WHERE es.employee_id=?", (eid,))


def _get_emp(req, eid):
    e = one(req.c, "SELECT * FROM employees WHERE id=? AND company_id=?", (eid, req.cid))
    if not e: raise ApiError("NOT_FOUND")
    return e


def _set_skills(c, cid, eid, ids):
    c.execute("DELETE FROM employee_skills WHERE employee_id=?", (eid,))
    for sid in set(ids):
        if not c.execute("SELECT 1 FROM skills WHERE id=? AND company_id=?", (sid, cid)).fetchone(): raise ApiError("VALIDATION", {"skill_ids": "unknown skill"})
        c.execute("INSERT INTO employee_skills VALUES(?,?)", (eid, sid))


def _other_active_ceo(c, cid, eid):
    return c.execute("SELECT 1 FROM employees WHERE company_id=? AND rbac_role='ceo_cto' AND is_active=1 AND id!=?", (cid, eid)).fetchone()


@route("GET", "/api/employees", perm="employees:read")
def emp_list(req):
    limit, off = page(req, 100); where, a = ["company_id=?"], [req.cid]
    if req.query.get("active") in ("0", "1"): where.append("is_active=?"); a.append(int(req.query["active"]))
    if req.query.get("department_id", "").isdigit(): where.append("department_id=?"); a.append(int(req.query["department_id"]))
    if req.query.get("q"): where.append("(display_name_en LIKE ? ESCAPE '\\' OR display_name_ar LIKE ? ESCAPE '\\' OR username LIKE ? ESCAPE '\\')"); a += [like(req.query["q"])] * 3
    w = " AND ".join(where)
    items = rows(req.c, f"SELECT * FROM employees WHERE {w} ORDER BY id LIMIT ? OFFSET ?", a + [limit, off])
    total = req.c.execute(f"SELECT count(*) FROM employees WHERE {w}", a).fetchone()[0]
    return JSON({"items": [emp_view(e, req.role) for e in items], "total": total})


@route("GET", "/api/employees/{id}", perm="employees:read")
def emp_get(req):
    e = _get_emp(req, req.id()); return JSON(emp_view(e, req.role, _skills(req.c, e["id"])))


@route("POST", "/api/employees", perm="employees:manage")
def emp_create(req):
    d = dict(req.body) if isinstance(req.body, dict) else {}
    pw = d.pop("password", None)
    v = clean(d, EMP_SPEC); check_refs(req.c, req.cid, v, EMP_SPEC)
    probs = sec.password_problems(pw, v["username"], v.get("email", ""))
    if probs: raise ApiError("WEAK_PASSWORD", probs)
    skills = v.pop("skill_ids", [])
    with req.tx() as w:
        if w.execute("SELECT 1 FROM employees WHERE company_id=? AND lower(username)=?", (req.cid, v["username"])).fetchone() or \
           (v.get("email") and w.execute("SELECT 1 FROM employees WHERE lower(email)=?", (v["email"].lower(),)).fetchone()):
            raise ApiError("CONFLICT", {"_": "username or email already in use"})
        now = utcnow(); v["company_id"] = req.cid; v["password_hash"] = sec.hash_password(pw, req.cfg.pbkdf2_iters)
        v["must_change_password"] = 1; v["created_at"] = v["updated_at"] = now
        if v.get("email"): v["email"] = v["email"].lower()
        cols = list(v)
        eid = w.execute(f"INSERT INTO employees({','.join(cols)}) VALUES({','.join('?' * len(cols))})", [v[k] for k in cols]).lastrowid
        _set_skills(w, req.cid, eid, skills)
        req.audit(w, "employee.create", "employee", eid, {"username": v["username"], "rbac_role": v["rbac_role"]})
    return JSON(emp_view(_get_emp(req, eid), req.role, _skills(req.c, eid)), 201)


@route("PATCH", "/api/employees/{id}", perm="employees:manage")
def emp_update(req):
    eid = req.id(); old = _get_emp(req, eid)
    spec = {k: v for k, v in EMP_SPEC.items() if k != "username"}
    spec["bio_ar"] = ("text", {"max": 1000}); spec["bio_en"] = ("text", {"max": 1000}); spec["desk_slot"] = ("int", {"min": 0, "max": 50})
    spec["rbac_role"] = ("enum", {"values": list(ROLES)})
    v = clean(req.body, spec, partial=True); check_refs(req.c, req.cid, v, spec)
    skills = v.pop("skill_ids", None)
    with req.tx() as w:
        if "rbac_role" in v and v["rbac_role"] != old["rbac_role"]:
            if eid == req.uid: raise ApiError("FORBIDDEN", {"_": "cannot change your own role"})
            if old["rbac_role"] == "ceo_cto" and old["is_active"] and not _other_active_ceo(w, req.cid, eid): raise ApiError("LAST_CEO")
        if v.get("email") and w.execute("SELECT 1 FROM employees WHERE lower(email)=? AND id!=?", (v["email"].lower(), eid)).fetchone(): raise ApiError("CONFLICT")
        changes = {k: [old.get(k), x] for k, x in v.items() if old.get(k) != x}
        if v:
            v["updated_at"] = utcnow(); w.execute(f"UPDATE employees SET {','.join(k + '=?' for k in v)} WHERE id=?", list(v.values()) + [eid])
        if skills is not None: _set_skills(w, req.cid, eid, skills); changes["skill_ids"] = skills
        if "rbac_role" in changes: sec.revoke_all(w, eid)  # force re-login under the new role
        req.audit(w, "employee.update", "employee", eid, changes)
    return JSON(emp_view(_get_emp(req, eid), req.role, _skills(req.c, eid)))


def _toggle(req, active):
    eid = req.id(); e = _get_emp(req, eid)
    with req.tx() as w:
        if not active:
            if eid == req.uid: raise ApiError("LAST_CEO") if e["rbac_role"] == "ceo_cto" else ApiError("FORBIDDEN", {"_": "cannot deactivate yourself"})
            if e["rbac_role"] == "ceo_cto" and not _other_active_ceo(w, req.cid, eid): raise ApiError("LAST_CEO")
            sec.revoke_all(w, eid)
        w.execute("UPDATE employees SET is_active=?, updated_at=? WHERE id=?", (1 if active else 0, utcnow(), eid))
        req.audit(w, "employee.activate" if active else "employee.deactivate", "employee", eid, {"username": e["username"]})
    return JSON({"ok": True, "is_active": active})


@route("POST", "/api/employees/{id}/activate", perm="employees:manage")
def emp_activate(req): return _toggle(req, True)
@route("POST", "/api/employees/{id}/deactivate", perm="employees:manage")
def emp_deactivate(req): return _toggle(req, False)


@route("POST", "/api/employees/{id}/reset-password", perm="employees:manage")
def emp_reset(req):
    eid = req.id(); e = _get_emp(req, eid)
    pw = req.body.get("new_password") if isinstance(req.body, dict) else None
    probs = sec.password_problems(pw, e["username"], e["email"])
    if probs: raise ApiError("WEAK_PASSWORD", probs)
    with req.tx() as w:  # the CEO/CTO chooses a temporary password; it is hashed immediately and never echoed back
        w.execute("UPDATE employees SET password_hash=?, must_change_password=1, failed_attempts=0, locked_until=NULL, updated_at=? WHERE id=?",
                  (sec.hash_password(pw, req.cfg.pbkdf2_iters), utcnow(), eid))
        sec.revoke_all(w, eid); req.audit(w, "employee.password_reset", "employee", eid, {"username": e["username"]})
    return JSON({"ok": True, "must_change_password": True})


# ---------------- reference + HQ ----------------
@route("GET", "/api/reference", perm="reference:read")
def reference(req):
    c, cid = req.c, req.cid
    co = one(c, "SELECT id,slug,name_ar,name_en,kind FROM companies WHERE id=?", (cid,))
    kids = rows(c, "SELECT id,slug,name_ar,name_en,kind FROM companies WHERE parent_id=? AND is_active=1", (cid,))
    return JSON({"company": co, "units": kids, "departments": rows(c, "SELECT id,code,name_ar,name_en FROM departments WHERE company_id=?", (cid,)),
                 "rooms": rows(c, "SELECT * FROM rooms WHERE company_id=?", (cid,)), "skills": rows(c, "SELECT id,code,name_ar,name_en FROM skills WHERE company_id=?", (cid,)),
                 "roles": list(ROLES), "classifications": ["internal", "confidential", "restricted"]})


def _cls_clause(role, col="classification"):
    cl = CLEARANCE[role]; return f"{col} IN ({','.join('?' * len(cl))})", list(cl)


@route("GET", "/api/hq/state", perm="hq:read")
def hq_state(req):
    c, cid = req.c, req.cid; cc, ca = _cls_clause(req.role)
    emps = rows(c, "SELECT id,username,display_name_ar,display_name_en,role_ar,role_en,rbac_role,room_id,desk_slot,department_id FROM employees WHERE company_id=? AND is_active=1 ORDER BY desk_slot,id", (cid,))
    tasks = rows(c, f"SELECT id,title,status,priority,assignee_id,external_action FROM tasks WHERE company_id=? AND status IN ('in_progress','awaiting_approval') AND {cc} ORDER BY id DESC", [cid] + ca)
    pend = rows(c, f"SELECT id,requested_by,kind,title,task_id FROM approvals WHERE company_id=? AND status='pending' AND {cc}", [cid] + ca)
    from datetime import datetime, timedelta, timezone
    online = {r["employee_id"] for r in c.execute("SELECT DISTINCT employee_id FROM sessions WHERE company_id=? AND revoked_at IS NULL AND expires_at>? AND last_seen_at>?", (cid, utcnow(), (datetime.now(timezone.utc) - timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ")))}
    for e in emps:
        mine = [t for t in tasks if t["assignee_id"] == e["id"]]
        wait = [t for t in mine if t["status"] == "awaiting_approval"] ; pa = [a for a in pend if a["requested_by"] == e["id"]]
        e["status"] = "awaiting_approval" if (wait or pa) else "working" if mine else "idle"
        e["active_tasks"] = [t for t in mine if t["status"] == "in_progress"][:3]; e["awaiting_approval"] = [{"id": a["id"], "title": a["title"], "kind": a["kind"]} for a in pa][:3]
        e["online"] = e["id"] in online; e["is_executive"] = e["rbac_role"] == "ceo_cto"
    rooms = rows(c, "SELECT * FROM rooms WHERE company_id=?", (cid,))
    return JSON({"generated_at": utcnow(), "rooms": rooms, "employees": emps, "pending_approvals": len(pend),
                 "counts": {s: sum(1 for e in emps if e["status"] == s) for s in ("working", "awaiting_approval", "idle")}})


@route("GET", "/api/hq/employees/{id}", perm="hq:read")
def hq_employee(req):
    e = _get_emp(req, req.id()); cc, ca = _cls_clause(req.role)
    t = rows(req.c, f"SELECT id,title,status,priority,due_date FROM tasks WHERE company_id=? AND assignee_id=? AND status NOT IN ('done','cancelled') AND {cc} ORDER BY id DESC LIMIT 50", [req.cid, e["id"]] + ca)
    a = rows(req.c, f"SELECT id,kind,title,status FROM approvals WHERE company_id=? AND requested_by=? AND status='pending' AND {cc}", [req.cid, e["id"]] + ca)
    return JSON({"employee": emp_view(e, req.role, _skills(req.c, e["id"])), "open_tasks": t, "pending_approvals": a})
