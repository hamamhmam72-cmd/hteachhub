"""Business data: generic tenant-scoped CRUD, tasks + state machine, approvals, time entries, chat."""
import json
from .api import route, ApiError, JSON, clean, check_refs, page, like, ROUTES
from .db import rows, one, utcnow
from .rbac import CLEARANCE, TASK_TRANSITIONS, LEVEL, can

CLS = ("enum", {"values": ["internal", "confidential", "restricted"], "default": "internal"})
S = lambda **o: ("str", o)
RES = {
    "clients": dict(path="clients", terminal=("archived",), closed=True, search=("name", "contact_email", "notes"), filters=("status",), own=False, spec={
        "name": S(req=True, max=200), "contact_email": S(max=200), "status": ("enum", {"values": ["active", "inactive", "archived"], "default": "active"}),
        "classification": CLS, "pinned": ("bool", {"default": False}), "notes": ("text", {"max": 4000})}),
    "leads": dict(path="leads", terminal=("closed_won", "closed_lost"), closed=True, search=("name", "source", "notes"), filters=("status", "owner_id", "client_id"), own=False, spec={
        "name": S(req=True, max=200), "source": S(max=100), "status": ("enum", {"values": ["new", "contacted", "qualified", "proposal", "closed_won", "closed_lost"], "default": "new"}),
        "est_value": ("float", {}), "owner_id": ("ref", {"table": "employees"}), "client_id": ("ref", {"table": "clients"}), "classification": CLS, "notes": ("text", {"max": 4000})}),
    "projects": dict(path="projects", terminal=("completed", "cancelled"), closed=True, search=("name", "description"), filters=("status", "client_id"), own=False, spec={
        "name": S(req=True, max=200), "description": ("text", {"max": 4000}), "client_id": ("ref", {"table": "clients"}),
        "status": ("enum", {"values": ["planned", "active", "on_hold", "completed", "cancelled"], "default": "planned"}),
        "classification": CLS, "start_date": ("date", {}), "due_date": ("date", {})}),
    "knowledge_items": dict(path="knowledge-items", terminal=(), closed=False, search=("title", "body", "tags"), filters=(), own=True, spec={
        "title": S(req=True, max=200), "body": ("text", {"max": 20000, "default": ""}), "tags": S(max=200), "pinned": ("bool", {"default": False}), "classification": CLS}),
    "research_reports": dict(path="research-reports", terminal=(), closed=False, search=("title", "query", "summary"), filters=("status",), own=True, spec={
        "title": S(req=True, max=200), "query": ("text", {"max": 1000}), "summary": ("text", {"max": 20000}),
        "status": ("enum", {"values": ["queued", "running", "completed", "failed"], "default": "queued"}), "classification": CLS}),
}


def _cc(role, col="classification"):
    cl = CLEARANCE[role]; return f"{col} IN ({','.join('?' * len(cl))})", list(cl)


def _short(v): return v[:120] if isinstance(v, str) else v


def _make_crud(name, r):
    table, spec = name, r["spec"]; perm_r, perm_w, perm_d = f"{name}:read", f"{name}:write", f"{name}:delete"

    def lst(req):
        limit, off = page(req); cc, ca = _cc(req.role); where, a = [f"company_id=?", cc], [req.cid] + ca
        for f in r["filters"]:
            if f in req.query: where.append(f"{f}=?"); a.append(req.query[f])
        if req.query.get("q"):
            where.append("(" + " OR ".join(f"{c} LIKE ? ESCAPE '\\'" for c in r["search"]) + ")"); a += [like(req.query["q"][:100])] * len(r["search"])
        w = " AND ".join(where)
        return JSON({"items": rows(req.c, f"SELECT * FROM {table} WHERE {w} ORDER BY id DESC LIMIT ? OFFSET ?", a + [limit, off]),
                     "total": req.c.execute(f"SELECT count(*) FROM {table} WHERE {w}", a).fetchone()[0]})

    def fetch(req):
        cc, ca = _cc(req.role)
        row = one(req.c, f"SELECT * FROM {table} WHERE id=? AND company_id=? AND {cc}", [req.id(), req.cid] + ca)
        if not row: raise ApiError("NOT_FOUND")  # out-of-clearance rows look nonexistent
        return row

    def get(req): return JSON(fetch(req))

    def _check_cls(req, v):
        if v.get("classification") and v["classification"] not in CLEARANCE[req.role]: raise ApiError("FORBIDDEN", {"classification": "above your clearance"})

    def create(req):
        v = clean(req.body, spec); check_refs(req.c, req.cid, v, spec); _check_cls(req, v)
        now = utcnow(); v.update(company_id=req.cid, created_by=req.uid, created_at=now, updated_at=now)
        if r["closed"] and v.get("status") in r["terminal"]: v["closed_at"] = now
        with req.tx() as w:
            rid = w.execute(f"INSERT INTO {table}({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values())).lastrowid
            req.audit(w, f"{name}.create", name, rid, {k: _short(x) for k, x in v.items() if k in ("name", "title", "status", "classification")})
        return JSON(one(req.c, f"SELECT * FROM {table} WHERE id=?", (rid,)), 201)

    def update(req):
        old = fetch(req); v = clean(req.body, spec, partial=True); check_refs(req.c, req.cid, v, spec); _check_cls(req, v)
        if r["own"] and req.role == "member" and old["created_by"] != req.uid: raise ApiError("FORBIDDEN")
        if old["classification"] not in CLEARANCE[req.role]: raise ApiError("NOT_FOUND")
        ch = {k: [_short(old[k]), _short(x)] for k, x in v.items() if old[k] != x}
        if not ch: return JSON(old)
        now = utcnow(); v = {k: v[k] for k in ch}; v["updated_at"] = now
        if r["closed"] and "status" in ch: v["closed_at"] = now if v["status"] in r["terminal"] else None
        with req.tx() as w:
            w.execute(f"UPDATE {table} SET {','.join(k + '=?' for k in v)} WHERE id=? AND company_id=?", list(v.values()) + [old["id"], req.cid])
            req.audit(w, f"{name}.update", name, old["id"], ch)
        return JSON(one(req.c, f"SELECT * FROM {table} WHERE id=?", (old["id"],)))

    def delete(req):
        old = fetch(req)
        with req.tx() as w:
            try: w.execute(f"DELETE FROM {table} WHERE id=? AND company_id=?", (old["id"], req.cid))
            except Exception: raise ApiError("CONFLICT", {"_": "record is referenced by other records"})
            req.audit(w, f"{name}.delete", name, old["id"], {"title": _short(old.get("name") or old.get("title"))})
        return JSON({"ok": True})

    p = f"/api/{r['path']}"
    route("GET", p, perm=perm_r)(lst); route("GET", p + "/{id}", perm=perm_r)(get); route("POST", p, perm=perm_w)(create)
    route("PATCH", p + "/{id}", perm=perm_w)(update); route("DELETE", p + "/{id}", perm=perm_d)(delete)


for _n, _r in RES.items(): _make_crud(_n, _r)

# ---------------- tasks ----------------
TASK_SPEC = {
    "title": S(req=True, max=200), "description": ("text", {"max": 8000}),
    "priority": ("enum", {"values": ["low", "normal", "high", "urgent"], "default": "normal"}),
    "assignee_id": ("ref", {"table": "employees"}), "project_id": ("ref", {"table": "projects"}), "due_date": ("date", {}),
    "external_action": ("bool", {"default": False}), "classification": CLS,
}


def _task(req, tid=None):
    cc, ca = _cc(req.role)
    t = one(req.c, f"SELECT * FROM tasks WHERE id=? AND company_id=? AND {cc}", [tid or req.id(), req.cid] + ca)
    if not t: raise ApiError("NOT_FOUND")
    return t


def _mine(req, t): return t["assignee_id"] == req.uid or t["created_by"] == req.uid


@route("GET", "/api/tasks", perm="tasks:read")
def task_list(req):
    limit, off = page(req); cc, ca = _cc(req.role); where, a = ["t.company_id=?", "t." + cc], [req.cid] + ca
    for f in ("status", "assignee_id", "project_id", "priority"):
        if f in req.query: where.append(f"t.{f}=?"); a.append(req.query[f])
    if req.query.get("q"): where.append("(t.title LIKE ? ESCAPE '\\' OR t.description LIKE ? ESCAPE '\\')"); a += [like(req.query["q"][:100])] * 2
    w = " AND ".join(where)
    return JSON({"items": rows(req.c, f"SELECT t.* FROM tasks t WHERE {w} ORDER BY t.id DESC LIMIT ? OFFSET ?", a + [limit, off]),
                 "total": req.c.execute(f"SELECT count(*) FROM tasks t WHERE {w}", a).fetchone()[0]})


@route("GET", "/api/tasks/{id}", perm="tasks:read")
def task_get(req):
    t = _task(req); t["approvals"] = rows(req.c, "SELECT id,kind,status,title FROM approvals WHERE task_id=?", (t["id"],))
    t["time_minutes"] = req.c.execute("SELECT COALESCE(SUM(minutes),0) FROM time_entries WHERE task_id=?", (t["id"],)).fetchone()[0]
    return JSON(t)


def _assign_ok(req, aid):
    if aid is not None and not can(req.role, "tasks:assign") and aid != req.uid: raise ApiError("FORBIDDEN", {"assignee_id": "members may only assign to themselves"})


@route("POST", "/api/tasks", perm="tasks:write")
def task_create(req):
    spec = dict(TASK_SPEC); spec["status"] = ("enum", {"values": ["draft", "todo"], "default": "todo"})
    v = clean(req.body, spec); check_refs(req.c, req.cid, v, spec); _assign_ok(req, v.get("assignee_id"))
    if v["classification"] not in CLEARANCE[req.role]: raise ApiError("FORBIDDEN", {"classification": "above your clearance"})
    now = utcnow(); v.update(company_id=req.cid, created_by=req.uid, created_at=now, updated_at=now)
    with req.tx() as w:
        tid = w.execute(f"INSERT INTO tasks({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values())).lastrowid
        req.audit(w, "task.create", "task", tid, {"title": _short(v["title"]), "status": v["status"], "assignee_id": v.get("assignee_id")})
    return JSON(_task(req, tid), 201)


@route("PATCH", "/api/tasks/{id}", perm="tasks:write")
def task_update(req):
    old = _task(req)
    if req.role == "member" and not _mine(req, old): raise ApiError("FORBIDDEN")
    spec = {k: v for k, v in TASK_SPEC.items() if k not in ("assignee_id",)}
    v = clean(req.body, spec, partial=True); check_refs(req.c, req.cid, v, spec)
    if v.get("classification") and v["classification"] not in CLEARANCE[req.role]: raise ApiError("FORBIDDEN")
    ch = {k: [_short(old[k]), _short(x)] for k, x in v.items() if old[k] != x}
    if not ch: return JSON(old)
    v = {k: v[k] for k in ch}; v["updated_at"] = utcnow()
    with req.tx() as w:
        w.execute(f"UPDATE tasks SET {','.join(k + '=?' for k in v)} WHERE id=? AND company_id=?", list(v.values()) + [old["id"], req.cid])
        req.audit(w, "task.update", "task", old["id"], ch)
    return JSON(_task(req, old["id"]))


@route("POST", "/api/tasks/{id}/assign", perm="tasks:write")
def task_assign(req):
    t = _task(req); v = clean(req.body, {"assignee_id": ("ref", {"table": "employees"})}); check_refs(req.c, req.cid, v, {"assignee_id": ("ref", {"table": "employees"})})
    _assign_ok(req, v.get("assignee_id"))
    if req.role == "member" and not _mine(req, t) and t["assignee_id"] is not None: raise ApiError("FORBIDDEN")
    with req.tx() as w:
        w.execute("UPDATE tasks SET assignee_id=?, updated_at=? WHERE id=?", (v.get("assignee_id"), utcnow(), t["id"]))
        req.audit(w, "task.assign", "task", t["id"], {"from": t["assignee_id"], "to": v.get("assignee_id")})
    return JSON(_task(req, t["id"]))


@route("POST", "/api/tasks/{id}/transition", perm="tasks:write")
def task_transition(req):
    t = _task(req); to = req.body.get("to") if isinstance(req.body, dict) else None
    allowed = TASK_TRANSITIONS.get(t["status"], {})
    if to not in allowed: raise ApiError("INVALID_TRANSITION", {"from": t["status"], "to": to, "allowed": sorted(allowed)})
    if LEVEL[req.role if req.role in LEVEL else "member"] < allowed[to]: raise ApiError("FORBIDDEN")
    if req.role == "member" and not _mine(req, t): raise ApiError("FORBIDDEN")
    if to == "done" and t["external_action"] and not req.c.execute("SELECT 1 FROM approvals WHERE task_id=? AND status='approved'", (t["id"],)).fetchone():
        raise ApiError("EXTERNAL_ACTION_NOT_APPROVED")
    now = utcnow()
    with req.tx() as w:
        w.execute("UPDATE tasks SET status=?, closed_at=?, updated_at=? WHERE id=?", (to, now if to in ("done", "cancelled") else None, now, t["id"]))
        if to == "cancelled": w.execute("UPDATE approvals SET status='cancelled' WHERE task_id=? AND status='pending'", (t["id"],))
        req.audit(w, "task.transition", "task", t["id"], {"from": t["status"], "to": to})
    return JSON(_task(req, t["id"]))


@route("DELETE", "/api/tasks/{id}", perm="tasks:delete")
def task_delete(req):
    t = _task(req)
    with req.tx() as w:
        w.execute("DELETE FROM tasks WHERE id=? AND company_id=?", (t["id"], req.cid)); req.audit(w, "task.delete", "task", t["id"], {"title": _short(t["title"])})
    return JSON({"ok": True})


# ---------------- time entries ----------------
TE_SPEC = {"task_id": ("ref", {"table": "tasks"}), "minutes": ("int", {"min": 1, "max": 1440}), "work_date": ("date", {}), "note": S(max=500),
           "employee_id": ("ref", {"table": "employees"})}


@route("GET", "/api/time-entries", perm="time_entries:read")
def te_list(req):
    limit, off = page(req); cc, ca = _cc(req.role, "t.classification"); where, a = ["te.company_id=?", cc], [req.cid] + ca
    if req.role == "member": where.append("te.employee_id=?"); a.append(req.uid)
    for f in ("task_id", "employee_id"):
        if f in req.query: where.append(f"te.{f}=?"); a.append(req.query[f])
    w = " AND ".join(where)
    return JSON({"items": rows(req.c, f"SELECT te.* FROM time_entries te JOIN tasks t ON t.id=te.task_id WHERE {w} ORDER BY te.id DESC LIMIT ? OFFSET ?", a + [limit, off])})


@route("POST", "/api/time-entries", perm="time_entries:write")
def te_create(req):
    spec = dict(TE_SPEC); spec["task_id"] = ("ref", {"table": "tasks", "req": True}); spec["minutes"] = ("int", {"req": True, "min": 1, "max": 1440}); spec["work_date"] = ("date", {"req": True})
    v = clean(req.body, spec); check_refs(req.c, req.cid, v, spec); _task(req, v["task_id"])
    emp = v.pop("employee_id", None) or req.uid
    if emp != req.uid and req.role not in ("manager", "ceo_cto"): raise ApiError("FORBIDDEN")
    v.update(company_id=req.cid, employee_id=emp, created_at=utcnow())
    with req.tx() as w:
        rid = w.execute(f"INSERT INTO time_entries({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values())).lastrowid
        req.audit(w, "time_entry.create", "time_entry", rid, {"task_id": v["task_id"], "minutes": v["minutes"], "employee_id": emp})
    return JSON(one(req.c, "SELECT * FROM time_entries WHERE id=?", (rid,)), 201)


@route("DELETE", "/api/time-entries/{id}", perm="time_entries:write")
def te_delete(req):
    te = one(req.c, "SELECT * FROM time_entries WHERE id=? AND company_id=?", (req.id(), req.cid))
    if not te or (req.role == "member" and te["employee_id"] != req.uid): raise ApiError("NOT_FOUND")
    _task(req, te["task_id"])
    with req.tx() as w:
        w.execute("DELETE FROM time_entries WHERE id=?", (te["id"],)); req.audit(w, "time_entry.delete", "time_entry", te["id"], {"minutes": te["minutes"]})
    return JSON({"ok": True})


# ---------------- approvals (CEO/CTO is the final decision-maker) ----------------
@route("GET", "/api/approvals", perm="approvals:read")
def appr_list(req):
    limit, off = page(req); cc, ca = _cc(req.role); where, a = ["company_id=?", cc], [req.cid] + ca
    for f in ("status", "kind"):
        if f in req.query: where.append(f"{f}=?"); a.append(req.query[f])
    if req.role == "member": where.append("requested_by=?"); a.append(req.uid)
    w = " AND ".join(where)
    return JSON({"items": rows(req.c, f"SELECT * FROM approvals WHERE {w} ORDER BY (status='pending') DESC, id DESC LIMIT ? OFFSET ?", a + [limit, off]),
                 "total": req.c.execute(f"SELECT count(*) FROM approvals WHERE {w}", a).fetchone()[0]})


APPR_SPEC = {"kind": ("enum", {"req": True, "values": ["pricing", "external_action", "repo_change", "security_exception", "backup_retention", "account_provisioning", "role_activation", "other"]}),
             "title": S(req=True, max=200), "description": ("text", {"max": 4000}), "task_id": ("ref", {"table": "tasks"}), "classification": CLS}


@route("POST", "/api/approvals", perm="approvals:request")
def appr_create(req):
    v = clean(req.body, APPR_SPEC); check_refs(req.c, req.cid, v, APPR_SPEC)
    if v["classification"] not in CLEARANCE[req.role]: raise ApiError("FORBIDDEN")
    task = _task(req, v["task_id"]) if v.get("task_id") else None
    if task and task["status"] not in ("todo", "in_progress", "rejected"): raise ApiError("INVALID_TRANSITION", {"task_status": task["status"]})
    now = utcnow(); v.update(company_id=req.cid, requested_by=req.uid, created_at=now)
    with req.tx() as w:
        aid = w.execute(f"INSERT INTO approvals({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values())).lastrowid
        if task: w.execute("UPDATE tasks SET status='awaiting_approval', updated_at=? WHERE id=?", (now, task["id"]))
        req.audit(w, "approval.request", "approval", aid, {"kind": v["kind"], "title": _short(v["title"]), "task_id": v.get("task_id")})
    return JSON(one(req.c, "SELECT * FROM approvals WHERE id=?", (aid,)), 201)


@route("POST", "/api/approvals/{id}/decide", perm="approvals:decide")
def appr_decide(req):
    d = clean(req.body, {"decision": ("enum", {"req": True, "values": ["approved", "rejected"]}), "note": ("text", {"max": 1000})})
    if d["decision"] == "rejected" and not d.get("note"): raise ApiError("VALIDATION", {"note": "required when rejecting"})
    cc, ca = _cc(req.role)
    with req.tx() as w:
        a = one(w, f"SELECT * FROM approvals WHERE id=? AND company_id=? AND {cc}", [req.id(), req.cid] + ca)
        if not a: raise ApiError("NOT_FOUND")
        if a["status"] != "pending": raise ApiError("CONFLICT", {"status": a["status"]})
        now = utcnow()
        w.execute("UPDATE approvals SET status=?, decided_by=?, decision_note=?, decided_at=? WHERE id=?", (d["decision"], req.uid, d.get("note"), now, a["id"]))
        if a["task_id"]: w.execute("UPDATE tasks SET status=?, updated_at=? WHERE id=? AND status='awaiting_approval'", (d["decision"], now, a["task_id"]))
        req.audit(w, "approval.decide", "approval", a["id"], {"decision": d["decision"], "kind": a["kind"], "task_id": a["task_id"], "note": d.get("note")})
    return JSON(one(req.c, "SELECT * FROM approvals WHERE id=?", (req.id(),)))


@route("POST", "/api/approvals/{id}/cancel", perm="approvals:request")
def appr_cancel(req):
    with req.tx() as w:
        a = one(w, "SELECT * FROM approvals WHERE id=? AND company_id=?", (req.id(), req.cid))
        if not a or (req.role not in ("ceo_cto", "manager") and a["requested_by"] != req.uid): raise ApiError("NOT_FOUND")
        if a["status"] != "pending": raise ApiError("CONFLICT")
        w.execute("UPDATE approvals SET status='cancelled' WHERE id=?", (a["id"],))
        if a["task_id"]: w.execute("UPDATE tasks SET status='todo', updated_at=? WHERE id=? AND status='awaiting_approval'", (utcnow(), a["task_id"]))
        req.audit(w, "approval.cancel", "approval", a["id"], {})
    return JSON({"ok": True})


# ---------------- scoped chat ----------------
def _thread(req, tid):
    t = one(req.c, "SELECT * FROM chat_threads WHERE id=? AND company_id=?", (tid, req.cid))
    if t and (t["scope_type"] == "company" or t["created_by"] == req.uid or req.uid in json.loads(t["participants_json"])): return t
    raise ApiError("NOT_FOUND")


@route("GET", "/api/chat/threads", perm="chat:use")
def chat_threads(req):
    out = []
    for t in rows(req.c, "SELECT * FROM chat_threads WHERE company_id=? ORDER BY id DESC LIMIT 300", (req.cid,)):
        p = json.loads(t["participants_json"])
        if t["scope_type"] == "company" or t["created_by"] == req.uid or req.uid in p: t["participants"] = p; del t["participants_json"]; out.append(t)
    return JSON({"items": out})


@route("POST", "/api/chat/threads", perm="chat:use")
def chat_new(req):
    spec = {"scope_type": ("enum", {"req": True, "values": ["company", "employee", "task", "room"]}), "scope_id": ("int", {"min": 1}), "title": S(req=True, max=200), "participant_ids": ("idlist", {})}
    v = clean(req.body, spec); st, sid = v["scope_type"], v.get("scope_id"); parts = set(v.get("participant_ids", [])) | {req.uid}
    if st != "company":
        tbl = {"employee": "employees", "task": "tasks", "room": "rooms"}[st]
        if not sid or not req.c.execute(f"SELECT 1 FROM {tbl} WHERE id=? AND company_id=?", (sid, req.cid)).fetchone(): raise ApiError("VALIDATION", {"scope_id": "not found in your company"})
        if st == "task": _task(req, sid)
        if st == "employee": parts.add(sid)
    for pid in parts:
        if not req.c.execute("SELECT 1 FROM employees WHERE id=? AND company_id=? AND is_active=1", (pid, req.cid)).fetchone(): raise ApiError("VALIDATION", {"participant_ids": "unknown participant"})
    with req.tx() as w:
        tid = w.execute("INSERT INTO chat_threads(company_id,scope_type,scope_id,title,created_by,participants_json,created_at) VALUES(?,?,?,?,?,?,?)",
                        (req.cid, st, sid, v["title"], req.uid, json.dumps(sorted(parts)), utcnow())).lastrowid
        req.audit(w, "chat.thread_create", "chat_thread", tid, {"scope": st, "scope_id": sid})
    return JSON({"id": tid, "scope_type": st, "scope_id": sid, "title": v["title"], "participants": sorted(parts)}, 201)


@route("GET", "/api/chat/threads/{id}/messages", perm="chat:use")
def chat_msgs(req):
    t = _thread(req, req.id()); after = int(req.query["after_id"]) if req.query.get("after_id", "").isdigit() else 0
    return JSON({"items": rows(req.c, "SELECT m.id,m.sender_id,e.display_name_en,e.display_name_ar,m.body,m.created_at FROM chat_messages m JOIN employees e ON e.id=m.sender_id "
                                       "WHERE m.thread_id=? AND m.id>? ORDER BY m.id LIMIT 200", (t["id"], after))})  # body is plain text: clients must escape


@route("POST", "/api/chat/threads/{id}/messages", perm="chat:use")
def chat_send(req):
    t = _thread(req, req.id())
    if not req.app.chat_limiter.allow(f"{req.cid}:{req.uid}"): raise ApiError("RATE_LIMITED")
    v = clean(req.body, {"body": S(req=True, max=4000)})
    with req.tx() as w:
        mid = w.execute("INSERT INTO chat_messages(thread_id,company_id,sender_id,body,created_at) VALUES(?,?,?,?,?)", (t["id"], req.cid, req.uid, v["body"], utcnow())).lastrowid
    return JSON({"id": mid}, 201)
