"""Audit, backups, retention, exports, health."""
import json
from .api import route, ApiError, JSON, Raw, clean, page
from .db import rows, one, utcnow
from . import audit, backup, retention, exports

# ---------------- audit ----------------
@route("GET", "/api/audit", perm="audit:read")
def audit_list(req):
    limit, off = page(req); where, a = ["company_id=?"], [req.cid]
    for f in ("action", "actor_username", "entity_type"):
        if req.query.get(f): where.append(f"{f}=?"); a.append(req.query[f][:80])
    w = " AND ".join(where)
    items = rows(req.c, f"SELECT seq,ts,actor_id,actor_username,action,entity_type,entity_id,summary_json,ip,substr(entry_hash,1,16) AS hash_prefix FROM audit_log WHERE {w} ORDER BY seq DESC LIMIT ? OFFSET ?", a + [limit, off])
    for i in items: i["summary"] = json.loads(i.pop("summary_json"))
    return JSON({"items": items, "total": req.c.execute(f"SELECT count(*) FROM audit_log WHERE {w}", a).fetchone()[0]})


@route("GET", "/api/audit/verify", perm="audit:read")
def audit_verify(req): return JSON(audit.verify_chain(req.c, req.app.audit_key, req.cid))


# ---------------- backups (platform-root CEO/CTO only) ----------------
@route("GET", "/api/backups/status", perm="backups:read", root_only=True)
def bk_status(req):
    runs = rows(req.c, "SELECT id,kind,status,size_bytes,sha256,started_at,finished_at,error,triggered_by,verified_at FROM backup_runs ORDER BY id DESC LIMIT 50")
    last = next((r for r in runs if r["status"] == "completed"), None)
    return JSON({"policy": backup.policy(req.app), "last_success": last, "runs": runs, "workers": rows(req.c, "SELECT * FROM worker_status")})


@route("POST", "/api/backups", perm="backups:manage", root_only=True)
def bk_create(req):
    try: return JSON(backup.run_backup(req.app, "manual", req.ctx["username"]), 201)
    except Exception: raise ApiError("BACKUP_FAILED")


@route("POST", "/api/backups/{id}/verify", perm="backups:manage", root_only=True)
def bk_verify(req): return JSON(backup.verify_backup(req.app, req.id(), req.ctx["username"]))


@route("PUT", "/api/backups/policy", perm="backups:manage", root_only=True)
def bk_policy(req):
    v = clean(req.body, {"enabled": ("bool", {"req": True}), "schedule": ("enum", {"req": True, "values": ["hourly", "daily", "weekly"]}), "keep_count": ("int", {"req": True, "min": 1, "max": 365})})
    with req.tx() as w:
        w.execute("UPDATE backup_policy SET enabled=?,schedule=?,keep_count=?,updated_by=?,updated_at=? WHERE id=1", (v["enabled"], v["schedule"], v["keep_count"], req.uid, utcnow()))
        req.audit(w, "backup.policy_update", "backup_policy", 1, v)
    return JSON(backup.policy(req.app))


# ---------------- retention ----------------
@route("GET", "/api/retention/rules", perm="retention:read")
def rt_rules(req): return JSON({"items": rows(req.c, "SELECT entity_type,retain_days,enabled FROM retention_rules WHERE company_id=?", (req.cid,)), "min_retention_days": req.cfg.min_retention_days,
                                "protected": ["active/planned/on-hold projects", "active clients", "pinned knowledge items", "audit log", "pending approvals"]})


@route("PUT", "/api/retention/rules", perm="retention:manage")
def rt_rules_put(req):
    v = clean(req.body, {"entity_type": ("enum", {"req": True, "values": list(retention.QUERIES)}), "retain_days": ("int", {"req": True, "min": 1, "max": 3650}), "enabled": ("bool", {"req": True})})
    if v["retain_days"] < req.cfg.min_retention_days: raise ApiError("VALIDATION", {"retain_days": f"minimum is {req.cfg.min_retention_days}"})
    with req.tx() as w:
        w.execute("INSERT INTO retention_rules(company_id,entity_type,retain_days,enabled) VALUES(?,?,?,?) ON CONFLICT(company_id,entity_type) DO UPDATE SET retain_days=excluded.retain_days, enabled=excluded.enabled",
                  (req.cid, v["entity_type"], v["retain_days"], v["enabled"]))
        req.audit(w, "retention.rule_update", "retention_rule", v["entity_type"], v)
    return rt_rules(req)


@route("POST", "/api/retention/dry-run", perm="retention:manage")
def rt_dry(req): return JSON(retention.dry_run(req.app, req.cid, req.uid, req.ctx["username"], req.ctx["username"]), 201)


@route("GET", "/api/retention/runs", perm="retention:read")
def rt_runs(req): return JSON({"items": [retention.public_run(r) for r in rows(req.c, "SELECT * FROM cleanup_runs WHERE company_id=? ORDER BY id DESC LIMIT 50", (req.cid,))]})


@route("POST", "/api/retention/runs/{id}/execute", perm="retention:manage")
def rt_exec(req):
    v = clean(req.body, {"confirm_phrase": ("str", {"req": True, "max": 60})})
    return JSON(retention.execute(req.app, req.cid, req.id(), v["confirm_phrase"], req.uid, req.ctx["username"]))


@route("POST", "/api/retention/runs/{id}/cancel", perm="retention:manage")
def rt_cancel(req):
    with req.tx() as w:
        n = w.execute("UPDATE cleanup_runs SET status='cancelled' WHERE id=? AND company_id=? AND status='pending_confirmation'", (req.id(), req.cid)).rowcount
        if not n: raise ApiError("CONFLICT")
        req.audit(w, "retention.cancel", "cleanup_run", req.id(), {})
    return JSON({"ok": True})


# ---------------- exports ----------------
@route("GET", "/api/export/executive-summary.{fmt}", perm="summary:read")
def ex_summary(req):
    body, fn, ct = exports.run_export(req.app, dict(req.ctx, ip=req.ip), "executive-summary", req.params["fmt"], req.query, req.query.get("lang", "bi"))
    return Raw(body, ct, fn)


@route("GET", "/api/export/{entity}.{fmt}")
def ex_entity(req):
    name = req.params["entity"].replace("-", "_")
    if name not in exports.ENT: raise ApiError("NOT_FOUND")
    from .rbac import can
    if not can(req.role, exports.ENT[name]["perm"]): raise ApiError("FORBIDDEN")
    body, fn, ct = exports.run_export(req.app, dict(req.ctx, ip=req.ip), name, req.params["fmt"], req.query, req.query.get("lang", "bi"))
    return Raw(body, ct, fn)


@route("GET", "/api/exports", perm="audit:read")
def ex_history(req): return JSON({"items": rows(req.c, "SELECT j.id,j.entity,j.format,j.lang,j.row_count,j.classification,j.sha256,j.bytes,j.created_at,e.username AS requested_by FROM export_jobs j JOIN employees e ON e.id=j.requested_by WHERE j.company_id=? ORDER BY j.id DESC LIMIT 100", (req.cid,))})


# ---------------- health ----------------
@route("GET", "/api/health", auth=False)
def health(req):
    req.c.execute("SELECT 1"); return JSON({"status": "ok", "time": utcnow()})


@route("GET", "/api/health/detail", perm="audit:read")
def health_detail(req):
    c = req.c; out = {"status": "ok", "time": utcnow(), "db_quick_check": c.execute("PRAGMA quick_check").fetchone()[0]}
    out["audit_chain"] = audit.verify_chain(c, req.app.audit_key, req.cid) if req.query.get("deep") == "1" else "skipped (add ?deep=1)"
    if req.ctx["is_platform_root"]:
        out["last_backup"] = one(c, "SELECT id,kind,finished_at,verified_at FROM backup_runs WHERE status='completed' ORDER BY id DESC LIMIT 1")
        out["workers"] = rows(c, "SELECT * FROM worker_status")
    if out["db_quick_check"] != "ok": out["status"] = "degraded"
    return JSON(out)


@route("GET", "/api/hq/summary", perm="summary:read")
def hq_summary(req): return JSON({"items": [{"label_en": a, "label_ar": b, "value": v} for a, b, v in exports.summary_data(req.app, req.ctx)]})
