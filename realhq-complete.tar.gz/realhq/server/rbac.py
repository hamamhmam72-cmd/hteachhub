"""Roles, permissions, data-classification clearance, task state machine."""
ROLES = ("ceo_cto", "manager", "member", "auditor")
CLASSES = ("internal", "confidential", "restricted")
CLEARANCE = {"ceo_cto": CLASSES, "auditor": CLASSES, "manager": CLASSES[:2], "member": CLASSES[:1]}

_EXPORTS = {f"export:{e}" for e in ("tasks", "clients", "leads", "projects", "approvals", "time_entries", "knowledge_items", "research_reports", "summary")}
PERMS = {
    "ceo_cto": {"*"},
    "manager": {"hq:read", "reference:read", "summary:read", "employees:read", "chat:use",
                "tasks:read", "tasks:write", "tasks:assign", "clients:read", "clients:write", "leads:read", "leads:write",
                "projects:read", "projects:write", "approvals:read", "approvals:request", "time_entries:read", "time_entries:write",
                "knowledge_items:read", "knowledge_items:write", "research_reports:read", "research_reports:write"} | _EXPORTS,
    "member": {"hq:read", "reference:read", "employees:read", "chat:use", "tasks:read", "tasks:write", "projects:read",
               "approvals:read", "approvals:request", "time_entries:read", "time_entries:write",
               "knowledge_items:read", "knowledge_items:write", "research_reports:read", "research_reports:write"},
    "auditor": {"*:read", "export:*"},  # strictly read-only
}


def can(role, perm):
    g = PERMS.get(role, set())
    ns, _, act = perm.partition(":")
    return "*" in g or perm in g or f"{ns}:*" in g or f"*:{act}" in g


def permission_list(role):
    allp = ["hq:read", "reference:read", "summary:read", "employees:read", "employees:manage", "chat:use", "audit:read",
            "approvals:decide", "backups:read", "backups:manage", "retention:read", "retention:manage"]
    for r in ("tasks", "clients", "leads", "projects", "approvals", "time_entries", "knowledge_items", "research_reports"):
        allp += [f"{r}:read", f"{r}:write", f"{r}:delete"]
    allp += sorted(_EXPORTS | {"export:employees", "export:audit_log"})
    return sorted({p for p in allp if can(role, p)})


# task state machine: from -> {to: min_role_level}. 'awaiting_approval/approved/rejected' are entered only via the approvals API.
LEVEL = {"member": 1, "manager": 2, "ceo_cto": 3}
TASK_TRANSITIONS = {
    "draft": {"todo": 1, "cancelled": 2},
    "todo": {"in_progress": 1, "cancelled": 2},
    "in_progress": {"todo": 1, "done": 1, "cancelled": 2},
    "awaiting_approval": {"cancelled": 2},
    "approved": {"in_progress": 1, "done": 1},
    "rejected": {"todo": 1, "cancelled": 2},
    "done": {"todo": 2},
    "cancelled": {"todo": 3},
}
