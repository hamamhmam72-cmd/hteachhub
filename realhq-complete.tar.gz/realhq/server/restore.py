"""Offline restore.  Stop the server first.   python -m server.restore <backup.db> [--apply]
Without --apply it only VERIFIES the snapshot (integrity, foreign keys, audit chain)."""
import argparse, os, shutil, sys, time
from pathlib import Path
from .config import Config
from .db import connect
from . import audit


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("backup"); ap.add_argument("--apply", action="store_true"); a = ap.parse_args()
    cfg = Config(); src = Path(a.backup).resolve(); key = audit.load_key(cfg)
    c = connect(src, readonly=True)
    ok = c.execute("PRAGMA integrity_check").fetchone()[0] == "ok" and c.execute("PRAGMA foreign_key_check").fetchone() is None
    chain = all(audit.verify_chain(c, key, r[0])["ok"] for r in c.execute("SELECT id FROM companies")); c.close()
    print(f"integrity+fk ok={ok}  audit_chain ok={chain}")
    if not (ok and chain): sys.exit("snapshot failed verification; refusing")
    if not a.apply: return print("verified (dry run). Re-run with --apply to restore.")
    if input("Type RESTORE to replace the live database: ") != "RESTORE": sys.exit("aborted")
    if cfg.db_path.exists(): shutil.copy2(cfg.db_path, cfg.db_path.with_suffix(f".pre-restore-{int(time.time())}")); 
    for s in ("-wal", "-shm"): Path(str(cfg.db_path) + s).unlink(missing_ok=True)
    shutil.copy2(src, cfg.db_path); os.chmod(cfg.db_path, 0o600); print("restored; start the server and check /api/health/detail?deep=1")


if __name__ == "__main__": main()
