"""Data lifecycle: dry-run -> CEO/CTO confirmation -> pre-cleanup backup + archive -> deletion. Never automatic."""
import hashlib, json, os
from pathlib import Path
from .db import rows, one, utcnow, iso_before, iso_after
from .api import ApiError
from . import audit, backup

# Every query hard-protects: active/planned/on-hold projects, active clients, pinned items. audit_log is never a candidate.
QUERIES = {
    "tasks_closed": ("tasks", "SELECT t.id FROM tasks t LEFT JOIN projects p ON p.id=t.project_id WHERE t.company_id=? AND t.status IN ('done','cancelled') "
                              "AND t.closed_at IS NOT NULL AND t.closed_at<? AND (p.id IS NULL OR p.status IN ('completed','cancelled'))"),
    "tasks_stale_drafts": ("tasks", "SELECT t.id FROM tasks t WHERE t.company_id=? AND t.status='draft' AND t.updated_at<? "
                                    "AND NOT EXISTS (SELECT 1 FROM time_entries te WHERE te.task_id=t.id)"),
    "leads_closed_lost": ("leads", "SELECT l.id FROM leads l WHERE l.company_id=? AND l.status='closed_lost' AND l.closed_at IS NOT NULL AND l.closed_at<? "
                                   "AND (l.client_id IS NULL OR l.client_id NOT IN (SELECT id FROM clients WHERE status='active'))"),
    "research_reports": ("research_reports", "SELECT r.id FROM research_reports r WHERE r.company_id=? AND r.status IN ('completed','failed') AND r.updated_at<?"),
}


def candidates(c, company_id, rules=None):
    out = {}
    for r in (rules or rows(c, "SELECT * FROM retention_rules WHERE company_id=? AND enabled=1", (company_id,))):
        out[r["entity_type"]] = [x[0] for x in c.execute(QUERIES[r["entity_type"]][1], (company_id, iso_before(r["retain_days"])))]
    return out


def dry_run(app, company_id, actor_id, actor_username, created_by):
    c = app.db.conn(); plan = candidates(c, company_id); counts = {k: len(v) for k, v in plan.items()}; total = sum(counts.values())
    status = "pending_confirmation" if total else "nothing_to_do"
    with app.db.tx() as w:
        rid = w.execute("INSERT INTO cleanup_runs(company_id,status,total_candidates,counts_json,plan_json,created_by,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)",
                        (company_id, status, total, json.dumps(counts), json.dumps(plan), created_by, utcnow(), iso_after(days=app.cfg.cleanup_plan_ttl_days))).lastrowid
        audit.log(w, app.audit_key, company_id, actor_id, actor_username, "retention.dry_run", "cleanup_run", rid, {"counts": counts, "total": total})
    return public_run(one(app.db.conn(), "SELECT * FROM cleanup_runs WHERE id=?", (rid,)))


def public_run(r):
    r = dict(r); r.pop("plan_json", None); r.pop("archive_path", None)
    for k in ("counts_json", "deleted_json"):
        if r.get(k): r[k[:-5]] = json.loads(r.pop(k))
        else: r.pop(k, None)
    r["confirmation_phrase"] = f"DELETE {r['total_candidates']} RECORDS" if r["status"] == "pending_confirmation" else None
    return r


def execute(app, company_id, run_id, phrase, actor_id, actor_username):
    c = app.db.conn(); run = one(c, "SELECT * FROM cleanup_runs WHERE id=? AND company_id=?", (run_id, company_id))
    if not run: raise ApiError("NOT_FOUND")
    if run["status"] != "pending_confirmation" or run["expires_at"] <= utcnow(): raise ApiError("CONFLICT", {"status": run["status"], "hint": "run a new dry-run"})
    if phrase != f"DELETE {run['total_candidates']} RECORDS": raise ApiError("CONFIRMATION_REQUIRED", {"expected": f"DELETE {run['total_candidates']} RECORDS"})
    with app.db.tx() as w:  # claim the run so it can't be executed twice
        if w.execute("UPDATE cleanup_runs SET status='executing', confirmed_by=? WHERE id=? AND status='pending_confirmation'", (actor_id, run_id)).rowcount != 1: raise ApiError("CONFLICT")
    try:
        bk = backup.run_backup(app, "pre_cleanup", actor_username)                       # 1) mandatory snapshot, abort on failure
        planned = json.loads(run["plan_json"]); now_ok = candidates(app.db.conn(), company_id)
        final = {k: sorted(set(v) & set(now_ok.get(k, []))) for k, v in planned.items()}  # 2) only what is STILL eligible AND was approved
        archive = {"cleanup_run": run_id, "company_id": company_id, "created_at": utcnow(), "rows": {}}
        for k, ids in final.items():
            tbl = QUERIES[k][0]; archive["rows"][k] = []
            for i in range(0, len(ids), 500):
                ch = ids[i:i + 500]; archive["rows"][k] += rows(app.db.conn(), f"SELECT * FROM {tbl} WHERE company_id=? AND id IN ({','.join('?' * len(ch))})", [company_id] + ch)
            if k.startswith("tasks"):
                archive["rows"][k + "_time_entries"] = [r for i in range(0, len(ids), 500) for r in rows(app.db.conn(), f"SELECT * FROM time_entries WHERE task_id IN ({','.join('?' * len(ids[i:i+500]))})", ids[i:i + 500])]
        d = app.cfg.archive_dir / str(company_id); d.mkdir(parents=True, exist_ok=True); os.chmod(d, 0o700)
        ap = d / f"cleanup-{run_id}.json"; blob = json.dumps(archive, ensure_ascii=False, default=str, indent=1).encode()
        fd = os.open(ap, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f: f.write(blob)                                      # 3) archive before deletion
        deleted = {}
        with app.db.tx() as w:                                                            # 4) delete atomically
            for k, ids in final.items():
                tbl, n = QUERIES[k][0], 0
                if k.startswith("tasks"): deleted[k + "_time_entries_cascaded"] = sum(w.execute(f"SELECT count(*) FROM time_entries WHERE task_id IN ({','.join('?' * len(ids[i:i+500]))})", ids[i:i + 500]).fetchone()[0] for i in range(0, len(ids), 500))
                for i in range(0, len(ids), 500):
                    ch = ids[i:i + 500]; n += w.execute(f"DELETE FROM {tbl} WHERE company_id=? AND id IN ({','.join('?' * len(ch))})", [company_id] + ch).rowcount
                deleted[k] = n
            sha = hashlib.sha256(blob).hexdigest()
            w.execute("UPDATE cleanup_runs SET status='executed', deleted_json=?, backup_run_id=?, archive_path=?, archive_sha256=?, executed_at=? WHERE id=?",
                      (json.dumps(deleted), bk["id"], str(ap), sha, utcnow(), run_id))
            audit.log(w, app.audit_key, company_id, actor_id, actor_username, "retention.execute", "cleanup_run", run_id, {"deleted": deleted, "backup_run_id": bk["id"], "archive_sha256": sha})
    except Exception as e:
        with app.db.tx() as w:
            w.execute("UPDATE cleanup_runs SET status='failed', error=? WHERE id=?", (str(e)[:300], run_id))
            audit.log(w, app.audit_key, company_id, actor_id, actor_username, "retention.failed", "cleanup_run", run_id, {"error": str(e)[:200]})
        if isinstance(e, ApiError): raise
        raise ApiError("BACKUP_FAILED" if "backup" in str(e).lower() else "INTERNAL")
    return public_run(one(app.db.conn(), "SELECT * FROM cleanup_runs WHERE id=?", (run_id,)))
