-- RealHQ Studio / H-teach hub  --  schema v1  (SQLite)
-- Conventions: every tenant table carries company_id; timestamps are UTC ISO-8601 text; bilingual fields *_ar / *_en.
CREATE TABLE companies (
  id INTEGER PRIMARY KEY, slug TEXT NOT NULL UNIQUE,
  name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  parent_id INTEGER REFERENCES companies(id),
  kind TEXT NOT NULL DEFAULT 'enterprise' CHECK(kind IN ('enterprise','platform','unit')),
  is_platform_root INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL);

CREATE TABLE departments (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  code TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, UNIQUE(company_id, code));

CREATE TABLE rooms (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  code TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  department_id INTEGER REFERENCES departments(id),
  kind TEXT NOT NULL DEFAULT 'office' CHECK(kind IN ('executive','office','lab','ops')),
  grid_x INTEGER NOT NULL DEFAULT 0, grid_y INTEGER NOT NULL DEFAULT 0,
  grid_w INTEGER NOT NULL DEFAULT 4, grid_h INTEGER NOT NULL DEFAULT 3, UNIQUE(company_id, code));

CREATE TABLE skills (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  code TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, UNIQUE(company_id, code));

CREATE TABLE employees (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  username TEXT NOT NULL, email TEXT UNIQUE,
  display_name_ar TEXT NOT NULL, display_name_en TEXT NOT NULL,
  role_ar TEXT NOT NULL, role_en TEXT NOT NULL,
  department_id INTEGER REFERENCES departments(id), room_id INTEGER REFERENCES rooms(id),
  desk_slot INTEGER NOT NULL DEFAULT 0,
  bio_ar TEXT NOT NULL DEFAULT '', bio_en TEXT NOT NULL DEFAULT '',
  rbac_role TEXT NOT NULL CHECK(rbac_role IN ('ceo_cto','manager','member','auditor')),
  password_hash TEXT NOT NULL DEFAULT '!',            -- '!' = no password set (cannot log in)
  must_change_password INTEGER NOT NULL DEFAULT 1,
  is_active INTEGER NOT NULL DEFAULT 1, is_demo INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until TEXT, last_login_at TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE(company_id, username));

CREATE TABLE employee_skills (
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE, PRIMARY KEY(employee_id, skill_id));

CREATE TABLE sessions (
  id INTEGER PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE,        -- sha256(token); raw token only lives in the cookie
  employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL REFERENCES companies(id),
  csrf_token TEXT NOT NULL, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, expires_at TEXT NOT NULL,
  revoked_at TEXT, ip TEXT, user_agent TEXT);
CREATE INDEX ix_sessions_emp ON sessions(employee_id);

CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  seq INTEGER NOT NULL, ts TEXT NOT NULL,
  actor_id INTEGER, actor_username TEXT NOT NULL,
  action TEXT NOT NULL, entity_type TEXT, entity_id TEXT, summary_json TEXT NOT NULL DEFAULT '{}', ip TEXT,
  prev_hash TEXT NOT NULL, entry_hash TEXT NOT NULL,              -- HMAC-SHA256 hash chain per company
  UNIQUE(company_id, seq));
CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT,'audit_log is append-only'); END;
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT,'audit_log is append-only'); END;

CREATE TABLE clients (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  name TEXT NOT NULL, contact_email TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','archived')),
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  pinned INTEGER NOT NULL DEFAULT 0, notes TEXT, created_by INTEGER REFERENCES employees(id),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, closed_at TEXT);

CREATE TABLE leads (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  name TEXT NOT NULL, source TEXT, status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new','contacted','qualified','proposal','closed_won','closed_lost')),
  est_value REAL, owner_id INTEGER REFERENCES employees(id), client_id INTEGER REFERENCES clients(id),
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  notes TEXT, created_by INTEGER REFERENCES employees(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL, closed_at TEXT);

CREATE TABLE projects (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  client_id INTEGER REFERENCES clients(id), name TEXT NOT NULL, description TEXT,
  status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','active','on_hold','completed','cancelled')),
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  start_date TEXT, due_date TEXT, created_by INTEGER REFERENCES employees(id),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, closed_at TEXT);

CREATE TABLE tasks (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  project_id INTEGER REFERENCES projects(id), title TEXT NOT NULL, description TEXT,
  status TEXT NOT NULL DEFAULT 'todo' CHECK(status IN ('draft','todo','in_progress','awaiting_approval','approved','rejected','done','cancelled')),
  priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN ('low','normal','high','urgent')),
  assignee_id INTEGER REFERENCES employees(id), created_by INTEGER REFERENCES employees(id), due_date TEXT,
  external_action INTEGER NOT NULL DEFAULT 0,       -- 1 => cannot reach 'done' without an approved CEO/CTO approval
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, closed_at TEXT);
CREATE INDEX ix_tasks_co_status ON tasks(company_id, status);
CREATE INDEX ix_tasks_assignee ON tasks(assignee_id, status);

CREATE TABLE approvals (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
  kind TEXT NOT NULL CHECK(kind IN ('pricing','external_action','repo_change','security_exception','backup_retention','account_provisioning','role_activation','other')),
  title TEXT NOT NULL, description TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','cancelled')),
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  requested_by INTEGER NOT NULL REFERENCES employees(id), decided_by INTEGER REFERENCES employees(id),
  decision_note TEXT, created_at TEXT NOT NULL, decided_at TEXT);
CREATE INDEX ix_appr_co_status ON approvals(company_id, status);

CREATE TABLE time_entries (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE, employee_id INTEGER NOT NULL REFERENCES employees(id),
  minutes INTEGER NOT NULL CHECK(minutes BETWEEN 1 AND 1440), work_date TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL);

CREATE TABLE knowledge_items (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', tags TEXT, pinned INTEGER NOT NULL DEFAULT 0,
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  created_by INTEGER REFERENCES employees(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL);

CREATE TABLE research_reports (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  title TEXT NOT NULL, query TEXT, status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','running','completed','failed')),
  summary TEXT,                                      -- external snippets are stored as inert text, never executed
  classification TEXT NOT NULL DEFAULT 'internal' CHECK(classification IN ('internal','confidential','restricted')),
  created_by INTEGER REFERENCES employees(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL);

CREATE TABLE chat_threads (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  scope_type TEXT NOT NULL CHECK(scope_type IN ('company','employee','task','room')), scope_id INTEGER,
  title TEXT NOT NULL, created_by INTEGER NOT NULL REFERENCES employees(id),
  participants_json TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
CREATE TABLE chat_messages (
  id INTEGER PRIMARY KEY, thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
  company_id INTEGER NOT NULL REFERENCES companies(id), sender_id INTEGER NOT NULL REFERENCES employees(id),
  body TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX ix_msgs_thread ON chat_messages(thread_id, id);

-- Whole-database backups => platform-level (managed by the platform-root CEO/CTO only).
CREATE TABLE backup_policy (
  id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 1,
  schedule TEXT NOT NULL DEFAULT 'daily' CHECK(schedule IN ('hourly','daily','weekly')),
  keep_count INTEGER NOT NULL DEFAULT 14 CHECK(keep_count BETWEEN 1 AND 365),
  updated_by INTEGER, updated_at TEXT NOT NULL);
CREATE TABLE backup_runs (
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('scheduled','manual','pre_cleanup')),
  status TEXT NOT NULL CHECK(status IN ('running','completed','failed','rotated')),
  path TEXT, size_bytes INTEGER, sha256 TEXT, started_at TEXT NOT NULL, finished_at TEXT,
  error TEXT, triggered_by TEXT NOT NULL DEFAULT 'system', verified_at TEXT, verify_result TEXT);

CREATE TABLE retention_rules (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  entity_type TEXT NOT NULL CHECK(entity_type IN ('tasks_closed','tasks_stale_drafts','leads_closed_lost','research_reports')),
  retain_days INTEGER NOT NULL DEFAULT 365, enabled INTEGER NOT NULL DEFAULT 1, UNIQUE(company_id, entity_type));
CREATE TABLE cleanup_runs (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  status TEXT NOT NULL CHECK(status IN ('pending_confirmation','nothing_to_do','executing','executed','failed','cancelled','expired')),
  total_candidates INTEGER NOT NULL DEFAULT 0, counts_json TEXT NOT NULL DEFAULT '{}', plan_json TEXT NOT NULL DEFAULT '{}',
  deleted_json TEXT, backup_run_id INTEGER REFERENCES backup_runs(id), archive_path TEXT, archive_sha256 TEXT, error TEXT,
  created_by TEXT NOT NULL, confirmed_by INTEGER, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, executed_at TEXT);

CREATE TABLE export_jobs (
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  entity TEXT NOT NULL, format TEXT NOT NULL, lang TEXT NOT NULL, filters_json TEXT NOT NULL DEFAULT '{}',
  row_count INTEGER NOT NULL, classification TEXT NOT NULL, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
  requested_by INTEGER NOT NULL REFERENCES employees(id), created_at TEXT NOT NULL);

CREATE TABLE worker_status (
  name TEXT PRIMARY KEY, last_run_at TEXT, last_ok_at TEXT, last_error TEXT, consecutive_failures INTEGER NOT NULL DEFAULT 0, next_run_at TEXT);
