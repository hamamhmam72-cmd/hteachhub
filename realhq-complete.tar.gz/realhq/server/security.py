"""Password hashing/policy, rate limiting, session tokens."""
import base64, hashlib, hmac, os, re, secrets, threading, time
from collections import defaultdict, deque

from .db import utcnow, iso_after, one

_COMMON = {"password123!", "qwerty123456", "welcome12345", "letmein12345", "admin1234567", "p@ssw0rd1234"}
_dummy_cache = {}


def _b64(b): return base64.b64encode(b).decode()


def hash_password(pw, iters):
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, iters, 32)
    return f"pbkdf2_sha256${iters}${_b64(salt)}${_b64(dk)}"


def verify_password(pw, stored, default_iters=600_000):
    """Constant-ish time: unknown/disabled accounts still burn one PBKDF2 round to blunt user enumeration."""
    try:
        algo, iters, salt, dk = (stored or "").split("$")
        if algo != "pbkdf2_sha256":
            raise ValueError
        iters = int(iters); salt = base64.b64decode(salt); dk = base64.b64decode(dk)
    except Exception:
        hashlib.pbkdf2_hmac("sha256", pw.encode(), b"\0" * 16, default_iters, 32)
        return False
    return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, iters, len(dk)), dk)


def needs_rehash(stored, iters):
    try:
        return int(stored.split("$")[1]) < iters
    except Exception:
        return False


def password_problems(pw, username="", email=""):
    p = []
    if not isinstance(pw, str) or len(pw) < 12: p.append("min_length_12")
    if isinstance(pw, str) and len(pw.encode()) > 256: p.append("max_length_256_bytes")
    if not isinstance(pw, str): return p
    if not re.search(r"[a-z]", pw): p.append("needs_lowercase")
    if not re.search(r"[A-Z]", pw): p.append("needs_uppercase")
    if not re.search(r"\d", pw): p.append("needs_digit")
    if not re.search(r"[^\w\s]|_", pw): p.append("needs_symbol")
    low = pw.lower()
    for bad in (username, (email or "").split("@")[0]):
        if bad and len(bad) >= 3 and bad.lower() in low: p.append("contains_username")
    if low in _COMMON: p.append("too_common")
    return sorted(set(p))


class RateLimiter:
    def __init__(self, window, limit):
        self.window, self.limit = window, limit
        self._hits = defaultdict(deque); self._lock = threading.Lock()

    def allow(self, key):
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > self.window: q.popleft()
            if len(q) >= self.limit: return False
            q.append(now)
            if len(self._hits) > 50_000:  # bound memory
                for k in [k for k, v in self._hits.items() if not v][:10_000]: self._hits.pop(k, None)
            return True


def _sha(s): return hashlib.sha256(s.encode()).hexdigest()


def create_session(c, emp, ip, ua, cfg):
    token = secrets.token_urlsafe(32); csrf = secrets.token_urlsafe(24); now = utcnow()
    c.execute("INSERT INTO sessions(token_hash,employee_id,company_id,csrf_token,created_at,last_seen_at,expires_at,ip,user_agent)"
              " VALUES(?,?,?,?,?,?,?,?,?)",
              (_sha(token), emp["id"], emp["company_id"], csrf, now, now, iso_after(cfg.session_abs_seconds), ip, (ua or "")[:200]))
    return token, csrf


def lookup_session(db, token, cfg):
    """Returns session+employee context or None. last_seen is only written when >60 s stale (cheap reads)."""
    if not token or len(token) > 100: return None
    c = db.conn()
    s = one(c, "SELECT s.*, e.username, e.rbac_role, e.is_active, e.must_change_password, e.display_name_en, e.display_name_ar,"
               " co.is_active AS co_active, co.is_platform_root FROM sessions s JOIN employees e ON e.id=s.employee_id"
               " JOIN companies co ON co.id=s.company_id WHERE s.token_hash=?", (_sha(token),))
    if not s or s["revoked_at"] or not s["is_active"] or not s["co_active"]: return None
    now = utcnow()
    if s["expires_at"] <= now: return None
    from datetime import datetime, timezone
    last = datetime.strptime(s["last_seen_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    age = (datetime.now(timezone.utc) - last).total_seconds()
    if age > cfg.session_idle_seconds: return None
    if age > 60:
        with db.tx() as w: w.execute("UPDATE sessions SET last_seen_at=? WHERE id=?", (now, s["id"]))
    return s


def revoke_session(c, session_id): c.execute("UPDATE sessions SET revoked_at=? WHERE id=? AND revoked_at IS NULL", (utcnow(), session_id))
def revoke_all(c, employee_id, except_id=None):
    c.execute("UPDATE sessions SET revoked_at=? WHERE employee_id=? AND revoked_at IS NULL AND id IS NOT ?", (utcnow(), employee_id, except_id))


def cookie_header(cfg, token, max_age):
    parts = [f"{cfg.cookie_name}={token}", "Path=/", "HttpOnly", "SameSite=Strict", f"Max-Age={max_age}"]
    if cfg.cookie_secure: parts.append("Secure")
    return "; ".join(parts)
