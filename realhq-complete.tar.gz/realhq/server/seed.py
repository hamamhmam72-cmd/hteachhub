"""Bilingual seed data: H-teach hub (enterprise) + RealHQ Studio (platform) + Hammam Alhwamdeh as Founder, CEO & CTO."""
import secrets
from .db import utcnow, iso_before
from . import audit
from .security import hash_password, password_problems

DEPTS = [
    ("exec", "المكتب التنفيذي", "Executive Office"), ("eng", "الهندسة", "Engineering"),
    ("design", "المنتج والتصميم", "Product & Design"), ("sec", "الأمن والخصوصية", "Security & Privacy"),
    ("ops", "العمليات", "Operations"), ("growth", "النمو والمبيعات", "Growth & Sales"), ("edu", "المحتوى التعليمي", "Education Content"),
]
ROOMS = [  # code, dept, kind, x, y, w, h
    ("exec-office", "exec", "executive", 0, 0, 4, 3, "المكتب التنفيذي", "Executive Office"),
    ("eng-bay", "eng", "office", 4, 0, 4, 3, "قاعة الهندسة", "Engineering Bay"),
    ("design-studio", "design", "lab", 8, 0, 4, 3, "استوديو المنتج والتصميم", "Product & Design Studio"),
    ("sec-room", "sec", "lab", 0, 3, 4, 3, "غرفة الأمن والخصوصية", "Security & Privacy Room"),
    ("ops-desk", "ops", "ops", 4, 3, 4, 3, "مكتب العمليات", "Operations Desk"),
    ("growth-hub", "growth", "office", 8, 3, 4, 3, "مركز النمو", "Growth Hub"),
    ("edu-lab", "edu", "lab", 0, 6, 6, 2, "مختبر المحتوى التعليمي", "Education Content Lab"),
]
SKILLS = [("sysarch", "هندسة الأنظمة", "Systems Architecture"), ("seceng", "هندسة الأمن", "Security Engineering"),
          ("uiux", "تصميم الواجهات وتجربة المستخدم", "UI/UX Design"), ("privacy", "خصوصية البيانات", "Data Privacy"),
          ("pm", "إدارة المشاريع", "Project Management"), ("curric", "تصميم المناهج", "Curriculum Design"),
          ("cs", "نجاح العملاء", "Customer Success"), ("arcontent", "المحتوى العربي", "Arabic Content")]
RET = ("tasks_closed", "tasks_stale_drafts", "leads_closed_lost", "research_reports")

# username, ar name, en name, role_ar, role_en, rbac, dept, room, skills
TEAM = [
    ("demo.eng", "قائد الهندسة (تجريبي)", "Engineering Lead (Demo)", "قائد الهندسة", "Engineering Lead", "manager", "eng", "eng-bay", ["sysarch", "seceng"]),
    ("demo.design", "مصمم المنتج (تجريبي)", "Product Designer (Demo)", "مصمم منتج", "Product Designer", "member", "design", "design-studio", ["uiux"]),
    ("demo.sec", "مهندس الأمن والخصوصية (تجريبي)", "Security & Privacy Engineer (Demo)", "مهندس أمن وخصوصية", "Security & Privacy Engineer", "member", "sec", "sec-room", ["seceng", "privacy"]),
    ("demo.ops", "منسق العمليات (تجريبي)", "Operations Coordinator (Demo)", "منسق عمليات", "Operations Coordinator", "member", "ops", "ops-desk", ["pm"]),
    ("demo.edu", "أخصائي المحتوى التعليمي (تجريبي)", "Education Content Specialist (Demo)", "أخصائي محتوى تعليمي", "Education Content Specialist", "member", "edu", "edu-lab", ["curric", "arcontent"]),
    ("demo.audit", "المدقق الداخلي (تجريبي)", "Internal Auditor (Demo)", "مدقق داخلي", "Internal Auditor", "auditor", "sec", "sec-room", ["privacy"]),
]


def seed_company(c, cfg, key):
    now = utcnow()
    c.execute("INSERT INTO companies(id,slug,name_ar,name_en,kind,is_platform_root,created_at) VALUES(1,'h-teach-hub','إتش-تيتش هب','H-teach hub','enterprise',1,?)", (now,))
    c.execute("INSERT INTO companies(id,slug,name_ar,name_en,parent_id,kind,created_at) VALUES(2,'realhq-studio','ريل إتش كيو ستوديو','RealHQ Studio',1,'platform',?)", (now,))
    dept, room, skill = {}, {}, {}
    for code, ar, en in DEPTS:
        dept[code] = c.execute("INSERT INTO departments(company_id,code,name_ar,name_en) VALUES(1,?,?,?)", (code, ar, en)).lastrowid
    for code, d, kind, x, y, w, h, ar, en in ROOMS:
        room[code] = c.execute("INSERT INTO rooms(company_id,code,name_ar,name_en,department_id,kind,grid_x,grid_y,grid_w,grid_h) VALUES(1,?,?,?,?,?,?,?,?,?)",
                               (code, ar, en, dept[d], kind, x, y, w, h)).lastrowid
    for code, ar, en in SKILLS:
        skill[code] = c.execute("INSERT INTO skills(company_id,code,name_ar,name_en) VALUES(1,?,?,?)", (code, ar, en)).lastrowid
    for e in RET:
        c.execute("INSERT INTO retention_rules(company_id,entity_type,retain_days,enabled) VALUES(1,?,365,1)", (e,))
    c.execute("INSERT INTO backup_policy(id,enabled,schedule,keep_count,updated_at) VALUES(1,1,'daily',14,?)", (now,))

    pw = cfg.bootstrap_password or secrets.token_urlsafe(18) + "aZ9!"
    if password_problems(pw, "hammam"): raise SystemExit("REALHQ_BOOTSTRAP_PASSWORD does not meet the password policy")
    ceo = c.execute(
        "INSERT INTO employees(company_id,username,display_name_ar,display_name_en,role_ar,role_en,department_id,room_id,desk_slot,bio_ar,bio_en,"
        "rbac_role,password_hash,must_change_password,created_at,updated_at) VALUES(1,'hammam',?,?,?,?,?,?,0,?,?,'ceo_cto',?,1,?,?)",
        ("همام الحوامدة", "Hammam Alhwamdeh", "المؤسس والرئيس التنفيذي ورئيس التقنية", "Founder, CEO & CTO", dept["exec"], room["exec-office"],
         "مؤسس إتش-تيتش هب والمسؤول النهائي عن جميع القرارات الاستراتيجية والتقنية.",
         "Founder of H-teach hub and final decision-maker for all strategic and technical approvals.",
         hash_password(pw, cfg.pbkdf2_iters), now, now)).lastrowid
    for s in ("sysarch", "seceng", "pm"): c.execute("INSERT INTO employee_skills VALUES(?,?)", (ceo, skill[s]))
    audit.log(c, key, 1, None, "system", "system.seed", "company", 1, {"note": "initial bootstrap"})
    ids = {"ceo": ceo}
    if cfg.seed_demo:
        for i, (u, nar, nen, rar, ren, rbac, d, r, sk) in enumerate(TEAM, start=1):
            eid = c.execute("INSERT INTO employees(company_id,username,display_name_ar,display_name_en,role_ar,role_en,department_id,room_id,desk_slot,"
                            "bio_ar,bio_en,rbac_role,password_hash,is_demo,created_at,updated_at) VALUES(1,?,?,?,?,?,?,?,?, '', '', ?, '!',1,?,?)",
                            (u, nar, nen, rar, ren, dept[d], room[r], i, rbac, now, now)).lastrowid
            for s in sk: c.execute("INSERT INTO employee_skills VALUES(?,?)", (eid, skill[s]))
            ids[u] = eid
        cl = c.execute("INSERT INTO clients(company_id,name,status,created_by,created_at,updated_at) VALUES(1,'Demo School / مدرسة تجريبية','active',?,?,?)", (ceo, now, now)).lastrowid
        pr = c.execute("INSERT INTO projects(company_id,client_id,name,status,created_by,created_at,updated_at) VALUES(1,?,'LMS Pilot / تجربة منصة التعلم','active',?,?,?)", (cl, ceo, now, now)).lastrowid
        def task(t, st, who, ext=0):
            return c.execute("INSERT INTO tasks(company_id,project_id,title,status,assignee_id,created_by,external_action,created_at,updated_at) VALUES(1,?,?,?,?,?,?,?,?)",
                             (pr, t, st, ids[who], ceo, ext, now, now)).lastrowid
        task("Build course catalog API / بناء واجهة كتالوج المقررات", "in_progress", "demo.eng")
        task("Design onboarding screens / تصميم شاشات الانضمام", "in_progress", "demo.design")
        t3 = task("Send pricing proposal to client / إرسال عرض السعر للعميل", "awaiting_approval", "demo.ops", 1)
        task("Draft privacy notice / صياغة إشعار الخصوصية", "todo", "demo.sec")
        c.execute("INSERT INTO approvals(company_id,task_id,kind,title,description,requested_by,created_at) VALUES(1,?,'pricing','Pricing proposal / عرض السعر','Draft only: not sent until approved.',?,?)", (t3, ids["demo.ops"], now))
        c.execute("INSERT INTO leads(company_id,name,source,status,est_value,owner_id,created_by,created_at,updated_at) VALUES(1,'Demo Academy / أكاديمية تجريبية','referral','qualified',12000,?,?,?,?)", (ids["demo.ops"], ceo, now, now))
        c.execute("INSERT INTO knowledge_items(company_id,title,body,pinned,created_by,created_at,updated_at) VALUES(1,'Security handbook / دليل الأمن','Pinned policy.',1,?,?,?)", (ceo, now, now))
        c.execute("INSERT INTO research_reports(company_id,title,query,status,summary,created_by,created_at,updated_at) VALUES(1,'EdTech market scan / مسح سوق التقنية التعليمية','edtech jordan','completed','Demo.',?,?,?)", (ceo, now, now))
    return pw if not cfg.bootstrap_password else None
