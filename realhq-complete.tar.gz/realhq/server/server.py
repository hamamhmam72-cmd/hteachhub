"""RealHQ Studio backend: stdlib HTTP server wiring (security headers, CSRF, RBAC, rate limits, size limits)."""
import hmac, json, logging, os, signal, sys, threading, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qsl, quote

from .config import Config
from .db import Database
from . import api, audit, security as sec, seed, workers
from .api import ApiError, JSON, Raw, Request, ROUTES
from .rbac import can
from . import handlers_auth, handlers_data, handlers_ops  # noqa: F401  (register routes)

log = logging.getLogger("realhq")
SEC_HEADERS = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Cache-Control": "no-store",
               "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'", "Cross-Origin-Resource-Policy": "same-origin"}
STATIC = {"/": ("index.html", "text/html; charset=utf-8"), "/app.css": ("app.css", "text/css; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8")}
UI_HEADERS = dict(SEC_HEADERS, **{"Cache-Control": "no-cache", "Content-Security-Policy":
    "default-src 'none'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src data:; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"})
WEB_DIR = __import__("pathlib").Path(__file__).resolve().parent.parent / "web"
MUTATING = {"POST", "PUT", "PATCH", "DELETE"}
OPEN_WHEN_MUST_CHANGE = {"/api/auth/me", "/api/auth/logout", "/api/auth/change-password"}


class App:
    def __init__(self, cfg=None):
        self.cfg = cfg or Config(); self.cfg.ensure_dirs(); self.db = Database(self.cfg)
        self.login_limiter = sec.RateLimiter(600, self.cfg.login_ip_limit); self.global_limiter = sec.RateLimiter(60, self.cfg.global_ip_limit)
        self.chat_limiter = sec.RateLimiter(60, 30); self.slots = threading.BoundedSemaphore(self.cfg.max_concurrent)
        self.audit_key = audit.load_key(self.cfg); self.workers = []
        self.bootstrap_pw = None
        if self.db.init_schema():
            with self.db.tx() as c: self.bootstrap_pw = seed.seed_company(c, self.cfg, self.audit_key)
        workers.recover(self)

    def start_workers(self): self.workers = workers.start_all(self)
    def stop(self):
        for w in self.workers: w.stop_evt.set()


def make_handler(app):
    cfg = app.cfg

    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"; timeout = cfg.socket_timeout; server_version = "RealHQ"; sys_version = ""

        def log_message(self, fmt, *a): log.info("%s %s", self.client_address[0], fmt % a)
        def ip(self):
            if cfg.trust_proxy and self.headers.get("X-Forwarded-For"): return self.headers["X-Forwarded-For"].split(",")[-1].strip()[:45]
            return self.client_address[0]

        def send(self, status, body, ctype, headers=None, filename=None, close=False, sec=None):
            self.send_response(status); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
            for k, v in (sec or SEC_HEADERS).items(): self.send_header(k, v)
            if filename: self.send_header("Content-Disposition", f"attachment; filename=\"{filename}\"; filename*=UTF-8''{quote(filename)}")
            for k, v in (headers or {}).items(): self.send_header(k, v)
            if close: self.send_header("Connection", "close"); self.close_connection = True
            self.end_headers()
            if self.command != "HEAD": self.wfile.write(body)

        def err(self, e, close=False):
            body = json.dumps({"error": {"code": e.code, "message_en": e.en, "message_ar": e.ar, "details": e.details}}, ensure_ascii=False).encode()
            self.send(e.status, body, "application/json; charset=utf-8", close=close)

        def handle_one(self):
            if not app.slots.acquire(timeout=5): return self.err(ApiError("RATE_LIMITED"), True)
            try: self._handle()
            except (BrokenPipeError, ConnectionResetError, TimeoutError): self.close_connection = True
            except ApiError as e: self.err(e)
            except Exception:
                eid = uuid.uuid4().hex[:8]; log.exception("unhandled error id=%s", eid)
                self.err(ApiError("INTERNAL", {"error_id": eid}), True)
            finally: app.slots.release()

        def _handle(self):
            ip = self.ip(); u = urlsplit(self.path); path = u.path.rstrip("/") or "/"
            if not app.global_limiter.allow(ip): raise ApiError("RATE_LIMITED")
            try: n = int(self.headers.get("Content-Length") or 0)
            except ValueError: raise ApiError("BAD_REQUEST")
            if self.headers.get("Transfer-Encoding"): self.close_connection = True; raise ApiError("BAD_REQUEST")
            if n < 0 or n > cfg.max_body: self.close_connection = True; raise ApiError("PAYLOAD_TOO_LARGE")
            raw = self.rfile.read(n) if n else b""
            body = None
            if raw:
                if "application/json" not in (self.headers.get("Content-Type") or ""): raise ApiError("UNSUPPORTED_MEDIA")
                try: body = json.loads(raw)
                except ValueError: raise ApiError("BAD_REQUEST", {"_": "invalid JSON"})
            if self.command in MUTATING and body is None: body = {}
            if path in STATIC and self.command in ("GET", "HEAD"):  # fixed whitelist: no path traversal possible
                fn, ct = STATIC[path]; f = WEB_DIR / fn
                if not f.exists(): raise ApiError("NOT_FOUND")
                return self.send(200, f.read_bytes(), ct, sec=UI_HEADERS)
            method = "GET" if self.command == "HEAD" else self.command; match = None; allowed = False
            for m, rx, fn, opts in ROUTES:
                r = rx.fullmatch(path)
                if r:
                    allowed = True
                    if m == method: match = (fn, opts, r.groupdict()); break
            if not match: raise ApiError("METHOD_NOT_ALLOWED" if allowed else "NOT_FOUND")
            fn, opts, params = match; ctx = None
            if opts["auth"]:
                ck = self.headers.get("Cookie") or ""; tok = next((v for k, v in (p.strip().partition("=")[::2] for p in ck.split(";")) if k == cfg.cookie_name), None)
                ctx = sec.lookup_session(app.db, tok, cfg)
                if not ctx: raise ApiError("UNAUTHENTICATED")
                ctx["ip"] = ip
                if method in MUTATING:
                    origin = self.headers.get("Origin")
                    if origin and urlsplit(origin).netloc != self.headers.get("Host"): raise ApiError("CSRF")
                    if not hmac.compare_digest(self.headers.get("X-CSRF-Token") or "", ctx["csrf_token"]): raise ApiError("CSRF")
                if ctx["must_change_password"] and path not in OPEN_WHEN_MUST_CHANGE: raise ApiError("PASSWORD_CHANGE_REQUIRED")
                if opts["perm"] and not can(ctx["rbac_role"], opts["perm"]): raise ApiError("FORBIDDEN")
                if opts["root_only"] and not (ctx["is_platform_root"] and ctx["rbac_role"] in ("ceo_cto", "auditor")): raise ApiError("FORBIDDEN")
                if opts["root_only"] and method in MUTATING and ctx["rbac_role"] != "ceo_cto": raise ApiError("FORBIDDEN")
            req = Request(app, method, path, dict(parse_qsl(u.query, keep_blank_values=True)), body, ip, self.headers, ctx, params)
            res = fn(req)
            if isinstance(res, Raw): self.send(res.status, res.body, res.ctype, res.headers, res.filename)
            else: self.send(res.status, json.dumps(res.data, ensure_ascii=False, default=str).encode(), "application/json; charset=utf-8", res.headers)

        do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = handle_one
    return H


class Server(ThreadingHTTPServer):
    daemon_threads = True; request_queue_size = 64; allow_reuse_address = True


def serve(app=None, block=True):
    app = app or App(); srv = Server((app.cfg.host, app.cfg.port), make_handler(app)); app.start_workers()
    log.info("RealHQ Studio API listening on http://%s:%s (data: %s)", *srv.server_address[:2], app.cfg.data_dir)
    if app.bootstrap_pw:
        print("\n" + "=" * 70 + "\n  FIRST RUN - one-time temporary password for 'hammam' (CEO & CTO):\n  " + app.bootstrap_pw +
              "\n  It is NOT stored anywhere and must be changed at first login.\n  Lost it? run: python -m server.admin reset-password hammam\n" + "=" * 70 + "\n", file=sys.stderr)
    if not block: return app, srv
    signal.signal(signal.SIGTERM, lambda *_: threading.Thread(target=srv.shutdown).start())
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
    finally: app.stop(); srv.server_close()


def main():
    logging.basicConfig(level=os.environ.get("REALHQ_LOG", "INFO"), format="%(asctime)s %(levelname)s %(name)s %(message)s"); serve()


if __name__ == "__main__": main()
