"""Background workers. Each loop survives exceptions (logged + exponential backoff) and publishes a heartbeat to worker_status."""
import logging, threading, time
from datetime import datetime, timezone
from .db import utcnow, iso_after, rows, one
from . import backup, retention

log = logging.getLogger("realhq.workers")


class Worker(threading.Thread):
    def __init__(self, app, name, interval, fn):
        super().__init__(name=name, daemon=True); self.app, self.interval, self.fn, self.stop_evt, self.fails = app, interval, fn, threading.Event(), 0

    def _beat(self, ok, err=None, nxt=0):
        with self.app.db.tx() as w:
            w.execute("INSERT INTO worker_status(name,last_run_at,last_ok_at,last_error,consecutive_failures,next_run_at) VALUES(?,?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET "
                      "last_run_at=excluded.last_run_at,last_ok_at=COALESCE(excluded.last_ok_at,last_ok_at),last_error=excluded.last_error,consecutive_failures=excluded.consecutive_failures,next_run_at=excluded.next_run_at",
                      (self.name, utcnow(), utcnow() if ok else None, err, self.fails, iso_after(nxt)))

    def run(self):
        while not self.stop_evt.is_set():
            try:
                self.fn(self.app); self.fails = 0; wait = self.interval; self._beat(True, None, wait)
            except Exception as e:  # never let the thread die silently
                self.fails += 1; wait = min(3600, self.interval * 2 ** min(self.fails, 6)); log.exception("worker %s failed", self.name)
                try: self._beat(False, str(e)[:300], wait)
                except Exception: pass
            self.stop_evt.wait(wait)


def backup_tick(app):
    p = backup.policy(app)
    if not p["enabled"]: return
    last = one(app.db.conn(), "SELECT finished_at FROM backup_runs WHERE kind='scheduled' AND status IN ('completed','rotated') ORDER BY id DESC LIMIT 1")
    due = True
    if last:
        age = (datetime.now(timezone.utc) - datetime.strptime(last["finished_at"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)).total_seconds()
        due = age >= backup.INTERVALS[p["schedule"]]
    if due: backup.run_backup(app, "scheduled", "system")


def retention_tick(app):
    """Dry-run ONLY. Produces a pending plan for the CEO/CTO; deletion always needs explicit human confirmation."""
    c = app.db.conn(); now = utcnow()
    with app.db.tx() as w: w.execute("UPDATE cleanup_runs SET status='expired' WHERE status='pending_confirmation' AND expires_at<=?", (now,))
    for co in rows(c, "SELECT id FROM companies WHERE is_active=1"):
        if one(c, "SELECT 1 FROM cleanup_runs WHERE company_id=? AND status='pending_confirmation'", (co["id"],)): continue
        last = one(c, "SELECT created_at FROM cleanup_runs WHERE company_id=? AND created_by='system' ORDER BY id DESC LIMIT 1", (co["id"],))
        if last and last["created_at"] > iso_after(-86400): continue
        if not c.execute("SELECT 1 FROM retention_rules WHERE company_id=? AND enabled=1", (co["id"],)).fetchone(): continue
        retention.dry_run(app, co["id"], None, "system", "system")


def session_gc(app):
    with app.db.tx() as w:
        w.execute("DELETE FROM sessions WHERE expires_at<? OR (revoked_at IS NOT NULL AND revoked_at<?)", (iso_after(-86400), iso_after(-7 * 86400)))


def recover(app):
    """Crash recovery on startup: runs left 'running'/'executing' by a dead process are marked failed, never silently resumed."""
    with app.db.tx() as w:
        w.execute("UPDATE backup_runs SET status='failed', error='interrupted by restart', finished_at=? WHERE status='running'", (utcnow(),))
        w.execute("UPDATE cleanup_runs SET status='failed', error='interrupted by restart' WHERE status='executing'")


def start_all(app):
    ws = [Worker(app, "backup", 60, backup_tick), Worker(app, "retention", 3600, retention_tick), Worker(app, "session_gc", 3600, session_gc)]
    for w in ws: w.start()
    return ws
