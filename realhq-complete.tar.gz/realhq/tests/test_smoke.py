"""End-to-end test against a real server instance. Run:  python -m tests.test_smoke"""
import http.client, json, os, shutil, sqlite3, tempfile, time

TMP = tempfile.mkdtemp(prefix="realhq-test-")
os.environ.update(REALHQ_DATA_DIR=TMP, REALHQ_ENV="development", REALHQ_PORT="0", REALHQ_PBKDF2_ITERS="100000",
                  REALHQ_BOOTSTRAP_PASSWORD="Boot-Strap#2026x", REALHQ_LOCKOUT_THRESHOLD="3", REALHQ_LOGIN_IP_LIMIT="200")
from server.server import serve  # noqa: E402
from server import audit  # noqa: E402

app, srv = serve(block=False)
import threading; threading.Thread(target=srv.serve_forever, daemon=True).start()
PORT = srv.server_address[1]
PASS, FAIL = [], []


def check(name, cond, extra=""):
    (PASS if cond else FAIL).append(name); print(("  ok   " if cond else "  FAIL ") + name + (f"  {extra}" if not cond else ""))


class Client:
    def __init__(self): self.cookie, self.csrf = None, None
    def req(self, method, path, body=None, raw=False, headers=None):
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=20); h = {"Host": f"127.0.0.1:{PORT}"}
        if self.cookie: h["Cookie"] = self.cookie
        if self.csrf and method != "GET": h["X-CSRF-Token"] = self.csrf
        data = None
        if body is not None: data = json.dumps(body); h["Content-Type"] = "application/json"
        h.update(headers or {}); c.request(method, path, data, h); r = c.getresponse(); b = r.read()
        sc = r.getheader("Set-Cookie")
        if sc and "Max-Age=0" not in sc: self.cookie = sc.split(";")[0]
        out = b if raw else (json.loads(b) if b else None)
        return r.status, out, r
    def login(self, ident, pw):
        s, b, _ = self.req("POST", "/api/auth/login", {"identifier": ident, "password": pw})
        if s == 200: self.csrf = b["csrf_token"]
        return s, b


def main():
    print("== health / security headers")
    s, b, r = Client().req("GET", "/api/health"); check("health ok", s == 200 and b["status"] == "ok")
    check("security headers", r.getheader("X-Frame-Options") == "DENY" and "nosniff" == r.getheader("X-Content-Type-Options"))
    check("unauthenticated blocked", Client().req("GET", "/api/tasks")[0] == 401)

    print("== login / lockout / password policy")
    ceo = Client()
    check("wrong password rejected", ceo.login("hammam", "wrong-Password1!")[0] == 401)
    s, b = ceo.login("hammam", "Boot-Strap#2026x"); check("CEO login ok", s == 200 and b["user"]["rbac_role"] == "ceo_cto")
    check("no secrets in login response", "password" not in json.dumps(b).lower().replace("must_change_password", ""))
    check("must-change blocks API", ceo.req("GET", "/api/tasks")[0] == 403)
    check("weak new password rejected", ceo.req("POST", "/api/auth/change-password", {"current_password": "Boot-Strap#2026x", "new_password": "short"})[0] == 422)
    s, b, _ = ceo.req("POST", "/api/auth/change-password", {"current_password": "Boot-Strap#2026x", "new_password": "Founder-Vault#9271"}); ceo.csrf = b["csrf_token"]
    check("password changed", s == 200 and ceo.req("GET", "/api/tasks")[0] == 200)
    check("CSRF enforced", Client().req("POST", "/api/auth/logout")[0] == 401 and
          (lambda c: (c.login("hammam", "Founder-Vault#9271"), setattr(c, "csrf", "bad"), c.req("POST", "/api/tasks", {"title": "x"})[0])[2])(Client()) == 403)
    victim = Client()
    for _ in range(3): victim.login("hammam", "nope-Nope-1234!")
    check("account locks after 3 failures (even correct pw)", Client().login("hammam", "Founder-Vault#9271")[0] == 401)
    with app.db.tx() as w: w.execute("UPDATE employees SET locked_until=NULL, failed_attempts=0 WHERE username='hammam'")
    ceo = Client(); ceo.login("hammam", "Founder-Vault#9271")
    check("password hash is PBKDF2", app.db.conn().execute("SELECT password_hash FROM employees WHERE username='hammam'").fetchone()[0].startswith("pbkdf2_sha256$"))

    print("== bilingual seed + HQ state")
    s, ref, _ = ceo.req("GET", "/api/reference")
    check("company bilingual", ref["company"]["name_en"] == "H-teach hub" and ref["company"]["name_ar"])
    s, emps, _ = ceo.req("GET", "/api/employees"); h = next(e for e in emps["items"] if e["username"] == "hammam")
    check("Hammam seeded AR+EN CEO&CTO", h["display_name_ar"] == "همام الحوامدة" and h["role_en"] == "Founder, CEO & CTO" and h["rbac_role"] == "ceo_cto")
    check("password hashes never returned", "password_hash" not in json.dumps(emps))
    s, hq, _ = ceo.req("GET", "/api/hq/state")
    st = {e["username"]: e["status"] for e in hq["employees"]}
    check("HQ live status (working/awaiting/idle)", st["demo.eng"] == "working" and st["demo.ops"] == "awaiting_approval" and st["demo.audit"] == "idle", str(st))
    check("executive desk present", any(e["is_executive"] and e["username"] == "hammam" for e in hq["employees"]))

    print("== employees + RBAC")
    mk = lambda u, role: ceo.req("POST", "/api/employees", {"username": u, "email": f"{u}@h-teach.example", "display_name_ar": "موظف", "display_name_en": u, "role_ar": "دور", "role_en": "Role", "rbac_role": role, "password": "Temp-Pass#4821x"})
    check("create member", mk("sara.m", "member")[0] == 201); check("create manager", mk("omar.k", "manager")[0] == 201)
    check("duplicate username rejected", mk("sara.m", "member")[0] == 409)
    check("weak pw on create rejected", ceo.req("POST", "/api/employees", {"username": "weak.u", "display_name_ar": "a", "display_name_en": "a", "role_ar": "a", "role_en": "a", "password": "abc"})[0] == 422)
    check("unknown field rejected (mass assignment)", ceo.req("POST", "/api/employees", {"username": "evil.u", "is_admin": True})[0] == 422)
    member = Client(); member.login("sara.m", "Temp-Pass#4821x")
    check("new employee must change password", member.req("GET", "/api/tasks")[0] == 403)
    s, b, _ = member.req("POST", "/api/auth/change-password", {"current_password": "Temp-Pass#4821x", "new_password": "Member-Key#5530z"}); member.csrf = b["csrf_token"]
    mgr = Client(); mgr.login("omar.k@h-teach.example", "Temp-Pass#4821x"); s, b, _ = mgr.req("POST", "/api/auth/change-password", {"current_password": "Temp-Pass#4821x", "new_password": "Manager-Key#7714q"}); mgr.csrf = b["csrf_token"]
    check("email login works", s == 200)
    check("member cannot create employees", member.req("POST", "/api/employees", {"username": "zzz.z"})[0] == 403)
    check("member cannot read audit", member.req("GET", "/api/audit")[0] == 403)
    check("member cannot export employees", member.req("GET", "/api/export/employees.csv", raw=True)[0] == 403)
    check("manager cannot decide approvals", mgr.req("POST", "/api/approvals/1/decide", {"decision": "approved"})[0] == 403)
    check("cannot demote last CEO", ceo.req("PATCH", f"/api/employees/{h['id']}", {"rbac_role": "member"})[0] in (403, 409))
    check("cannot deactivate self", ceo.req("POST", f"/api/employees/{h['id']}/deactivate")[0] == 409)

    print("== classification clearance + tenant isolation")
    s, secret, _ = ceo.req("POST", "/api/tasks", {"title": "Board strategy", "classification": "restricted"}); check("CEO creates restricted task", s == 201)
    s, lst, _ = member.req("GET", "/api/tasks"); check("member cannot see restricted", all(t["classification"] == "internal" for t in lst["items"]))
    check("restricted task is 404 to member", member.req("GET", f"/api/tasks/{secret['id']}")[0] == 404)
    check("member cannot create above clearance", member.req("POST", "/api/tasks", {"title": "x", "classification": "restricted"})[0] == 403)
    now = "2026-01-01T00:00:00Z"
    with app.db.tx() as w:
        w.execute("INSERT INTO companies(id,slug,name_ar,name_en,created_at) VALUES(99,'other-co','أخرى','Other Co',?)", (now,))
        w.execute("INSERT INTO tasks(company_id,title,created_at,updated_at) VALUES(99,'OTHER TENANT SECRET',?,?)", (now, now))
        oid = w.execute("SELECT id FROM tasks WHERE company_id=99").fetchone()[0]
    s, lst, _ = ceo.req("GET", "/api/tasks?limit=200"); check("tenant isolation: list", all(t["title"] != "OTHER TENANT SECRET" for t in lst["items"]))
    check("tenant isolation: direct id", ceo.req("GET", f"/api/tasks/{oid}")[0] == 404 and ceo.req("PATCH", f"/api/tasks/{oid}", {"title": "pwn"})[0] == 404 and ceo.req("DELETE", f"/api/tasks/{oid}")[0] == 404)
    check("cross-tenant ref rejected", ceo.req("POST", "/api/tasks", {"title": "x", "assignee_id": 9999})[0] == 422)

    print("== tasks, approvals, external-action gate")
    s, t, _ = mgr.req("POST", "/api/tasks", {"title": "Email pricing to client", "external_action": True}); tid = t["id"]
    check("illegal transition blocked", mgr.req("POST", f"/api/tasks/{tid}/transition", {"to": "approved"})[0] == 409)
    mgr.req("POST", f"/api/tasks/{tid}/transition", {"to": "in_progress"})
    check("external action cannot be marked done unapproved", mgr.req("POST", f"/api/tasks/{tid}/transition", {"to": "done"})[0] == 409)
    s, a, _ = mgr.req("POST", "/api/approvals", {"kind": "pricing", "title": "Send price", "task_id": tid}); check("approval requested", s == 201)
    check("task now awaiting_approval", ceo.req("GET", f"/api/tasks/{tid}")[1]["status"] == "awaiting_approval")
    check("reject requires note", ceo.req("POST", f"/api/approvals/{a['id']}/decide", {"decision": "rejected"})[0] == 422)
    check("CEO approves", ceo.req("POST", f"/api/approvals/{a['id']}/decide", {"decision": "approved"})[0] == 200)
    check("double-decide blocked", ceo.req("POST", f"/api/approvals/{a['id']}/decide", {"decision": "approved"})[0] == 409)
    check("approved external task can complete", mgr.req("POST", f"/api/tasks/{tid}/transition", {"to": "done"})[0] == 200)
    check("time entry", member.req("POST", "/api/time-entries", {"task_id": tid, "minutes": 30, "work_date": "2026-11-20"})[0] in (201, 404))
    s, th, _ = ceo.req("POST", "/api/chat/threads", {"scope_type": "task", "scope_id": tid, "title": "Pricing", "participant_ids": []})
    check("scoped chat thread", s == 201 and member.req("GET", f"/api/chat/threads/{th['id']}/messages")[0] == 404)
    check("chat send+read", ceo.req("POST", f"/api/chat/threads/{th['id']}/messages", {"body": "<script>alert(1)</script>"})[0] == 201)

    print("== CSV / PDF exports")
    with app.db.tx() as w:
        w.execute("INSERT INTO clients(company_id,name,created_at,updated_at) VALUES(1,'=HYPERLINK(\"http://evil\")',?,?)", (now, now))
    s, csvb, r = ceo.req("GET", "/api/export/clients.csv?lang=bi", raw=True)
    check("CSV has UTF-8 BOM", csvb.startswith(b"\xef\xbb\xbf")); txt = csvb.decode("utf-8-sig")
    check("CSV bilingual header", "Name / الاسم" in txt); check("CSV formula neutralized", "'=HYPERLINK" in txt and ",=HYPERLINK" not in txt)
    check("CSV attachment header", "attachment" in r.getheader("Content-Disposition"))
    for lang in ("en", "ar", "bi"):
        s, pdf, _ = ceo.req("GET", f"/api/export/tasks.pdf?lang={lang}", raw=True); check(f"PDF tasks lang={lang}", s == 200 and pdf[:4] == b"%PDF")
    open(f"{TMP}/tasks_ar.pdf", "wb").write(ceo.req("GET", "/api/export/employees.pdf?lang=ar", raw=True)[1])
    open(f"{TMP}/summary.pdf", "wb").write(ceo.req("GET", "/api/export/executive-summary.pdf?lang=bi", raw=True)[1])
    check("exec summary csv", ceo.req("GET", "/api/export/executive-summary.csv", raw=True)[0] == 200)
    s, aud, _ = ceo.req("GET", "/api/export/audit_log.csv", raw=True); check("audit log export (CEO)", s == 200)
    check("export history recorded", len(ceo.req("GET", "/api/exports")[1]["items"]) >= 5)
    check("member limited export forbidden", member.req("GET", "/api/export/tasks.csv", raw=True)[0] == 403)
    check("bad filter rejected", ceo.req("GET", "/api/export/tasks.csv?since=nope", raw=True)[0] == 400)

    print("== backups")
    s, bk, _ = ceo.req("POST", "/api/backups"); check("manual backup", s == 201 and bk["status"] == "completed" and os.path.exists(bk["path"]))
    check("backup file mode 600", oct(os.stat(bk["path"]).st_mode)[-3:] == "600")
    s, vr, _ = ceo.req("POST", f"/api/backups/{bk['id']}/verify"); check("restore verification", vr["ok"], str(vr))
    check("manager cannot touch backups", mgr.req("GET", "/api/backups/status")[0] == 403 and mgr.req("POST", "/api/backups")[0] == 403)
    check("policy update", ceo.req("PUT", "/api/backups/policy", {"enabled": True, "schedule": "hourly", "keep_count": 3})[0] == 200)
    from server import workers; workers.backup_tick(app)
    check("scheduler produced scheduled backup", app.db.conn().execute("SELECT count(*) FROM backup_runs WHERE kind='scheduled' AND status='completed'").fetchone()[0] == 1)

    print("== retention / cleanup (365 days)")
    old, recent = "2024-01-01T00:00:00Z", "2026-11-01T00:00:00Z"
    with app.db.tx() as w:
        w.execute("INSERT INTO projects(id,company_id,name,status,created_at,updated_at) VALUES(500,1,'Active proj','active',?,?)", (old, old))
        w.execute("INSERT INTO projects(id,company_id,name,status,created_at,updated_at,closed_at) VALUES(501,1,'Old done proj','completed',?,?,?)", (old, old, old))
        ins = lambda pid, st, cl, upd: w.execute("INSERT INTO tasks(company_id,project_id,title,status,created_at,updated_at,closed_at) VALUES(1,?,?,?,?,?,?)", (pid, f"t-{st}-{pid}", st, old, upd, cl))
        ins(501, "done", old, old)            # purge
        ins(None, "cancelled", old, old)      # purge
        ins(500, "done", old, old)            # PROTECTED (active project)
        ins(None, "done", recent, recent)     # PROTECTED (recent)
        ins(None, "draft", None, old)         # stale draft -> purge
        w.execute("INSERT INTO leads(company_id,name,status,created_at,updated_at,closed_at) VALUES(1,'lost old','closed_lost',?,?,?)", (old, old, old))
        w.execute("INSERT INTO knowledge_items(company_id,title,pinned,created_at,updated_at) VALUES(1,'pinned old',1,?,?)", (old, old))
        w.execute("INSERT INTO research_reports(company_id,title,status,created_at,updated_at) VALUES(1,'old report','completed',?,?)", (old, old))
    check("rule floor enforced (<365 rejected)", ceo.req("PUT", "/api/retention/rules", {"entity_type": "tasks_closed", "retain_days": 30, "enabled": True})[0] == 422)
    s, run, _ = ceo.req("POST", "/api/retention/dry-run"); check("dry-run pending", run["status"] == "pending_confirmation", str(run))
    check("dry-run deletes nothing", app.db.conn().execute("SELECT count(*) FROM tasks WHERE title LIKE 't-%'").fetchone()[0] == 5)
    check("manager cannot run cleanup", mgr.req("POST", "/api/retention/dry-run")[0] == 403)
    check("wrong phrase refused", ceo.req("POST", f"/api/retention/runs/{run['id']}/execute", {"confirm_phrase": "yes"})[0] == 409)
    s, done, _ = ceo.req("POST", f"/api/retention/runs/{run['id']}/execute", {"confirm_phrase": run["confirmation_phrase"]})
    check("cleanup executed with counts", s == 200 and done["deleted"]["tasks_closed"] == 2 and done["deleted"]["tasks_stale_drafts"] == 1 and done["deleted"]["leads_closed_lost"] == 1 and done["deleted"]["research_reports"] == 1, str(done))
    left = [r[0] for r in app.db.conn().execute("SELECT title FROM tasks WHERE title LIKE 't-%'")]
    check("active-project + recent tasks protected", sorted(left) == ["t-done-500", "t-done-None"] or len(left) == 2, str(left))
    check("pinned knowledge protected", app.db.conn().execute("SELECT count(*) FROM knowledge_items WHERE title='pinned old'").fetchone()[0] == 1)
    check("pre-cleanup backup + archive exist", app.db.conn().execute("SELECT count(*) FROM backup_runs WHERE kind='pre_cleanup' AND status='completed'").fetchone()[0] == 1 and any(os.scandir(f"{TMP}/archives/1")))
    check("cannot execute twice", ceo.req("POST", f"/api/retention/runs/{run['id']}/execute", {"confirm_phrase": run["confirmation_phrase"]})[0] == 409)

    print("== audit log integrity")
    s, v, _ = ceo.req("GET", "/api/audit/verify"); check("hash chain verifies", v["ok"] and v["entries"] > 20, str(v))
    acts = {a["action"] for a in ceo.req("GET", "/api/audit?limit=200")[1]["items"]}
    check("audit covers key events", {"auth.login", "auth.login_failed", "auth.account_locked", "employee.create", "approval.decide", "export.download", "backup.create", "retention.execute", "retention.dry_run"} <= acts, str({"auth.login", "auth.login_failed", "auth.account_locked", "employee.create", "approval.decide", "export.download", "backup.create", "retention.execute"} - acts))
    check("no password/hash in audit", "pbkdf2" not in json.dumps(ceo.req("GET", "/api/audit?limit=200")[1]) and "Temp-Pass" not in json.dumps(ceo.req("GET", "/api/audit?limit=200")[1]))
    try: app.db.conn().execute("UPDATE audit_log SET action='x' WHERE id=1"); ok = False
    except sqlite3.DatabaseError: ok = True
    check("audit_log append-only (UPDATE blocked)", ok)
    try: app.db.conn().execute("DELETE FROM audit_log"); ok = False
    except sqlite3.DatabaseError: ok = True
    check("audit_log append-only (DELETE blocked)", ok)
    t2 = f"{TMP}/tamper.db"; d = sqlite3.connect(t2); app.db.conn().backup(d); d.close(); c = sqlite3.connect(t2)
    c.execute("DROP TRIGGER audit_no_update"); c.execute("UPDATE audit_log SET actor_username='mallory' WHERE seq=3 AND company_id=1"); c.commit(); c.row_factory = sqlite3.Row
    check("tampering is detected by verify_chain", not audit.verify_chain(c, app.audit_key, 1)["ok"])

    print("== hardening")
    def raw_status(headers, body=b""):
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10); c.putrequest("POST", "/api/auth/login", skip_host=False)
        for k, v in headers.items(): c.putheader(k, v)
        c.endheaders(body); return c.getresponse().status
    check("oversized body rejected (413)", raw_status({"Content-Type": "application/json", "Content-Length": "2000000"}) == 413)
    check("non-JSON content type rejected (415)", raw_status({"Content-Type": "text/plain", "Content-Length": "3"}, b"a=b") == 415)
    check("chunked bodies refused", raw_status({"Content-Type": "application/json", "Transfer-Encoding": "chunked"}, b"0\r\n\r\n") == 400)
    s_, ui, r_ = Client().req("GET", "/", raw=True)
    check("UI served with strict CSP (no unsafe-inline scripts)", s_ == 200 and b"RealHQ" in ui and "script-src 'self'" in r_.getheader("Content-Security-Policy") and "unsafe-inline" not in r_.getheader("Content-Security-Policy"))
    check("UI assets served", Client().req("GET", "/app.js", raw=True)[0] == 200 and Client().req("GET", "/app.css", raw=True)[0] == 200)
    check("no path traversal via static", Client().req("GET", "/..%2f..%2fetc%2fpasswd", raw=True)[0] == 404 and Client().req("GET", "/server/config.py", raw=True)[0] == 404)
    check("logout revokes session", (lambda c: (c.login("hammam", "Founder-Vault#9271"), c.req("POST", "/api/auth/logout"), c.req("GET", "/api/auth/me")[0])[2])(Client()) == 401)
    check("deactivated employee loses access", (ceo.req("POST", f"/api/employees/{[e for e in ceo.req('GET','/api/employees')[1]['items'] if e['username']=='sara.m'][0]['id']}/deactivate")[0] == 200) and member.req("GET", "/api/auth/me")[0] == 401)
    check("SQLi-ish search is inert", ceo.req("GET", "/api/tasks?q=%27%3B+DROP+TABLE+tasks%3B--")[0] == 200)

    print(f"\n{len(PASS)} passed, {len(FAIL)} failed"); 
    if FAIL: print("FAILED:", FAIL)
    return not FAIL


if __name__ == "__main__":
    ok = False
    try: ok = main()
    finally: app.stop(); srv.shutdown(); print("artifacts in", TMP)
    raise SystemExit(0 if ok else 1)
