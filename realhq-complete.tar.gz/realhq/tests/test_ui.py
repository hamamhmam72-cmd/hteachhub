"""Real-browser UI test (needs: pip install playwright && playwright install chromium). Run: python tests/test_ui.py"""
import os, subprocess, sys, time, tempfile, urllib.request
from playwright.sync_api import sync_playwright
pw='Test-Boot#2026xQ!'; new="Founder-Studio#2026!k"
d=tempfile.mkdtemp(); env=dict(os.environ,REALHQ_DATA_DIR=d,REALHQ_ENV="development",REALHQ_PORT="8099",REALHQ_BOOTSTRAP_PASSWORD=pw)
srv=subprocess.Popen([sys.executable,"-m","server.server"],cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),env=env,stderr=subprocess.DEVNULL)
for _ in range(50):
    try: urllib.request.urlopen("http://127.0.0.1:8099/api/health"); break
    except Exception: time.sleep(.2)
errs=[]
try:
  with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":1280,"height":820})
    pg.on("pageerror",lambda e:errs.append(str(e))); pg.on("console",lambda m: m.type=="error" and "fonts" not in m.text and "ERR_" not in m.text and errs.append(m.text))
    pg.goto("http://127.0.0.1:8099/"); pg.wait_for_selector("form")
    assert pg.evaluate("document.documentElement.dir")=="rtl"; pg.screenshot(path="/tmp/realhq_ui_login.png")
    pg.fill("[name=ident]","hammam"); pg.fill("[name=pw]","wrong-pass-123!"); pg.click("button.gold"); pg.wait_for_selector(".toast.bad"); print("bad login shows error: ok")
    pg.fill("[name=pw]",pw); pg.click("button.gold"); pg.wait_for_selector("[name=n2]"); print("forced password change: ok")
    pg.fill("[name=c]",pw); pg.fill("[name=n]",new); pg.fill("[name=n2]",new); pg.click("button.gold"); pg.wait_for_selector(".floor .desk"); print("HQ rendered: ok")
    pg.wait_for_timeout(500); pg.screenshot(path="/tmp/realhq_ui_hq_ar.png")
    print("desks:",pg.locator(".desk").count(),"exec desk:",pg.locator(".desk.executive").count(), "awaiting:",pg.locator(".desk.awaiting_approval").count())
    pg.locator(".desk.working").first.click(); pg.wait_for_selector(".panel .card"); pg.fill(".panel input[placeholder]:not([maxlength='4000'])","مهمة جديدة من الواجهة"); pg.click(".panel button.em"); pg.wait_for_selector(".toast"); print("assign task from HQ: ok")
    pg.locator(".panel input[maxlength='4000']").fill("<b>مرحبا</b> hello"); pg.click(".panel form.row button"); pg.wait_for_selector(".chat p"); assert pg.locator(".chat b").count()==1; print("chat + XSS-safe (tags shown as text): ok")
    pg.keyboard.press("l"); pg.wait_for_timeout(300); assert pg.evaluate("document.documentElement.dir")=="ltr"; pg.wait_for_selector(".floor .desk"); pg.screenshot(path="/tmp/realhq_ui_hq_en.png"); print("LTR switch (L key): ok")
    pg.keyboard.press("2"); pg.wait_for_selector(".card .row"); pg.click("button.em"); pg.wait_for_timeout(600); print("approvals tab + approve: ok")
    pg.keyboard.press("3"); pg.wait_for_selector("table"); pg.keyboard.press("4"); pg.wait_for_selector("a[href*=export]"); pg.click("text=Verify integrity"); pg.wait_for_selector("text=Audit chain intact"); pg.screenshot(path="/tmp/realhq_ui_ops.png"); print("team + ops + audit verify: ok")
    pg.set_viewport_size({"width":390,"height":800}); pg.keyboard.press("1"); pg.wait_for_selector(".floor .desk"); assert pg.evaluate("document.documentElement.scrollWidth<=document.documentElement.clientWidth+2"); print("mobile no horizontal overflow: ok")
    b.close()
finally: srv.terminate()
print("JS errors:",errs or "none")
