'use strict';
/* RealHQ Studio UI — all text is inserted via textContent (never innerHTML), so stored data cannot inject markup. */
const T = {
  portal: ['Employee Login Portal', 'بوابة دخول الموظفين'], signin: ['Sign in', 'تسجيل الدخول'], company: ['Company code', 'رمز الشركة'],
  ident: ['Username or company email', 'اسم المستخدم أو البريد الرسمي'], password: ['Password', 'كلمة المرور'], logout: ['Sign out', 'خروج'],
  hq: ['Headquarters', 'المقر'], approvals: ['Approvals', 'الموافقات'], team: ['Team', 'الفريق'], ops: ['Operations', 'العمليات'],
  working: ['Working', 'يعمل'], awaiting_approval: ['Awaiting CEO/CTO', 'بانتظار الرئيس التنفيذي'], idle: ['Idle', 'متفرغ'],
  exec: ['Executive office', 'المكتب التنفيذي'], tasks: ['Open tasks', 'المهام المفتوحة'], none: ['Nothing here yet.', 'لا يوجد شيء بعد.'],
  assign: ['Assign task', 'إسناد مهمة'], title: ['Task title', 'عنوان المهمة'], chat: ['Scoped chat', 'محادثة مباشرة'], send: ['Send', 'إرسال'],
  approve: ['Approve', 'اعتماد'], reject: ['Reject', 'رفض'], note: ['Reason for rejection', 'سبب الرفض'], pending: ['Pending', 'معلّق'],
  low: ['Low', 'منخفضة'], normal: ['Normal', 'عادية'], high: ['High', 'عالية'], urgent: ['Urgent', 'عاجلة'],
  todo: ['To do', 'للتنفيذ'], in_progress: ['In progress', 'قيد التنفيذ'], approved: ['Approved', 'معتمد'], rejected: ['Rejected', 'مرفوض'],
  done: ['Done', 'منجز'], draft: ['Draft', 'مسودة'], cancelled: ['Cancelled', 'ملغى'], create: ['Create employee', 'إنشاء موظف'],
  username: ['Username', 'اسم المستخدم'], name_ar: ['Name (Arabic)', 'الاسم بالعربية'], name_en: ['Name (English)', 'الاسم بالإنجليزية'],
  role_ar: ['Title (Arabic)', 'المسمى بالعربية'], role_en: ['Title (English)', 'المسمى بالإنجليزية'], rbac: ['Access role', 'دور الوصول'],
  temp: ['Temporary password', 'كلمة مرور مؤقتة'], deact: ['Deactivate', 'تعطيل'], act: ['Activate', 'تفعيل'], reset: ['Reset password', 'إعادة تعيين كلمة المرور'],
  exports: ['Exports (CSV / PDF)', 'التصدير (CSV / PDF)'], audit: ['Audit log', 'سجل التدقيق'], verify: ['Verify integrity', 'التحقق من السلامة'],
  chain_ok: ['Audit chain intact', 'سلسلة التدقيق سليمة'], chain_bad: ['AUDIT CHAIN BROKEN', 'سلسلة التدقيق معطوبة'], backups: ['Backups', 'النسخ الاحتياطي'],
  backup_now: ['Back up now', 'نسخ احتياطي الآن'], last_ok: ['Last successful', 'آخر نسخة ناجحة'], retention: ['Data retention (365 days)', 'الاحتفاظ بالبيانات (365 يومًا)'],
  dry: ['Run dry-run', 'تشغيل فحص تجريبي'], phrase: ['Type the confirmation phrase', 'اكتب عبارة التأكيد'], exec_btn: ['Permanently delete', 'حذف نهائي'],
  chpw: ['Set a new password', 'تعيين كلمة مرور جديدة'], must: ['For security, you must change your temporary password.', 'لأمانك، يجب تغيير كلمة المرور المؤقتة.'],
  cur: ['Current password', 'كلمة المرور الحالية'], new: ['New password (12+ chars, mixed)', 'كلمة المرور الجديدة (12+ حرفًا، متنوعة)'], same: ['Passwords do not match', 'كلمتا المرور غير متطابقتين'],
  pick: ['Select a team member to inspect tasks, chat, or assign work.', 'اختر أحد أعضاء الفريق لعرض مهامه أو محادثته أو إسناد مهمة له.'], saved: ['Done', 'تم'], other: ['العربية', 'English'], online: ['online', 'متصل'], pending_n: ['Pending approvals', 'موافقات معلّقة'], dryrun_ok: ['Plan ready — nothing deleted yet', 'الخطة جاهزة — لم يُحذف شيء بعد'],
  nothing: ['Nothing to clean up', 'لا شيء للتنظيف'], skills: ['Skills', 'المهارات'], msg: ['Message', 'رسالة'], kb: ['Shortcuts: 1–4 tabs · L language · Esc close', 'اختصارات: 1–4 تبويبات · L اللغة · Esc إغلاق'],
  min_length_12: ['at least 12 characters', '12 حرفًا على الأقل'], needs_lowercase: ['a lowercase letter', 'حرف صغير'], needs_uppercase: ['an uppercase letter', 'حرف كبير'],
  needs_digit: ['a digit', 'رقم'], needs_symbol: ['a symbol', 'رمز'], contains_username: ['must not contain username', 'يجب ألا تحتوي اسم المستخدم'],
};
let lang; try { lang = localStorage.getItem('lang') || 'ar'; } catch { lang = 'ar'; }
const t = k => (T[k] || [k, k])[lang === 'ar' ? 1 : 0];
const nm = o => o['display_name_' + lang] || o.display_name_en, rl = o => o['role_' + lang] || o.role_en;
const $ = s => document.querySelector(s), root = $('#app');
const S = { me: null, csrf: null, tab: 'hq', sel: null, timers: [] };
const can = p => S.me && S.me.permissions.includes(p);

function h(tag, a = {}, ...c) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(a)) { if (k === 'class') e.className = v; else if (k === 'style') e.style.cssText = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (v !== false && v != null) e.setAttribute(k, v); }
  for (const x of c.flat(9)) if (x != null && x !== false) e.append(x.nodeType ? x : document.createTextNode(String(x)));
  return e;
}
async function api(m, p, b) {
  const r = await fetch('/api' + p, { method: m, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrf || '' }, body: b ? JSON.stringify(b) : undefined });
  const d = (r.headers.get('content-type') || '').includes('json') ? await r.json() : null;
  if (!r.ok) { const er = d && d.error || {}; throw Object.assign(new Error(er['message_' + lang] || r.status), { code: er.code, status: r.status, details: er.details }); }
  return d;
}
function toast(m, bad) { const e = h('div', { class: 'toast' + (bad ? ' bad' : '') }, m); $('#toasts').append(e); setTimeout(() => e.remove(), 5000); }
function emsg(e) { const d = e.details; let x = e.message; if (Array.isArray(d)) x += ': ' + d.map(t).join(', '); else if (d && typeof d === 'object') x += ' — ' + Object.entries(d).map(([k, v]) => k + ': ' + v).join('; '); return x; }
async function run(btn, fn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { if (e.status === 401 && S.me) { S.me = null; render(); } else toast(emsg(e), true); } finally { if (btn) btn.disabled = false; }
}
function setLang(l) { lang = l; try { localStorage.setItem('lang', l); } catch {} document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr'; render(); }
const field = (label, input) => h('div', {}, h('label', {}, label), input);
const pill = s => h('span', { class: 'pill ' + s }, t(s));

/* ---------- auth screens ---------- */
function loginView(err) {
  const f = h('form', { onsubmit: ev => { ev.preventDefault(); run(f.querySelector('button'), async () => {
    const d = await api('POST', '/auth/login', { company: f.company.value.trim() || undefined, identifier: f.ident.value, password: f.pw.value });
    S.me = d.user; S.csrf = d.csrf_token; render(); }).catch(() => {}); } },
    h('div', { class: 'brand' }, h('b', {}, lang === 'ar' ? 'إتش-تيتش هب' : 'H-teach hub'), h('span', {}, 'RealHQ Studio · ' + t('portal'))),
    err && h('div', { class: 'err', role: 'alert' }, err),
    field(t('company'), h('input', { name: 'company', value: 'h-teach-hub', autocomplete: 'organization', dir: 'ltr' })),
    field(t('ident'), h('input', { name: 'ident', required: true, autofocus: true, autocomplete: 'username', dir: 'ltr' })),
    field(t('password'), h('input', { name: 'pw', type: 'password', required: true, autocomplete: 'current-password', dir: 'ltr' })),
    h('p', {}, h('button', { class: 'btn gold', style: 'width:100%' }, t('signin'))),
    h('button', { type: 'button', class: 'btn', onclick: () => setLang(lang === 'ar' ? 'en' : 'ar') }, t('other')));
  root.replaceChildren(h('div', { class: 'login' }, f));
}
function changeView() {
  const f = h('form', { onsubmit: ev => { ev.preventDefault();
    if (f.n.value !== f.n2.value) return toast(t('same'), true);
    run(f.querySelector('button'), async () => { const d = await api('POST', '/auth/change-password', { current_password: f.c.value, new_password: f.n.value });
      S.csrf = d.csrf_token; const m = await api('GET', '/auth/me'); S.me = m.user; render(); }); } },
    h('div', { class: 'brand' }, h('b', {}, t('chpw')), h('span', {}, t('must'))),
    field(t('cur'), h('input', { name: 'c', type: 'password', required: true, autocomplete: 'current-password', dir: 'ltr' })),
    field(t('new'), h('input', { name: 'n', type: 'password', required: true, minlength: 12, autocomplete: 'new-password', dir: 'ltr' })),
    field(t('new'), h('input', { name: 'n2', type: 'password', required: true, autocomplete: 'new-password', dir: 'ltr' })),
    h('p', {}, h('button', { class: 'btn gold' }, t('chpw'))), h('button', { type: 'button', class: 'btn', onclick: () => run(null, async () => { await api('POST', '/auth/logout'); S.me = null; render(); }) }, t('logout')));
  root.replaceChildren(h('div', { class: 'login' }, f));
}

/* ---------- shell ---------- */
const TABS = () => [['hq', true], ['approvals', can('approvals:read')], ['team', can('employees:read')], ['ops', S.me.rbac_role === 'ceo_cto' || S.me.rbac_role === 'auditor']].filter(x => x[1]).map(x => x[0]);
function render() {
  S.timers.forEach(clearInterval); S.timers = [];
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; document.documentElement.lang = lang;
  if (!S.me) return loginView();
  if (S.me.must_change_password) return changeView();
  const tabs = TABS(); if (!tabs.includes(S.tab)) S.tab = 'hq';
  const main = h('main', {}, h('div', { class: 'load' }, '…'));
  root.replaceChildren(h('header', { class: 'top' },
    h('div', { class: 'brand' }, h('b', {}, lang === 'ar' ? 'إتش-تيتش هب' : 'H-teach hub'), h('span', {}, 'RealHQ Studio')),
    h('nav', { 'aria-label': 'main' }, tabs.map(k => h('button', { 'aria-current': k === S.tab ? 'page' : null, onclick: () => { S.tab = k; S.sel = null; render(); } }, t(k)))),
    h('span', { class: 'mu' }, nm(S.me) + ' · ' + S.me.rbac_role),
    h('button', { class: 'btn', onclick: () => setLang(lang === 'ar' ? 'en' : 'ar') }, t('other')),
    h('button', { class: 'btn', onclick: () => run(null, async () => { await api('POST', '/auth/logout'); S.me = null; render(); }) }, t('logout'))), main,
    h('p', { class: 'mu', style: 'text-align:center;font-size:12px' }, t('kb')));
  ({ hq: viewHQ, approvals: viewApprovals, team: viewTeam, ops: viewOps })[S.tab](main).catch(e => main.replaceChildren(h('div', { class: 'err' }, emsg(e))));
}

/* ---------- HQ: live floor plan ---------- */
async function viewHQ(main) {
  const [ref, st0] = await Promise.all([api('GET', '/reference'), api('GET', '/hq/state')]); let st = st0;
  const stats = h('div', { class: 'stats' }), floor = h('div', { class: 'floor' }), panel = h('div', { class: 'panel' });
  const emps = {};
  function draw() {
    st.employees.forEach(e => emps[e.id] = e);
    stats.replaceChildren(...['working', 'awaiting_approval', 'idle'].map(k => h('span', {}, h('i', { class: 'lg', style: 'background:' + ({ working: 'var(--em)', awaiting_approval: 'var(--gold)', idle: 'var(--mu)' })[k] }), h('b', {}, st.counts[k]), t(k))), h('span', {}, h('b', {}, st.pending_approvals), t('pending_n')));
    const byRoom = {}; st.employees.forEach(e => (byRoom[e.room_id || 0] = byRoom[e.room_id || 0] || []).push(e));
    const rooms = st.rooms.map(r => h('section', { class: 'room ' + r.kind, style: `grid-column:${r.grid_x + 1}/span ${r.grid_w};grid-row:${r.grid_y + 1}/span ${r.grid_h}` },
      h('h3', {}, r['name_' + lang]), h('div', { class: 'desks' }, (byRoom[r.id] || []).map(desk))));
    if (byRoom[0]) rooms.push(h('section', { class: 'room', style: 'grid-column:1/-1' }, h('div', { class: 'desks' }, byRoom[0].map(desk))));
    floor.replaceChildren(...rooms);
  }
  const desk = e => h('button', { class: `desk ${e.status} ${e.is_executive ? 'executive' : ''}`, onclick: () => inspect(e.id), 'aria-label': nm(e) },
    h('span', { class: 'dot' + (e.online ? ' on' : ''), title: e.online ? t('online') : '' }),
    h('span', {}, (e.is_executive ? '★ ' : '') + nm(e), h('small', {}, rl(e)), h('small', {}, t(e.status) + (e.active_tasks[0] ? ' · ' + (e.active_tasks[0].title.split(' / ')[lang === 'ar' ? 1 : 0] || e.active_tasks[0].title) : ''))));
  async function inspect(id) {
    S.sel = id; const d = await api('GET', '/hq/employees/' + id), e = d.employee, base = emps[id] || {};
    let th = null, pollT; const log = h('div', { class: 'chat' }); const mi = h('input', { placeholder: t('msg'), maxlength: 4000 });
    async function loadChat() {
      if (!th) { th = (await api('GET', '/chat/threads')).items.find(x => x.scope_type === 'employee' && x.scope_id === id) || null; if (!th) return; }
      const m = await api('GET', `/chat/threads/${th.id}/messages`);
      log.replaceChildren(...m.items.map(x => h('p', {}, h('b', {}, x['display_name_' + lang] + ': '), x.body))); log.scrollTop = log.scrollHeight;
    }
    const sendF = h('form', { class: 'row', onsubmit: ev => { ev.preventDefault(); if (!mi.value.trim()) return; run(null, async () => {
      if (!th) th = await api('POST', '/chat/threads', { scope_type: 'employee', scope_id: id, title: nm(e) });
      await api('POST', `/chat/threads/${th.id}/messages`, { body: mi.value }); mi.value = ''; await loadChat(); }); } }, h('div', { class: 'g' }, mi), h('button', { class: 'btn' }, t('send')));
    const ti = h('input', { placeholder: t('title'), maxlength: 200 }), pr = h('select', {}, ['normal', 'low', 'high', 'urgent'].map(p => h('option', { value: p }, t(p))));
    const af = can('tasks:write') && h('form', { class: 'grid2', onsubmit: ev => { ev.preventDefault(); run(ev.target.querySelector('button'), async () => {
      await api('POST', '/tasks', { title: ti.value, priority: pr.value, assignee_id: id }); toast(t('saved')); st = await api('GET', '/hq/state'); draw(); inspect(id); }); } },
      h('div', { style: 'grid-column:1/-1' }, ti), pr, h('button', { class: 'btn em' }, t('assign')));
    panel.replaceChildren(h('div', { class: 'card' }, h('h2', {}, (e.rbac_role === 'ceo_cto' ? '★ ' : '') + nm(e)), h('div', { class: 'mu' }, rl(e)), base.status && h('p', {}, pill(base.status)),
      e['bio_' + lang] && h('p', {}, e['bio_' + lang]), (e.skills || []).length > 0 && h('p', { class: 'mu' }, t('skills') + ': ' + e.skills.map(s => s['name_' + lang]).join('، ')),
      h('h2', {}, t('tasks')), d.open_tasks.length ? d.open_tasks.map(x => h('div', { class: 'row' }, h('span', { class: 'g' }, x.title), pill(x.status))) : h('div', { class: 'empty' }, t('none')),
      d.pending_approvals.map(a => h('div', { class: 'row' }, h('span', { class: 'g' }, a.title), pill('pending'))),
      af && h('h2', { style: 'margin-top:1rem' }, t('assign')), af, h('h2', { style: 'margin-top:1rem' }, t('chat')), log, sendF));
    loadChat().catch(() => {}); S.timers.push(pollT = setInterval(() => S.sel === id && loadChat().catch(() => {}), 5000));
  }
  panel.replaceChildren(h('div', { class: 'card empty' }, t('pick'))); main.replaceChildren(stats, h('div', { class: 'cols' }, floor, panel)); draw();
  S.timers.push(setInterval(async () => { try { st = await api('GET', '/hq/state'); draw(); } catch (e) { if (e.status === 401) { S.me = null; render(); } } }, 15000));
}

/* ---------- approvals ---------- */
async function viewApprovals(main) {
  const d = await api('GET', '/approvals?limit=100'); const ceo = can('approvals:decide');
  main.replaceChildren(h('div', { class: 'card' }, h('h2', {}, t('approvals')), d.items.length ? d.items.map(a => h('div', { class: 'row' },
    h('span', { class: 'g' }, h('b', {}, a.title), h('div', { class: 'mu' }, a.kind + (a.decision_note ? ' — ' + a.decision_note : ''))), pill(a.status),
    ceo && a.status === 'pending' && [h('button', { class: 'btn em', onclick: ev => run(ev.target, async () => { await api('POST', `/approvals/${a.id}/decide`, { decision: 'approved' }); render(); }) }, t('approve')),
      h('button', { class: 'btn bad', onclick: ev => { const n = prompt(t('note')); if (n) run(ev.target, async () => { await api('POST', `/approvals/${a.id}/decide`, { decision: 'rejected', note: n }); render(); }); } }, t('reject'))])) : h('div', { class: 'empty' }, t('none'))));
}

/* ---------- team ---------- */
async function viewTeam(main) {
  const d = await api('GET', '/employees?limit=200'), ceo = can('employees:manage'); const F = {};
  const inp = (k, type = 'text', dir) => F[k] = h('input', { type, required: k !== 'email', dir, autocomplete: 'off' });
  const form = ceo && h('form', { class: 'card', onsubmit: ev => { ev.preventDefault(); run(ev.target.querySelector('button'), async () => {
    await api('POST', '/employees', { username: F.u.value, display_name_ar: F.na.value, display_name_en: F.ne.value, role_ar: F.ra.value, role_en: F.re.value, rbac_role: F.r.value, password: F.p.value });
    toast(t('saved')); render(); }); } }, h('h2', {}, t('create')),
    h('div', { class: 'grid2' }, field(t('username'), inp('u', 'text', 'ltr')), field(t('rbac'), F.r = h('select', {}, ['member', 'manager', 'auditor', 'ceo_cto'].map(r => h('option', { value: r }, r)))),
      field(t('name_ar'), inp('na')), field(t('name_en'), inp('ne', 'text', 'ltr')), field(t('role_ar'), inp('ra')), field(t('role_en'), inp('re', 'text', 'ltr'))),
    field(t('temp'), inp('p', 'password', 'ltr')), h('p', {}, h('button', { class: 'btn gold' }, t('create'))));
  main.replaceChildren(h('div', { class: 'card', style: 'overflow:auto' }, h('h2', {}, t('team')), h('table', {}, h('tbody', {}, d.items.map(e => h('tr', {},
    h('td', {}, (e.rbac_role === 'ceo_cto' ? '★ ' : '') + nm(e), h('div', { class: 'mu' }, rl(e))), h('td', { dir: 'ltr' }, e.username), h('td', {}, e.rbac_role), h('td', {}, pill(e.is_active ? 'working' : 'cancelled')),
    ceo && h('td', {}, h('button', { class: 'btn', onclick: ev => run(ev.target, async () => { await api('POST', `/employees/${e.id}/${e.is_active ? 'deactivate' : 'activate'}`); render(); }) }, e.is_active ? t('deact') : t('act')), ' ',
      h('button', { class: 'btn', onclick: ev => { const p = prompt(t('temp')); if (p) run(ev.target, async () => { await api('POST', `/employees/${e.id}/reset-password`, { new_password: p }); toast(t('saved')); }); } }, t('reset')))))))), form);
}

/* ---------- operations: exports, audit, backups, retention ---------- */
async function viewOps(main) {
  const L = lang === 'ar' ? 'ar' : 'en', ent = ['tasks', 'clients', 'leads', 'projects', 'approvals', 'employees', 'audit_log', 'executive-summary'].filter(x => can('export:' + x.replace('-', '_')) || (x === 'executive-summary' && can('summary:read')));
  const cards = [h('div', { class: 'card' }, h('h2', {}, t('exports')), ent.map(x => h('div', { class: 'row' }, h('span', { class: 'g', dir: 'ltr' }, x), h('a', { class: 'btn', href: `/api/export/${x}.csv?lang=${L}`, download: '' }, 'CSV'), h('a', { class: 'btn', href: `/api/export/${x}.pdf?lang=${L}`, download: '' }, 'PDF'))))];
  const au = await api('GET', '/audit?limit=12'), vr = h('span', {});
  cards.push(h('div', { class: 'card', style: 'overflow:auto' }, h('h2', {}, t('audit')), h('div', { class: 'row' }, h('button', { class: 'btn', onclick: ev => run(ev.target, async () => { const v = await api('GET', '/audit/verify'); vr.textContent = (v.ok ? '✔ ' + t('chain_ok') : '✖ ' + t('chain_bad')) + ` (${v.entries})`; vr.style.color = v.ok ? 'var(--em)' : 'var(--rd)'; }) }, t('verify')), vr),
    h('table', {}, h('tbody', {}, au.items.map(a => h('tr', {}, h('td', { dir: 'ltr' }, a.ts.replace('T', ' ').slice(0, 19)), h('td', {}, a.actor_username), h('td', { dir: 'ltr' }, a.action)))))));
  if (S.me.is_platform_root && can('backups:read')) {
    const b = await api('GET', '/backups/status'), ceo = can('backups:manage');
    cards.push(h('div', { class: 'card' }, h('h2', {}, t('backups')), h('p', { class: 'mu' }, `${b.policy.schedule} · keep ${b.policy.keep_count} · ${t('last_ok')}: ${b.last_success ? b.last_success.finished_at : '—'}`),
      ceo && h('button', { class: 'btn em', onclick: ev => run(ev.target, async () => { const r = await api('POST', '/backups'); const v = await api('POST', `/backups/${r.id}/verify`); toast(v.ok ? t('saved') : 'verify failed', !v.ok); render(); }) }, t('backup_now')),
      b.runs.slice(0, 5).map(r => h('div', { class: 'row' }, h('span', { class: 'g' }, `#${r.id} ${r.kind}`), h('span', { class: 'mu' }, r.finished_at || ''), pill(r.status === 'completed' ? 'approved' : r.status === 'running' ? 'pending' : 'rejected')))));
  }
  if (can('retention:read')) {
    const runs = (await api('GET', '/retention/runs')).items, ceo = can('retention:manage'), pend = runs.find(r => r.status === 'pending_confirmation');
    const ph = h('input', { placeholder: pend ? pend.confirmation_phrase : '', dir: 'ltr' });
    cards.push(h('div', { class: 'card' }, h('h2', {}, t('retention')), ceo && h('button', { class: 'btn', onclick: ev => run(ev.target, async () => { const r = await api('POST', '/retention/dry-run'); toast(r.total_candidates ? t('dryrun_ok') : t('nothing')); render(); }) }, t('dry')),
      pend && h('div', { style: 'margin-top:.8rem' }, h('div', { class: 'mu', dir: 'ltr' }, JSON.stringify(pend.counts)), ceo && [field(t('phrase') + ': ' + pend.confirmation_phrase, ph),
        h('button', { class: 'btn bad', style: 'margin-top:.5rem', onclick: ev => { if (confirm(pend.confirmation_phrase + ' ?')) run(ev.target, async () => { await api('POST', `/retention/runs/${pend.id}/execute`, { confirm_phrase: ph.value }); toast(t('saved')); render(); }); } }, t('exec_btn'))]),
      runs.slice(0, 4).map(r => h('div', { class: 'row' }, h('span', { class: 'g mu', dir: 'ltr' }, `#${r.id} ${r.created_at.slice(0, 10)} · ${r.total_candidates}`), pill(r.status === 'executed' ? 'approved' : r.status === 'pending_confirmation' ? 'pending' : 'cancelled')))));
  }
  main.replaceChildren(h('div', { class: 'cols', style: 'grid-template-columns:1fr 1fr' }, h('div', { style: 'display:grid;gap:1rem' }, cards[0], cards[2] || h('span'), cards[3] || h('span')), h('div', {}, cards[1])));
}

document.addEventListener('keydown', e => {
  if (!S.me || e.target.closest('input,select,textarea') || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase(), tabs = TABS();
  if (k === 'l') setLang(lang === 'ar' ? 'en' : 'ar'); else if (k === 'escape') { S.sel = null; if (S.tab === 'hq') render(); } else if (/^[1-4]$/.test(k) && tabs[+k - 1]) { S.tab = tabs[+k - 1]; render(); }
});
(async () => { try { const d = await api('GET', '/auth/me'); S.me = d.user; S.csrf = d.csrf_token; } catch {} render(); })();
